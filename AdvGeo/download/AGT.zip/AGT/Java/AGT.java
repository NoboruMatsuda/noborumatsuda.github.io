/**
 * AGT.java
 *
 *	AdvGeo tutor executable module
 *
 * Created: Wed Sep 24 13:11:28 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: AGT.java 1.2 2003/12/09 22:06:45 NoboruM Exp NoboruM $
 *
 *
 * Use following command to make archive class files
 *
 *	jar cvf agt.zip *.class *.gif 
 *
 */

import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
// import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class AGT extends JApplet implements WindowListener, ActionListener {

    //-
    //-	Fields = = = = = = = = = = = = = = = = = = = = = = = = = 
    //- 

    // Version
    static String advGeoVersion = "1.1";

    // Flag telling if the tutor is running as a model tracer
    static boolean mtMode;
    static public boolean isMtMode() { return mtMode; }
    static public void setMtMode(boolean newMtMode) {
	mtMode = newMtMode;
    }

    // Problem ID
    Problem problem;

    // Communication Manager
    static ComManager comManager;
    public static ComManager getComManager() { return comManager; }
    public void setComManager(ComManager newComManager) {
	this.comManager = newComManager;
    }

    // Fatal Error message window
    static FatalMessage fatalMessage;
    public static FatalMessage getFatalMessage() { return fatalMessage; }
    public void setFatalMessage(FatalMessage newFatalMessage) {
	this.fatalMessage = newFatalMessage;
    }

    // The proposition asserted by the most reacent FC.  Used by
    // scaffolding in Inference Step
    static String fcLastAssertion;
    static public String getFcLastAssertion() { return fcLastAssertion; }
    static public void setFcLastAssertion(String newFcLastAssertion) {
	fcLastAssertion = newFcLastAssertion;
    }
    
    static boolean runningAsApplication = false;
    static public boolean isRunningAsApplication() {
	return runningAsApplication;
    }
    static public void setRunningAsApplication( boolean value ) {
	runningAsApplication = value;
    }

    // 
    //	GUI components
    // 

    // Top-level Container when running as an application
    static JFrame theFrame;

    // Screen size
    // static Dimension screenSize = new Dimension( 1250, 990 );
    static Dimension screenSize = new Dimension( 1200, 850 );

    // Container 
    JDesktopPane desktop;

    // Problem Description window
    ProblemDescription problemDescription;
    int pdXratio = 40;
    int pdYratio = 30;

    // Proof Table
    static ProofTable proofTable;
    public static ProofTable getProofTable() {
	return proofTable;
    }
    int ptXratio = 40;
    int ptYratio = 70;

    // Message window
    static Message messageWindow;
    int mwXratio = 60;
    int mwYratio = 30;

    // Inference Step
    static InferenceStep inferenceStep;
    public static InferenceStep getInferenceStep() {
	return inferenceStep;
    }
    int isXratio = 30;
    int isYratio = 70;

    // PropositionBuilder
    static PropositionBuilder propositionBuilder;
    public static PropositionBuilder getPropositionBuilder() {
	return propositionBuilder;
    }
    // AGT Logo
    JInternalFrame agtLogo;
    int pbXratio = 30;
    int pbYratio = 20;

    // Postulate Browser
    static PostulateBrowser postulateBrowser;
    int pobXratio = 30;
    int pobYratio = 50;

    // Menu Items
    final String MENU[][] = {
	// File menu
	{ "File", "Load", "Exit" }
    };
    
    // Default Font to display messages and equations
    // static Font displayFont = new Font( "Times New Roman", Font.PLAIN, 16 );
    // static final Font displayFont = new Font( "MS UI Gothic", Font.PLAIN, 18 );
    static final Font displayFont = new Font( "MS Gothic", Font.PLAIN, 18 );
    static Font getDisplayFont() { return displayFont; }
    static final Font displayFont14 = new Font( "MS Gothic", Font.PLAIN, 14 );
    static Font getDisplayFont14() { return displayFont14; }
    Font getDisplayFont( int size ) {
	return new Font( "MS Gothic", Font.PLAIN, size );
    }
    

    //-
    //- Run as an application = = = = = = = = = = = = = = = = = = = = 
    //-

    public AGT() {}
    
    public static void main(String[] args) {
	
	// Look and feel
	JFrame.setDefaultLookAndFeelDecorated( true );
	// Must run in English 
	//Locale.setDefault( Locale.ENGLISH  );
	Locale.setDefault( Locale.JAPANESE  );
	
	/* 
	   for (int i = 0; i < args.length; i++) {
	   System.out.println("args[" + i + "] = " + args[i] + " ");
	   }
	*/
	
	// When "-mt" is fed as an option, 
	if ( args.length != 0 ) {
	    if ( args[0].equals( "-mt" ) ) {
		setMtMode( true );
		System.out.println("Model tracing mode is ON");
	    }
	}

	// Create a tutor 
	AGT agt = new AGT();
	setRunningAsApplication( true );

	// Create a Frame and put the tutor on it
	theFrame = new JFrame();
	// Automatically hide and dispose the frame after invoking any
	// registered WindowListener objects
	theFrame.setDefaultCloseOperation( JFrame.DO_NOTHING_ON_CLOSE );
	theFrame.addWindowListener( agt );
	// Set window size and location
	// screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	theFrame.setSize( screenSize );
	theFrame.getContentPane().add( agt );
	theFrame.setVisible( true );

	// Start the tutor
	agt.init();
	agt.start();
    }

    //-
    //-	Run as an applet = = = = = = = = = = = = = = = = = = = = = = = = = 
    //-
    public void init() {

	// super( "AdvGeo Tutor " + advGeoVersion );

	// Initiate a communication manager
	setComManager( new ComManager() );
	// Register this "component" as a message receiver recognized
	// by the communication manager
	ComManager.registerComponent( this );

	// Initialize a desktop pane
	desktop = new JDesktopPane();
	desktop.setOpaque(true);
	setContentPane( desktop ); 

	setFatalMessage( new FatalMessage( desktop, getComManager() ) );

	/* Following two lines draws a red line around the desktop,
           which is just inside of the outer most frame and below menu
           bar */
	//Border desktopBorder = BorderFactory.createLineBorder(Color.red);
	//desktop.setBorder( desktopBorder ); 

	Dimension desktopSize =
	    new Dimension( screenSize.width, screenSize.height );
	// desktop.setPreferredSize( desktopSize );
	desktop.setSize( desktopSize );

	setVisible( true );
	
	System.out.println("Content pane size: " +
			   getContentPane().getSize());

	System.out.println("desktop size: " + desktop.getSize());

	// Menu bar
	/*
	  JMenuBar menuBar = setupMenubar();
	  setJMenuBar( menuBar );
	*/

	// Create and Initialize GUI components
	// Wed Apr 14 17:49:51 2004
	// this must be done by initGUI called by the LISP backend
	// setupWindows( desktop );

    }

    public void start() {
	runSession();
    }

    //-
    //-	Class Methods = = = = = = = = = = = = = = = = = = = = = = = = = 
    //- 

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *	Main loop
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    void runSession() {

	getComManager().setTutorUp( true );
	getComManager().mainLoop();
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *	Create and initialize GUI components used in AdvGeo
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
    void setupWindows( JDesktopPane desktop ) {

	// Problem Description
	if ( problemDescription == null ) {
	    Dimension pdSize = windowSize( pdXratio, pdYratio );
	    Point pdLocation = new Point( 0, 0 );
	    problemDescription = new ProblemDescription( pdSize, pdLocation );
	    problemDescription.setVisible( true );
	    desktop.add( problemDescription );
	}

	// Proof Table
	if ( proofTable == null ) {
	    Dimension ptSize = windowSize( ptXratio, ptYratio );
	    int ptY = problemDescription.getHeight();
	    Point ptLocation = new Point( 0, ptY );
	    proofTable = new ProofTable( ptSize, ptLocation );
	    desktop.add( proofTable );
	}

	// Message
	if ( messageWindow == null ) {
	    Dimension mwSize = windowSize( mwXratio, mwYratio);
	    int mwX = problemDescription.getWidth();
	    Point mwLocation = new Point( mwX, 0 );
	    messageWindow = new Message( mwSize, mwLocation );
	    messageWindow.setVisible( true );
	    desktop.add( messageWindow );
	}

	// propositionBuilder = new PropositionBuilder( pbSize, pbLocation );
	// propositionBuilder.setVisible( false );
	// desktop.add( propositionBuilder );
	
	// Postulate Browser
	if ( postulateBrowser == null ) {
	    Dimension pobSize = windowSize( pobXratio, pobYratio );
	    int pobX =
		problemDescription.getX() + problemDescription.getWidth();
	    int pobY = messageWindow.getHeight();
	    Point pobLocation = new Point( pobX, pobY );
	    postulateBrowser = new PostulateBrowser( pobSize, pobLocation );
	    desktop.add( postulateBrowser );
	}
	
	// AGT logo
	if ( agtLogo == null ) {
	    Dimension pbSize = windowSize( pbXratio, pbYratio );
	    int pbX =
		problemDescription.getX() + problemDescription.getWidth();
	    int pbY = postulateBrowser.getY() + postulateBrowser.getHeight();
	    Point pbLocation = new Point( pbX, pbY );
	    agtLogo = createAgtLogo( pbSize, pbLocation );
	    desktop.add( agtLogo );
	}

	// Inference Step
	if ( inferenceStep == null ) {
	    Dimension isSize = windowSize( isXratio, isYratio );
	    int isX = postulateBrowser.getX() + postulateBrowser.getWidth();
	    int isY = messageWindow.getHeight();
	    Point isLocation = new Point( isX, isY );
	    inferenceStep = new InferenceStep( isSize, isLocation );
	    desktop.add( inferenceStep );
	}
    }
    
    JInternalFrame createAgtLogo( Dimension size, Point location ) {

	JInternalFrame logo = new JInternalFrame();
	logo.setLocation( location );
	logo.setPreferredSize( size );

	/*
	  JPanel pane = new JPanel();
	  pane.setBackground( Color.yellow );
	  logo.getContentPane().add( pane );
	*/

	// 363 X 160
	ImageIcon icon = null; 
	if ( isRunningAsApplication() ) {
	    icon = new ImageIcon( "AGT-Logo.gif" ); 
	} else {
	    Image logoImage = getImage( getCodeBase(), "AGT-Logo.gif" );
	    icon = new ImageIcon( logoImage );
	}
	JLabel picture = new JLabel( icon );
	logo.getContentPane().add( picture );

	logo.pack();
	logo.setVisible( true );

	return logo;
    }

    // Returns a desired size of the window specified as a ratio to
    // the screen size
    Dimension windowSize( int xRatio, int yRatio ) {

	int width;
	int height;

	if ( isRunningAsApplication() ) {

	    // When running as an application, measure the size of
	    // content pane, because the screen size holds the window
	    // title area and border lines
	    Container contentPane = theFrame.getContentPane();
	    width = (int)contentPane.getSize().getWidth();
	    height = (int)contentPane.getSize().getHeight();

	} else {
	    
	    // When running as an applet, rerutning screen size is
	    // just fine
	    width = screenSize.width;
	    height = screenSize.height;
	}
	
	return new Dimension( width * xRatio / 100,
			      height * yRatio / 100 );
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *	Setup a menu bar
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
    JMenuBar setupMenubar() {

	JMenuBar menubar = new JMenuBar();
	JMenu menu;
	JMenuItem menuItem;

	// File menu
	menu = new JMenu( MENU[0][0] );
	menu.setMnemonic( KeyEvent.VK_F );
	menubar.add( menu );
	
	menuItem = new JMenuItem( MENU[0][1], KeyEvent.VK_L );
	menuItem.addActionListener( this );
	menu.add( menuItem );
	
	menuItem = new JMenuItem( MENU[0][2], KeyEvent.VK_X );
	menuItem.addActionListener( this );
	menu.add( menuItem );
	
	return menubar;
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *	Shutdown AdvGeo
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    public void stop() {
	closeAGT();
	super.stop();
    }

    public void destroy() {
	System.out.println( "destroy()..." );
	super.destroy();
    }

    void closeAGT() {
	
	System.out.println("Shutting down the tutor...");
	getComManager().sendAgtCommand( "(AGT:SHUTDOWN-TUTOR)" );
	getComManager().shutdown();

	if ( isRunningAsApplication()) {
	    System.exit( 0 );
	}
    }
	
    public void shutdownAGT() {

	// dispose();
	// getComManager().shutdown();
	// System.exit( 0 );
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     *	Misc methods relating to communication manager
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    //-
    //- Initialize GUI components - - - - - - - - - - - - - - -
    //-
    public void initGUI() {
	removeWindowsFromComManager();
	setupWindows( desktop );
    }

    void removeWindowsFromComManager() {

	if ( problemDescription != null ) {
	    problemDescription.dropFromComMamager();
	    desktop.remove( problemDescription );
	    problemDescription = null;
	}
	if ( proofTable != null ) {
	    proofTable.dropFromComMamager();
	    desktop.remove( proofTable );
	    proofTable = null;
	}
	if ( messageWindow != null ) {
	    messageWindow.dropFromComMamager();
	    desktop.remove( messageWindow );
	    messageWindow = null;
	}
	if ( inferenceStep != null ) {
	    inferenceStep.dropFromComMamager();
	    desktop.remove( inferenceStep );
	    inferenceStep = null;
	}
	if ( postulateBrowser != null ) {
	    postulateBrowser.dropFromComMamager();
	    desktop.remove( postulateBrowser );
	    postulateBrowser = null;
	}
    }

    //-
    //-	Login - - - - - - - - - - - - - - - - - - - - - - - - - 
    //-

    // Login window shared by login and acknowledgeLogin
    Login login = null;

    // Let a student identify himself
    public void login() {

	if ( login == null ) {
	    String loginMsg =
		"Welcome to AGT\n" + 
		"Please input a user name and a password";
	    login = new Login( loginMsg );
	    desktop.add( login );
	}
	login.reset();
	login.setVisible( true );
	login.toFront();
	login.grabInputFocus();
    }

    // 
    public void acknowledgeLogin() {
	if ( login != null ) {
	    login.setVisible( false );
	}
    }

    //-
    //-	Loading Problem - - - - - - - - - - - - - - - - - - - - 
    //-

    // Request the LISP backend to feed a problem
    void requestProblem() {

	getComManager().sendAgtCommand( "AGT", "(AGT:AGT-FEED-PROBLEM)" );
    }

    void requestProblem( String problem ) {

	String command = "(AGT:AGT-FEED-PROBLEM " + problem + ".lisp)";
	getComManager().sendAgtCommand( "AGT", command );
    }

    /* ------------------------------------------------------------
     *	Action Listener
     * ------------------------------------------------------------ */

    public void actionPerformed( ActionEvent event ) {
	
	String command = event.getActionCommand();
	
	if ( command.equals( MENU[0][1] ) ) {
	    // [File][load] 

	    // Load a problem
	    requestProblem();

	} else if ( command.equals( MENU[0][2] ) ) {
	    // [File][exit] 
	    
	    // Exit tutor
	    closeAGT();
	}
    }

    /* ------------------------------------------------------------
     *	window Listner
     * ------------------------------------------------------------ */

    public void windowClosing(WindowEvent windowEvent) {
	closeAGT();
    }
    public void windowClosed(WindowEvent windowEvent) {
    }
    public void windowOpened(WindowEvent windowEvent) {}
    public void windowIconified(WindowEvent windowEvent) {}
    public void windowDeiconified(WindowEvent windowEvent) {}
    public void windowActivated(WindowEvent windowEvent) {}
    public void windowDeactivated(WindowEvent windowEvent) {}
    
    //
    //  Code for demo & debug -------------------------------------
    //
    void demo() {

	/**
	   String goal = "<APM = <BQM";
	   Vector premises = new Vector();
	   premises.add( "M midpoint AB" );
	   premises.add( "AP = BQ" );

	   proofTable.setPremise( premises );
	   proofTable.setGoal( goal );
	*/

	// inferenceStep.selectTab( InferenceStep.BACKWARD_TAB );
	
	/*
	  String postulate = "MidPointLaw";
	  Vector dsPremise = new Vector();
	  dsPremise.add( "x midpoint ab" );
	  Vector premise = new Vector();
	  premise.add( "M midpoint AB" );
	  String dsConsequence = "ax = bx";
	  String consequence = "AM = BM";

	  inferenceStep.dispatchForwardInference( postulate,
	  dsPremise,
	  premise,
	  dsConsequence,
	  consequence );
	*/

	// Must initiated by dispatchForwardInference method
	// theForwardInference.scaffolding();

	// inferenceStep.insertStep( new StepSelectPostulate() );
	// inferenceStep.insertStep( new StepPickupPostulate() );
    }

}

//
// end of $RCSfile: AGT.java $
// 
