/**
 * ComManager.java
 *
 *	Maintain commucation channels among various window components
 *
 * Created: Fri Oct 03 11:23:53 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * $Id: ComManager.java 1.1 2003/10/04 17:15:48 NoboruM Exp NoboruM $
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.reflect.*;

public class ComManager {
  
    /* ------------------------------------------------------------
     *	Fields
     * ------------------------------------------------------------ */

    /*
      static final int PROOF_TABLE = 1;
      static final int INFERENCE_STEP = 2;
    */

    // The event queue
    Vector eventQueue = new Vector();
    
    //-
    //-	Socket communication
    //-
    // Socket
    MySocket socket;
    // server name
    // String serverName = "localhost";
    String serverName = "vanlehn22.lrdc.pitt.edu";
    // Socket port number
    int serverPort = 3042;
    
    // Interval for the server to poll socket
    final int SERVER_SLEEP_INTERVAL = 100;

    boolean tutorUp;
    public boolean isTutorUp() { return tutorUp; }
    public void setTutorUp(boolean newTutorUp) {
	this.tutorUp = newTutorUp;
    }

    //-
    //- Constructor
    //- 

    public ComManager() {

	// Establish connection between a LISP back-end
	try {
	    socket = new MySocket( serverName, serverPort );
	} catch ( IOException e ) {
	    e.printStackTrace();
	}
    }
    
    //-
    //-	Methods
    //- 

    /*
    void pushEventQueue( CcEvent event ) {
	eventQueue.add( event );
    }
    */

    void popEventQueue() {
	eventQueue.removeElementAt( 0 );
    }

    /* ------------------------------------------------------------
     *	Registering and looking up components
     * ------------------------------------------------------------ */
    
    // Each GUI component, including an instance of AGT itself, is
    // stored into registeredComponent Vector by its class name
    // followed by the instance object
    private static Vector registeredComponent = new Vector();

    public static void registerComponent( Object component ) {
	registeredComponent.add( component.getClass() );
	registeredComponent.add( component );
	/*
	  System.out.println( "ComManager:registerComponent" +
	  component.getClass() );
	*/
    }
	
    public static void dropComponent( Object component ) {
	registeredComponent.remove( component.getClass() );
	registeredComponent.remove( component );
    }

    public Object findComponent( String className ) {

	Class theClass = null;

	try {
	    theClass = Class.forName( className );
	} catch (ClassNotFoundException e) {
	    e.printStackTrace();
	}

	for (int i = 0; i < registeredComponent.size(); i+=2)
	    if ( theClass == registeredComponent.elementAt(i))
		return registeredComponent.elementAt(i+1);

	return null;
    }
    
    /* ------------------------------------------------------------
     *	Polling a socket and dispatch a message fetched
     * ------------------------------------------------------------ */

    /*
      <PostulateBrowser><loadDsName><args>TRI-CONG VERTICAL-ANGLE ISOSCELES-TRIANGLE RIGHT-ANGLE ADJACENT-RIGHT-ANGLES TRI-ANGLE-180 RIGHT-TRI-CONG Z-THEOREM F-THEOREM RIGHT-TRI-MEDIAN TRI-MIDPOINT-LAW ADJACENT-ANGLES MID-POINT PARA-COLLINEAR RECTANGLE PARA-COLL-4 PARALLELOGRAM RHOMBUS RECTANGLE-DIAGONAL SEGMENT-SUM TWO-RIGHT-TRI </args></loadDsName></PostulateBrowser>
    */
    void mainLoop() {

	String msg;

	while ( isTutorUp() ) {

	    try {
		Thread.sleep( SERVER_SLEEP_INTERVAL );
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	    msg = socket.readLineNoBlock();

	    if ( msg != "" ) {
		System.out.println("mainLoop: msg => " + msg);

		String firstTag = ComParser.getFirstTag( msg );

		// System.out.println("mainLoop: firstTag => " + firstTag);

		if ( ComParser.isStandaloneTag( firstTag ) )
		    dispatch( ComParser.stripOff( firstTag ) );
		else {
		    String componentName = ComParser.stripOff( firstTag );
		    String methodCall = ComParser.stripFirstTag( msg );

		    /*
		      System.out.println("mainLoop: componentName => " +
		      componentName + ", methodCall => " +
		      methodCall );
		    */

		    dispatch( componentName, methodCall );
		}
	    }
	}
    }

    void dispatch( String methodName ) {

	Method method = null;

	try {
	    method = ComManager.class.getMethod( methodName, new Class[] {} );
	    method.invoke( this, new Object[] {} );
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    public void dispatch( String componentName, String methodCall ) {
	
	Object component = findComponent( componentName );
	Class theClass = component.getClass();
	Method theMethod = ComParser.getMethod( theClass, methodCall );
	Object[] arguments = ComParser.getArguments( methodCall );

	try {
	    /*
	      System.out.println("ComManager.diapatch ======");
	      System.out.println("  method -> " + theMethod);
	      System.out.println("  component -> " + component);
	      System.out.println("  arguments -> " + arguments);
	    */

	    theMethod.invoke( component, arguments );
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    /*
    // This method must be called when a component gets an event fired
    public void dispatch( Object sender, String message ) {

	// Dispatch first event waiting in the queue, if any.
	if ( !eventQueue.isEmpty() ) {

	    CcEvent event = (CcEvent)eventQueue.firstElement();
	    if ( event.getSender().contains( sender ) ) {
		event.dispatch( message );
		eventQueue.removeElementAt( 0 );
	    }
	}
    }
    */

    /* ------------------------------------------------------------
     *	Compose and send a message from GUI components
     * ------------------------------------------------------------ */

    // if no sender is specified, set it as 'AGT
    void sendAgtCommand( String command ) {
	sendAgtCommand( "AGT", command );
    }

    // Compose a GUI-EVENT and send it to a socket
    void sendAgtCommand( String sender, String command ) {
	
	sendAgtMessage( ":AGT-COMMAND ", sender, command );
    }

    // Composes a message to report clicking on a component.  <sender>
    // must be an InternalFrame that contains the GUI component that
    // launched the mouseClicked event, whereas <arg> is an event
    // specific agrument that is wished to pass to the AGT LISP-backend.
    void sendMouseClick( String sender, String arg ) {
	sendAgtMessage( ":MOUSE-CLICK", sender, arg );
    }
    
    // Composes a message to report a string input.  Same comments on
    // <sender> and <arg> as sendMouseClick defined above.
    void sendStringInput( String sender, String arg ) {
	sendAgtMessage( ":STRING-INPUT", sender, arg );
    }
    
    void sendAgtMessage( String type, String sender, String arg ) {

	// if the arg contains comma(s), replace it with "#\,"
	/*
	if ( arg.indexOf( ',' ) != -1 )
	    arg = arg.replaceAll( ",", "#\\\\," );
	if ( arg.indexOf( '\'' ) != -1 )
	    arg = arg.replaceAll( "'", "#\\\\'" );
	*/

	String msg = "(" + type + " " + sender + " " + arg + ")\n";
	socket.println( msg );
    }

    /* ------------------------------------------------------------
     *	Shutting down a connection to the LISP back-end
     * ------------------------------------------------------------ */

    void shutdown() {

	setTutorUp( false );

	// Send a signal to shutdown the socket stream.  The LISP
	// backend is waiting for this to arrive
	socket.println( ":GOOD-BYE" );

	try {
	    socket.close();
	} catch ( IOException e ) {
	    e.printStackTrace();
	}
    }
}

//
// $RCSfile: ComManager.java $
//
