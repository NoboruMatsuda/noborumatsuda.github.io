/**
 * ComParser.java
 *
 *	XML-like message parser.  See ComManager.lisp for the details
 *	of message format.
 *
 * Created: Fri Oct 31 23:23:41 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id$ */

import java.util.*;
import java.lang.reflect.*;

public class ComParser {
    

    // Returns the string between first '<' and '>' pair, which is
    // supposed to be a command name
    public static String getFirstTag( String msg ) {

	String tag = null;
	int start = msg.indexOf( '<' );
	int end = msg.indexOf( '>' );

	if ( (start > -1) && (end>start)) {
	    tag = msg.substring( start, end+1 );
	}

	return tag;
    }

    // returns "" if <firstTag> is a standalone tag, i.e., <foo/>
    // otherwise returns the string between <firstTag> and
    // </firstTag>
    public static String stripFirstTag( String msg ) {

	String body = "";
	String firstTag = getFirstTag( msg );

	if ( !isStandaloneTag( firstTag ) ) {
	    int start = firstTag.length();
	    int end = msg.indexOf( "</" + firstTag.substring( 1 ) );
	    body = msg.substring( start, end );
	}
	return body;
    }

    // Returns only "tagName" in "<tagName>"
    public static String stripOff( String tag ) {

	String tagName = "";

	if ( isStandaloneTag( tag ) )
	    tagName = tag.substring(1, tag.length() -2 );
	else
	    tagName = tag.substring(1, tag.length() -1 );

	return tagName;
    }

    // Drops the string cirrounded by the first <tag> and </tag> pair
    // from argList and returns remaning string
    static String removeFirstArg( String argList ) {
	
	String body = "";
	String tag = getFirstTag( argList );
	int index = argList.indexOf( "</" + tag.substring( 1 ) );
	int cutOff = index + tag.length() + 1;

	/*
	  System.out.println("tag => " + tag);
	  System.out.println("argLst.length() => " + argList.length());
	  System.out.println("cutOff => " + cutOff);
	*/

	if ( tag != "" && cutOff < argList.length() ) {
	    body = argList.substring( cutOff );
	}
	
	return body;
    }

    // Returns a method specified by methodCall, which is in the form
    // of <method><argType>argString</argType>...</method>
    public static Method getMethod( Class theClass, String methodCall ) {

	/*
	  System.out.println("ComParse.getMethod: theClass => " + theClass +
	  ", methodCall => " + methodCall);
	*/

	String methodName = stripOff( getFirstTag( methodCall ) );
	String argList = stripFirstTag( methodCall );
	Class[] argTypes = getArgTypes( argList );

	/*
	  System.out.println("methodName => " + methodName);
	  for (int i = 0; i < argTypes.length; i++) {
	  System.out.println("argTypes[" + i + "]=" + argTypes[i]);
	  }
	*/

	Method method = null;
	try {
	    method = theClass.getMethod( methodName, argTypes );
	    // System.out.println("method ===>>>> " + method);
	} catch (NoSuchMethodException e) {
	    e.printStackTrace();
	}

	return method;
    }

    // Returns a vector of class extracted from a list of argments in
    // argList, which is in the form of <argType>arg</argType>...
    static Class [] getArgTypes( String argList ) {

	// System.out.println("ComParser.getArgTypes: argList => " + argList);
	
	Vector /* Class */ types = new Vector();

	String argTypeTag;
	while ( (argTypeTag = getFirstTag( argList )) != null ) {
	    types.add( toClass( stripOff( argTypeTag ) ) );
	    argList = removeFirstArg( argList );
	    // System.out.println("new argList => " + argList);
	}

	Class[] argTypes = new Class[ types.size() ];
	for (int i = 0; i < types.size(); i++) {
	    argTypes[i] = (Class)types.elementAt(i);
	}

	return argTypes;
    }

    // 
    static Class toClass( String className ) {

	if ( className.equals( "String" ) ) {
	    return String.class;
	} else if ( className.equals( "int" ) ) {
	    return int.class;
	} else {
	    System.out.println( "ComParser.toClass: unknown class " +
				className );
	}
	return null;
    }

    // Returns a vector of string as a list of arguments specified in
    // the <methodCall> by <argType>argString</argType>
    // 
    public static Object[] getArguments( String methodCall ) {
	
	Vector /* String */ args = new Vector();
	String argList = stripFirstTag( methodCall );
	String argTypeTag;

	while ( (argTypeTag = getFirstTag( argList )) != null ) {

	    // stripOff removes " and "
	    String argStr = stripOff( stripFirstTag( argList ) );

	    // if the type of argument is int then translate argStr
	    // into Integer
	    if ( stripOff( argTypeTag ).equals( "int" ) )
		args.add( new Integer( argStr ) );
	    else
		args.add( argStr );

	    argList = removeFirstArg( argList );
	}

	/*
	  System.out.println("args => " + args);
	  System.out.println("args.size() => " + args.size());
	*/
	
	Object[] arguments = new Object[ args.size() ];
	for (int i = 0; i < args.size(); i++) {
	    arguments[i] = args.elementAt(i);
	}
	return arguments;
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     *	Tests
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    // See if the tag is <hoge/> 
    public static boolean isStandaloneTag( String tag ) {
	return tag.charAt( tag.length() - 2 ) == '/';
    }

}


/*
<PostulateBrowser><loadDsName><args>TRI-CONG VERTICAL-ANGLE ISOSCELES-TRIANGLE RIGHT-ANGLE ADJACENT-RIGHT-ANGLES TRI-ANGLE-180 RIGHT-TRI-CONG Z-THEOREM F-THEOREM RIGHT-TRI-MEDIAN TRI-MIDPOINT-LAW ADJACENT-ANGLES MID-POINT PARA-COLLINEAR RECTANGLE PARA-COLL-4 PARALLELOGRAM RHOMBUS RECTANGLE-DIAGONAL SEGMENT-SUM TWO-RIGHT-TRI </args></loadDsName></PostulateBrowser>
*/


//
// $RCSfile$
// 
