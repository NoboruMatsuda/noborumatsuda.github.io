/**
 * $RCSfile: DiagramDisplay.java $
 *
 *	The most basic panel that displays a problem figure.
 *
 *	Must have a Figure object, which is held in a problem, in
 *	which the configuration of problem figuer is specified.
 *
 * Created: Sat May 11 16:23:13 2002
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * $Id: DiagramDisplay.java 1.2 2003/05/07 22:02:24 NoboruM Exp NoboruM $
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DiagramDisplay extends JPanel implements ComponentListener {

    //-
    //- Field - - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    // Dimension of the frame
    int width;
    int height;

    // Mergin around the diagram
    int displayMargin = 20;
    public int getDisplayMargin() { return displayMargin; }
    public void setDisplayMargin(int newDisplayMargin) {
	this.displayMargin = newDisplayMargin;
    }

    // the problem diagram to be displayed
    Figure figure;
    public Figure getFigure() { return figure; }
    public void setFigure( Figure figure ) {
	this.figure = figure;
	// xyCanonicalizeFigure();
	// flipVertical();
	repaint();
    }
    
    //-
    //- Constructor - - - - - - - - - - - - - - - - - - - - - - - - -
    //-

    public DiagramDisplay() {}

    public DiagramDisplay( Dimension size ) {
	this( size.width, size.height );
    }

    public DiagramDisplay ( int width, int height ) {

	this.width = width;
	this.height = height;

	setPreferredSize( new Dimension( width, height ) );

	// Must have no border
	setBorder( BorderFactory.createEmptyBorder() );
	
	setBackground( Color.white );
	addComponentListener(this);
    }

    //-
    //-	Methods - - - - - - - - - - - - - - - - - - - - - - - - -
    //- 

    // Adjust the coordinate to fit the window
    public void xyCanonicalizeFigure() {
	figure.xyCanonicalize( this.width, this.height, getDisplayMargin() );
    }

    void xyCanonicalizeFigure( Figure fig ) {
	fig.xyCanonicalize( this.width, this.height, getDisplayMargin() );
    }

    // Put the figure up side down 
    public void flipVertical() {
	figure.flipVertical();
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // repaint compoment
    // 
    public void paintComponent(Graphics g) {

	// System.out.println("paintComponent@DiagramDisplay");

	// paint background
	super.paintComponent(g); 

	// if a configuration hasn't been read, then do nothing
	if ( this.figure == null || this.figure.notReadYet() )
	    return;

	figure.drawFigure(g);

	/*
	g.setColor( Color.red );
	g.drawRect( 1, 1, width-1, height-1);
	*/
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    // ComponentListener
    //
    public void componentResized(ComponentEvent e) {

	height = getHeight();
	width = getWidth();

	if ( this.figure != null ) xyCanonicalizeFigure();
    }
    public void componentMoved(ComponentEvent param1) {}
    public void componentShown(ComponentEvent param1) {}
    public void componentHidden(ComponentEvent param1) {}

}

//
// end of DiagramDisplay
//
