/**
 * Equation.java
 *
 *
 * Created: Mon Feb 23 22:31:16 2004
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * $Id: Equation.java 1.1 2004/02/24 21:36:30 NoboruM Exp NoboruM $
 */

public class Equation {

    //-
    //-	Field - - - - - - - - - - - - - - - - - - - - - - - - - 
    //-

    static String[] arithmeticTermPrefix = {":EQ", ":PARALLEL", ":CONG" };
    static String[] arithmeticTermString = {"��", "//", "��" };
    
    static String[] fprimLabelPrefix = {":P", ":S", ":R", ":A", ":T", ":L" };
    static String[] fprimLabelString = {"", "", "", "��", "��", ""};

    static String[] unitaryPrefix = {":TRIANGLE", ":RIGHTANG", ":RECTANGLE",
				     ":PARALLELOGRAM", ":RHOMBUS" };
    static String[] unitaryString = {"��", "��", "Rectangle-",
				     "Parallelogram-", "Phombus-"};

    static final int ARITHMETIC_TERM = 1;
    static final int PRIMITIVE_TERM = 2;
    static final int OBJECT_TERM = 3;

    //-
    //-	Method - - - - - - - - - - - - - - - - - - - - - - - - - 
    //-
    
    //-
    //- Convert ugly LISP expressions into human friendly math expressions
    //-

    public static String reformMessage( String msg ) {

	String goodString = "";
	int index = 0;
	int begin = msg.indexOf( '(' );

	while ( !( begin < 0 ) ) {
	    String term = getTerm( msg, begin );
	    // System.out.println("term -> :" + term + ":");
	    String termEq = toEquation( term );
	    goodString += msg.substring( index, begin ) + termEq;
	    index = begin + term.length();
	    begin = msg.indexOf( '(', index );
	}
	goodString += msg.substring( index, msg.length() );

	return goodString;
    }

    // Given a LISP expression representing an equation, convert it
    // into human friendly math form
    public static String toEquation( String expression ) {

	// System.out.println("toEquation:: " + expression);

	String equation = "";

	if ( !expression.equals( "" ) ) {

	    switch ( equationType( expression ) ) {
	    case ARITHMETIC_TERM:
		// A = B, A // B, or A \cong B
		equation = arithmeticTermToEquation( expression );
		break;
		
	    case PRIMITIVE_TERM:
		// One of the geometric primitives
		equation = primitiveTermToEquation( expression );
		break;
		
		
	    case OBJECT_TERM:
		// geometric objects that have primitive terms as its
		// arguments.  E.g., (:triangle (:p a) (:p b) (:p c))
		equation = objectTermToEquation( expression );
		break;
	    }
	}
	return equation;
    }

    // Given a LISP expression represeiting binomial term, convert it
    // into a human friendly equation
    static String arithmeticTermToEquation( String exp ) {

	String op = getIdentifier( exp );
	String opStr = operatorString( op );

	// The position of the second open bracket, i.e., the
	// beginning of the first argument of <exp>
	int begin = exp.indexOf( '(' );
	begin = exp.indexOf( '(', begin +1 );
	String t1 = getTerm( exp, begin );
	String t1Str = toEquation( t1 );

	// The position of the third open bracket, i.e., the beginning
	// of the second argument of <exp>
	begin = exp.indexOf( '(', begin + t1.length() );
	String t2 = getTerm( exp, begin );
	String t2Str = toEquation( t2 );

	return t1Str + " " + opStr + " " + t2Str;
    }

    // Given a LISP expression <exp> representing a primitive
    // geometric object such as a segment, angle, etc, returns a
    // corresponding math expression
    static String primitiveTermToEquation( String exp ) {

	String fp = getIdentifier( exp );
	String fpStr = fprimString( fp );

	String args = getFprimArgs( exp );

	return fpStr + args;
    }

    static String objectTermToEquation( String exp ) {

	// System.out.println("objectTermToEquation:: exp -> " + exp);

	String id = getIdentifier( exp );
	String idStr = objectString( id );

	String args = "";

	// The beginning of the first argument, i.e., the second open
	// bracket.
	int index = exp.indexOf( '(' );
	index = exp.indexOf( '(', index +1 );

	// The beginning of an argument. 
	int begin = index;

	while ( index > 0 ) {
	    
	    if ( exp.charAt(index) == ')' ) {
		args += toEquation( exp.substring( begin, index +1 ) );
		begin = index + 1;
		index = exp.indexOf( '(', index );
	    } else {
		index++; 
	    }
	}

	// System.out.println("idStr: " + idStr + ", args: " + args);
	return idStr + args;
    }

    // ----------------------------------------------------------------------
    //	Classifiers
    // ----------------------------------------------------------------------

    // Return a type of the LISP like expression 
    static int equationType( String exp ) {

	String id = getIdentifier( exp );
	int type = -1;
	
	if ( memberOf( id, arithmeticTermPrefix ) )
	    type = ARITHMETIC_TERM;
	else if ( memberOf( id, fprimLabelPrefix ) )
	    type = PRIMITIVE_TERM;
	else if ( memberOf( id, unitaryPrefix ) )
	    type = OBJECT_TERM;

	return type;
    }

    // Returns a string representing the operator <op>
    static String operatorString( String op ) {

	String opStr = "";
	for (int i = 0; i < arithmeticTermPrefix.length; i++) {
	    if ( op.toUpperCase().equals(arithmeticTermPrefix[i]) ) {
		opStr = arithmeticTermString[i];
		break;
	    }
	}
	return opStr;
    }

    static String fprimString( String fp ) {

	String fpStr = "";

	for (int i = 0; i < fprimLabelPrefix.length; i++) {
	    if ( fp.toUpperCase().equals( fprimLabelPrefix[i] ) ) {
		fpStr = fprimLabelString[i];
		break;
	    }
	}
	return fpStr;
    }

    static String objectString( String obj ) {

	// System.out.println("ObjectString:: obj -> " + obj);
	
	String objStr = "";

	for (int i = 0; i < unitaryPrefix.length; i++) {
	    if ( obj.toUpperCase().equals( unitaryPrefix[i] ) ) {
		objStr = unitaryString[i];
		break;
	    }
	}
	return objStr;
    }

    // ----------------------------------------------------------------------
    // String manipulation
    // ----------------------------------------------------------------------

    public static String getTerm( String exp, int begin ) {

	// System.out.println("exp => " + exp);

	int end = begin +1;
	int balance = 1;

	while ( balance > 0 ) {

	    // System.out.println("exp.charAt(" + end + ") == " + exp.charAt(end) );

	    if ( exp.charAt( end ) == '(' ) {
		balance++;
	    } else if ( exp.charAt( end ) == ')' ) {
		balance--;
	    }
	    end++;
	}

	return exp.substring( begin, end );
    }

    // Extract the first LIST keyword out of a LISP s-expression <exp>
    //     <exp> -> (:eq (:s a b) (:b c d))
    static String getIdentifier( String exp ) {

	// The position where the first LISP keyword starts
	int begin = exp.indexOf( ':' );
	// The position where the first LISP keyword ends
	int end = exp.indexOf( ' ', begin );
	
	return exp.substring( begin, end );
    }

    // Given a LISP expression representing a primitive object, e.g.,
    // (:s a b), returns a flat string concatinating its arguments
    // (i.e., the name of the primitive object
    static String getFprimArgs( String fprim ) {

	String args = "";

	// The begining of the LISP keyword representing the type of
	// <fprim>
	int keywordPosition = fprim.indexOf( ':' );
	// The first white space after the keyword
	int index = fprim.indexOf( ' ', keywordPosition );

	// until hit a close bracket, ...
	while ( fprim.charAt( index ) != ')' ) {
	    // if the index-th character is a letter or a digit, ...
	    if ( Character.isLetterOrDigit(fprim.charAt( index )) )
		// concatinate it at the tail of <args>
		args += Character.toUpperCase( fprim.charAt( index ) );

	    index++;
	}

	return args;
    }

    // ----------------------------------------------------------------------
    //	Misc utilities
    // ----------------------------------------------------------------------

    // Returns true when the string <s> is a member of <list>
    static boolean memberOf( String s, String[] list ) {

	for (int i = 0; i < list.length; i++)
	    if ( s.toUpperCase().equals(list[i]) )
		return true;

	return false;
    }

}

//
// end of $RCSfile: Equation.java $
// 
