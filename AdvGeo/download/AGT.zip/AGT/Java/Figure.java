/**
 * Figure.java
 *
 *	Description of problem configuration
 *
 * Created: Sat May 11 12:48:07 2002
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: Figure.java 1.1 2003/05/07 22:03:54 NoboruM Exp NoboruM $
 */

import java.io.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;

public class Figure {

    /* ------------------------------------------------------------
     *	Fields
     * ------------------------------------------------------------*/

    // Points
    private Vector p = new Vector();

    // Segments represented by two endpoints
    private Vector s = new Vector();
    Hashtable segColor = new Hashtable();
    Color defaultColor = Color.black;
    Color highlightColor = Color.red;

    // Default width of the line
    BasicStroke wideStroke = new BasicStroke(3.0f);

    // Zooming ratio for the configuration to fit into the window.
    // This value is used in xyCanonicalize and lookupPointByPosition
    double ratio = 1.0;

    // Minimum and maximum xy-coordination for the points used for
    // canonicalization and flipVertical
    double max_x = 0;
    double max_y = 0;
    double min_x = Double.MAX_VALUE;
    double min_y = Double.MAX_VALUE;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public Figure() {}

    public Figure( String config ) {

	// This is a deprecated stuff, but I need an input stream from
	// string, which a StringReader does not fit.
	StringBufferInputStream inStr = new StringBufferInputStream( config );
	// StringReader reader = new StringReader( config );
	lisp.LispInterpreter interpreter = new lisp.LispInterpreter( inStr );

	Object configuration = null;
	try {
	    configuration = interpreter.getReader().read();
	} catch (Exception e) {
	    e.printStackTrace();
	}

	readConfigurationFromLispExp( configuration );
    }

    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------*/

    //=
    //=	Read a configuration from LISP data =========================
    //= 

    /**
     *	Read LISP expressions into p and s
     */
    void readConfigurationFromLispExp( Object data ) {

	Object gDat[] = new Object[3]; 
	
	gDat[0] = ((lisp.LispCons)data).getSecond();
	gDat[1] = ((lisp.LispCons)data).getThird();
	gDat[2] = ((lisp.LispCons)data).getFourth();
	
	// System.out.println( gDat[0] );
	
	for ( int i = 0; i < 3; i++ ) {
	    
	    String car = ((lisp.LispCons)gDat[i]).getCar().toString();
	    Object cdr = ((lisp.LispCons)gDat[i]).getCdr();
	    
	    // System.out.println( car );
	    // System.out.println( cdr );
	    
	    if ( car.equals( ":point" ) )
		readPoints( cdr );
	    else if ( car.equals( ":segment" ) )
		readSegments( cdr );
	}
    }

    /**
     *	Read point data from a list of points
     */
    void readPoints( Object points ) {
	
	Object thePoint;
	String label;
	String numString;
	double px, py, lx, ly;

	while ( points != lisp.LispCons.emptyList ) {

	    thePoint = ((lisp.LispCons)points).getCar();
	    label = ((lisp.LispCons)thePoint).getCar().toString();

	    // x-coordinate of the point
	    numString = ((lisp.LispCons)thePoint).getSecond().toString();
	    px = stringToDouble( numString );

	    // y-coordinate of the point
	    numString = ((lisp.LispCons)thePoint).getThird().toString();
	    py = stringToDouble( numString );

	    // x-coordinate of the point label
	    numString = ((lisp.LispCons)thePoint).getFourth().toString();
	    lx = stringToDouble( numString );

	    // y-coordinate of the point label
	    numString = ((lisp.LispCons)thePoint).getFifth().toString();
	    ly = stringToDouble( numString );

	    /*
	      System.out.println("Read Point " + label +
	      "(" + px + ", " + py + ", " +
	      lx + ", " + ly + ")" );
	    */

	    // Make a new point and put it into the point pool.
	    p.addElement( new GpPoint( px, py, label, lx, ly ) );
	    
	    points = ((lisp.LispCons)points).getCdr();
	}
    }

    /**
     *	Read segment data from a list of segments
     */
    void readSegments( Object segs ) {

	Object theSegment;
	String endp1Label, endp2Label;
	GpPoint endp1, endp2;
	
	while ( segs != lisp.LispCons.emptyList ) {

	    theSegment = ((lisp.LispCons)segs).getCar();
	    
	    endp1Label = ((lisp.LispCons)theSegment).getFirst().toString();
	    endp2Label = ((lisp.LispCons)theSegment).getSecond().toString();
	    endp1 = lookupPointByLabel( endp1Label );
	    endp2 = lookupPointByLabel( endp2Label );

	    // Make a new segment and put it into the segment pool.
	    GpSegment newSeg = new GpSegment( endp1, endp2 );
	    s.addElement( newSeg );
	    segColor.put( newSeg, defaultColor );

	    segs = ((lisp.LispCons)segs).getCdr();
	}

	System.out.println(s.size() + " segments read");
    }

    // Add a segment that has p1 and p2 as its endpoints
    GpSegment addSegment( GpPoint p1, GpPoint p2 ) {

	GpSegment newSegment = new GpSegment( p1, p2 );
	s.addElement( newSegment );
	segColor.put( newSegment, highlightColor );
	return newSegment; 
    }

    //=
    //=	Lookup methods ===================================================
    //=

    /**
     *	Lookup element by its labels
     */
    GpPoint lookupPointByLabel( String l ) {

	Enumeration points = getPoints();

	while ( points.hasMoreElements() ) {
	    GpPoint p = (GpPoint)points.nextElement();
	    if ( l.toUpperCase().equals( p.getLabel().toUpperCase() ) ) {
		return p;
	    }
	}
	return null;
    }
    
    GpPoint lookupPointByPosition( Point p ) {

	Enumeration points = getPoints();

	while ( points.hasMoreElements() ) {
	    GpPoint point = (GpPoint)points.nextElement();
	    if ( point.isInNeighbor( p ) ) {
		return point;
	    }
	}
	return null;
    }

    GpSegment lookupSegmentByName( String name ) {

	String l1 = name.substring( 0, 1 ).toUpperCase();
	String l2 = name.substring( 1, 2 ).toUpperCase();
	String theName = l1.compareTo( l2 ) < 0 ? l1 + l2 : l2 + l1;

	// System.out.println("lookupSegmentByName: theName " + theName);

	Enumeration segments = getSegments();
	while ( segments.hasMoreElements() ) {
	    GpSegment segment = (GpSegment)segments.nextElement();
	    // System.out.println("segment " + segment.getName());
	    if ( segment.getName().toUpperCase().equals( theName ) ) {
		// System.out.println("Got " + segment.getName());
		return segment;
	    }
	}
	return null;
    }

    //=
    //=	Drawing configuration =========================================
    //= 

    void drawFigure( Graphics g ) {
	drawSegments(g);
	drawPointLabels(g);
    }

    void drawPointLabels( Graphics g ) {

	Enumeration points = getPoints();
	while ( points.hasMoreElements() ) {

	    GpPoint p = (GpPoint)points.nextElement();
	    g.drawString( p.getLabel().toUpperCase(),
			  (int)p.getLx(), (int)p.getLy() );
	}
    }
	
    void drawSegments( Graphics g ) {

	Graphics2D g2 = (Graphics2D) g;
	g2.setStroke(wideStroke);

	Enumeration segments = getSegments();
	while ( segments.hasMoreElements() ) {

	    GpSegment s = (GpSegment)segments.nextElement();

	    GpPoint[] endpoints = s.getEndpoints();

	    g.setColor( (Color)segColor.get( s ) );
	    g2.draw( new Line2D.Double( (int)endpoints[0].getX(),
					(int)endpoints[0].getY(),
					(int)endpoints[1].getX(),
					(int)endpoints[1].getY() ) );
	    g.setColor( defaultColor );

	    /*
	      g.drawLine( (int)endpoints[0].getX(), (int)endpoints[0].getY(),
	      (int)endpoints[1].getX(), (int)endpoints[1].getY() );
	    */

	}
    }

    void highlightSegment( String name ) {

	System.out.println("highlightSegment: " + name);
	
	GpSegment seg = lookupSegmentByName( name );
	segColor.remove( seg );
	segColor.put( seg, highlightColor );
    }

    //=
    //= Misc methods ==================================================
    //=

    /**
     *	Return the enumeration of segments and points
     */
    public Enumeration getSegments() {
	return s.elements();
    }

    public Enumeration getPoints() {
	return p.elements();
    }

    /**
     *	return true if the configuration hasn't been read yet
     */
    public boolean notReadYet() {
	return p.isEmpty();
    }

    /**
     *	Flip the figure vertically
     */
    public void flipVertical( int height, int mergin ) {

	Enumeration points = getPoints();

	while ( points.hasMoreElements() ) {

	    GpPoint p = (GpPoint)points.nextElement();
	    p.setY( height - p.getY() + mergin );
	    p.setLy( height - p.getLy() + mergin );
	}
    }

    void flipVertical() {

	readMinMax();
	// System.out.println("max_Y: " + max_y + ", min_y: " + min_y);

	double center_y = (max_y + min_y) / 2;
	// System.out.println("center_y: " + center_y);

	Enumeration points = getPoints();
	while ( points.hasMoreElements() ) {

	    GpPoint p = (GpPoint)points.nextElement();
	    p.setY( center_y - (p.getY() - center_y));
	    p.setLy( center_y - (p.getLy() - center_y));
	}
    }

    /**
     *	Adjust figure size into a given dimension
     */
    public void xyCanonicalize( int width, int height, int mergin ) {

	// System.out.println("xyCanonicalize " + width + ":" + height);
	
	max_x = 0;
	max_y = 0;
	min_x = Double.MAX_VALUE;
	min_y = Double.MAX_VALUE;

	Enumeration points = getPoints();
	while ( points.hasMoreElements() ) {

	    GpPoint p = (GpPoint)points.nextElement();
	    if ( max_x < p.getX() ) max_x = p.getX();
	    if ( max_y < p.getY() ) max_y = p.getY();
	    if ( min_x > p.getX() ) min_x = p.getX();
	    if ( min_y > p.getY() ) min_y = p.getY();
	}
	
	double fwidth = (max_x - min_x);
	double fheight = (max_y - min_y);
	double areaWidth = (width - (mergin * 2));
	double areaHeight = (height - (mergin * 2));

	double w_ratio =  areaWidth / fwidth;
	double h_ratio =  areaHeight / fheight;

	double x_offset;
	double y_offset;

	if ( w_ratio * fheight > areaHeight ) {
	    ratio = h_ratio;
	    x_offset = (width - (fwidth * ratio)) / 2;
	    y_offset = mergin;
	} else {
	    ratio = w_ratio;
	    x_offset = mergin;
	    y_offset = (height - (fheight * ratio)) / 2; 
	}
	
	points = getPoints();
	while ( points.hasMoreElements() ) {

	    GpPoint p = (GpPoint)points.nextElement();
	    double x = x_offset + ((p.getX() - min_x) * ratio);
	    double y = y_offset + ((p.getY() - min_y) * ratio);
	    double lx = x_offset + ((p.getLx() - min_x) * ratio);
	    double ly = y_offset + ((p.getLy() - min_y) * ratio);
	    p.moveTo( x, y, lx, ly );
	}
    }

    // Quite ad-hoc for AGT Evaluation 2004, but quick hack to put
    // some spaces between two triangles used in TRI-CONG
    void separateTriangles() {

	readMinMax();

	double gap = 0.0;
	double delta = 0.0;

	GpPoint x = lookupPointByLabel( "X" );
	GpPoint y = lookupPointByLabel( "Y" );
	GpPoint z = lookupPointByLabel( "Z" );
	GpPoint u = lookupPointByLabel( "U" );
	GpPoint v = lookupPointByLabel( "V" );
	GpPoint w = lookupPointByLabel( "W" );

	double min_xyz = Double.MAX_VALUE;
	double max_xyz = 0;
	double min_uvw = Double.MAX_VALUE;
	double max_uvw = 0;
	
	if ( x.getX() < min_xyz ) { min_xyz = x.getX(); }
	if ( x.getX() > max_xyz ) { max_xyz = x.getX(); }
	if ( y.getX() < min_xyz ) { min_xyz = y.getX(); }
	if ( y.getX() > max_xyz ) { max_xyz = y.getX(); }
	if ( z.getX() < min_xyz ) { min_xyz = z.getX(); }
	if ( z.getX() > max_xyz ) { max_xyz = z.getX(); }

	if ( u.getX() < min_uvw ) { min_uvw = u.getX(); }
	if ( u.getX() > max_uvw ) { max_uvw = u.getX(); }
	if ( v.getX() < min_uvw ) { min_uvw = v.getX(); }
	if ( v.getX() > max_uvw ) { max_uvw = v.getX(); }
	if ( w.getX() < min_uvw ) { min_uvw = w.getX(); }
	if ( w.getX() > max_uvw ) { max_uvw = w.getX(); }

	/*
	  System.out.println("min_xyz: " + min_xyz + ", max_xyz: " + max_xyz +
	  "min_uvw: " + min_uvw + ", max_uvw: " + max_uvw );
	*/


	if ( min_xyz < min_uvw ) {
	    // Triangle XYZ goes on the left
	    // System.out.println("XYZ goes on the left");
	    delta = max_xyz - min_uvw;
	    gap = (max_xyz - min_xyz) * 2 * 0.2;
	    u.setX( u.getX() + delta + gap );
	    v.setX( v.getX() + delta + gap );
	    w.setX( w.getX() + delta + gap );
	    u.setLx( u.getLx() + delta + gap );
	    v.setLx( v.getLx() + delta + gap );
	    w.setLx( w.getLx() + delta + gap );
	} else {
	    // Triangle UVW goes on the left
	    // System.out.println("UVW goes on the left");
	    delta = max_uvw - min_xyz;
	    gap = (max_uvw - min_uvw) * 2 * 0.2;
	    x.setX( x.getX() + delta + gap );
	    y.setX( y.getX() + delta + gap );
	    z.setX( z.getX() + delta + gap );
	    x.setLx( x.getLx() + delta + gap );
	    y.setLx( y.getLx() + delta + gap );
	    z.setLx( z.getLx() + delta + gap );
	}
    }

    void readMinMax() {

	max_x = 0;
	max_y = 0;
	min_x = Double.MAX_VALUE;
	min_y = Double.MAX_VALUE;

	Enumeration points = getPoints();
	while ( points.hasMoreElements() ) {
	    GpPoint p = (GpPoint)points.nextElement();
	    if ( p.getX() < min_x ) { min_x = p.getX(); }
	    if ( p.getX() > max_x ) { max_x = p.getX(); }
	    if ( p.getY() < min_y ) { min_y = p.getY(); }
	    if ( p.getY() > max_y ) { max_y = p.getY(); }
	}
    }

    // Reallocate points to new XY-coordinates <newXY>, which is a '$'
    // separated list of "NAME X Y Lx Ly"
    void changeXY( String newXYcoordinates ) {

	StringTokenizer items = new StringTokenizer( newXYcoordinates, "$" );
	while ( items.hasMoreTokens() ) {
	    String newXY = items.nextToken();

	    // System.out.println("newXY: " + newXY);

	    StringTokenizer newXYtoken = new StringTokenizer( newXY );
	    String name = newXYtoken.nextToken();
	    String x = newXYtoken.nextToken();
	    String y = newXYtoken.nextToken();
	    String lx = newXYtoken.nextToken();
	    String ly = newXYtoken.nextToken();

	    /*
	      System.out.println("name: " + name + ", x: " + x + ", y: " + y
	      + ", lx: " + lx + ", ly: " + ly );
	    */
	    
	    GpPoint p = lookupPointByLabel( name );
	    p.moveTo( Double.parseDouble( x ),
		      Double.parseDouble( y ),
		      Double.parseDouble( lx ),
		      Double.parseDouble( ly ) );
	}
    }

    /**
     *	Translate a string representing LISP number into a real number
     */
    double stringToDouble( String num ) {
	
	if ( num.indexOf( (int)'/' ) == -1 )
	    return new Double( num ).doubleValue();
	else {
	    int idx = num.indexOf( (int)'/' );
	    int numerator, denominator;
	    
	    // System.out.println( "index: " + idx );
	    
	    numerator = Integer.valueOf(num.substring(0, idx)).intValue();
	    denominator = Integer.valueOf(num.substring(idx + 1)).intValue();
	    
	    // System.out.println( numerator + " / " + denominator );
	    
	    return ((double)numerator) / ((double)denominator);
	}
    }
    
} // end of Figure
