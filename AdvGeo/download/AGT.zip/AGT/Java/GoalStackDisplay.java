/**
 * GoalStackDisplay.java
 *
 *	Provide interactive goal-subgoal tree
 *
 * Created: Fri May 09 14:52:30 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id$
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

public class GoalStackDisplay extends JPanel implements MouseMotionListener, MouseListener, ComponentListener {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // size of the diaplay pane
    private int width = 300;
    private int height = 500;

    // Must define following variable and method to get the window
    // displayed in a desired size.
    private Dimension preferredSize = new Dimension( width, height );

    public Dimension getPreferredSize() {
	return preferredSize;
    }

    // A node that is selected to move
    private Node movingNode;
    // Distance between the target location and mouse press
    private double x_target_offset, y_target_offset;
    // A source node of the link that is about to be made
    private Node linkingNode = null;

    public setLinkingNode( Node node ) {
	linkingNode = node;
    }

    // Node type used in addNode()
    public static final int GOAL_NODE = 1;
    public static final int OPERATOR_APPLICATION_NODE = 2;

    // A bag of goals displayed
    private Vector treeNodes = new Vector();
    // Get an enumerator of the treeNodes
    Enumeration getTreeNodes() {
	return treeNodes.elements();
    }

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public GoalStackDisplay (){

	Border raisedBevel = BorderFactory.createRaisedBevelBorder();
	Border loweredBevel = BorderFactory.createLoweredBevelBorder();
	Border compound =
	    BorderFactory.createCompoundBorder( raisedBevel, loweredBevel );

	setBorder(compound);
	setBackground( Color.white ); 

	// setLayout( null );
	
	// Mouse listener
	addMouseListener( this );
	addMouseMotionListener( this );
    }

    /* ------------------------------------------------------------
     *	Class methods
     * ------------------------------------------------------------*/

    // Add a new goal node with the <equation> into the goal-node bag
    void addNode( int type, String equation, int x, int y ) {

	// Create a new goal node
	Node newNode = null;
	if ( type == GOAL_NODE) {	    
	    newNode = new GoalNode( equation, x, y );
	} else {
	    newNode = new OperatorApplicationNode( equation, x, y );
	}

	// Add new goalNode into the goal-node bug
	treeNodes.add( newNode );
	// add( newGoalNode );

	System.out.println("new node added: " + newNode.getBounds());
    }

    // Return a goalNode that has <Point> in it
    Node targetNode( Point p ) {

	Enumeration theNodes = getTreeNodes();
	while ( theNodes.hasMoreElements() ) {
	    Node node = (Node)theNodes.nextElement();
	    if ( node.contains( p ) ) {
		return node;
	    }
	} // end of while ()

	return null;
    }

    /**
     * 
     * @param g <description>
     */
    public void paintComponent(Graphics g)
    {
	super.paintComponent(g);

	Enumeration theNodes = getTreeNodes();
	while ( theNodes.hasMoreElements() ) {
	    ((Node)theNodes.nextElement()).drawBody(g);
	} // end of while ()
    }

    /* ------------------------------------------------------------
     *	implementation of java.awt.event.MouseListener interface
     * ------------------------------------------------------------*/

    /**
     *
     * @param e <description>
     */
    public void mouseClicked(MouseEvent e)
    {
	// TODO: implement this java.awt.event.MouseListener method
    }

    /**
     *
     * @param e <description>
     */
    public void mousePressed(MouseEvent e)
    {
	Point p = e.getPoint();
	movingNode = targetNode( p );

	// if a target node is found, record distance between the
	// target node and mous cursor, which is used in
	// mouseDragged()
	if ( movingNode != null) {
	    x_target_offset = p.getX() - movingNode.getX();
	    y_target_offset = p.getY() - movingNode.getY();
	} // end of if ()

	System.out.println("mousePressed: " + movingNode);
    }

    /**
     *
     * @param e <description>
     */
    public void mouseReleased(MouseEvent e)
    {
	movingNode = null;
    }

    /**
     *
     * @param e <description>
     */
    public void mouseEntered(MouseEvent e)
    {
	// TODO: implement this java.awt.event.MouseListener method
    }

    /**
     *
     * @param e <description>
     */
    public void mouseExited(MouseEvent e)
    {
	// TODO: implement this java.awt.event.MouseListener method
    }

    /* ------------------------------------------------------------
     *	implementation of java.awt.event.MouseMotionListener interface
     * ------------------------------------------------------------ */

    /**
     *
     * @param e <description>
     */
    public void mouseDragged(MouseEvent e)
    {
	if ( movingNode != null ) {
	    // the target node must be moved along with the mouse,
	    // hence need x_ and y_target_offset, which is set by
	    // mousePressed()
	    movingNode.setLocation( (int)(e.getX() - x_target_offset),
				    (int)(e.getY() - y_target_offset) );
	    repaint();
	} // end of if ()
    }

    /**
     *
     * @param e <description>
     */
    public void mouseMoved(MouseEvent e)
    {
	if ( linkingNode != null ) {
	    repaint();
	    getGraphics().drawLine( e.getX(), e.getY(),
				    (int)linkingNode.getX(),
				    (int)linkingNode.getY() );
	} // end of if ()
	
	// TODO: implement this java.awt.event.MouseMotionListener method
    }

    /* ------------------------------------------------------------
     *	java.awt.event.ComponentListener interface
     * ------------------------------------------------------------*/

    /**
     *
     * @param e <description>
     */
    public void componentResized(ComponentEvent e)
    {
	// TODO: implement this java.awt.event.ComponentListener method
    }

    /**
     *
     * @param e <description>
     */
    public void componentMoved(ComponentEvent e)
    {
	// TODO: implement this java.awt.event.ComponentListener method
    }

    /**
     *
     * @param e <description>
     */
    public void componentShown(ComponentEvent e)
    {
	repaint();
	// TODO: implement this java.awt.event.ComponentListener method
    }

    /**
     *
     * @param e <description>
     */
    public void componentHidden(ComponentEvent e)
    {
	// TODO: implement this java.awt.event.ComponentListener method
    }

    

    /* ============================================================
     *	A Node class
     * ============================================================*/

    abstract class Node extends Rectangle {
	
	/* ------------------------------------------------------------
	 *	Member variables
	 * ------------------------------------------------------------*/

	// Description of goal
	String equation;
	// Size of strings representing the equation
	int labelWidth = -1;
	int labelHeight = -1;
	// Amount of margin around the label
	int X_MARGIN = 20;
	int Y_MARGIN = 10;

	void setLabelSize( Graphics g ) {

	    Graphics2D g2 = (Graphics2D) g;
	    FontMetrics metrics = g2.getFontMetrics();

	    labelWidth = metrics.stringWidth( equation );
	    labelHeight = metrics.getHeight();

	    setSize( labelWidth + (X_MARGIN * 2),
		     labelHeight + (Y_MARGIN * 2) );
	}

	/* ------------------------------------------------------------
	 *	Constructor
	 * ------------------------------------------------------------*/

	// New goal node with <equation> located at <X,Y>
	public Node( String equation, int x, int y ) {

	    super( new Point(x, y) );
	    this.equation = equation;
	    System.out.println("x = " + this.x + " y = " + this.y);
	}

	/* ------------------------------------------------------------
	 *	Member methods
	 * ------------------------------------------------------------*/

	/**
	 * draw a node
	 */
	public void drawBody( Graphics g ) {
	    System.out.println("You must define drawBody method");
	}
    }

    /* ============================================================
     *	Goal Node
     * ============================================================*/

    class GoalNode extends Node {

	/* --------------------------------------------------
	 *	Construction
	 * --------------------------------------------------*/
	GoalNode( String equation, int x, int y ) {
	    super( equation, x, y );
	}

	/* --------------------------------------------------
	 *	methods
	 * --------------------------------------------------*/

	public void drawBody( Graphics g ) {
	    // if the labelWidth and labelHeight never get the value,
	    // set them
	    if ( labelWidth == -1 ) {
		setLabelSize(g);
	    }
	    g.drawString( equation, x + X_MARGIN, y + labelHeight + Y_MARGIN );
	}
    }

    /* ============================================================
     *	Operator Application Node
     * ============================================================ */

    class OperatorApplicationNode extends GoalNode {

	/* --------------------------------------------------
	 *	Constructor
	 * --------------------------------------------------*/

	public OperatorApplicationNode( String equation, int x, int y ) {
	    super( equation, x, y );
	}

	/* --------------------------------------------------
	 *	methods
	 * --------------------------------------------------*/

	public void drawBody( Graphics g ) {
	    super.drawBody( g );
	    g.drawRect( x, y, (int)getWidth(), (int)getHeight() );
	}
    }

} // end of GoalStackDisplay.java
