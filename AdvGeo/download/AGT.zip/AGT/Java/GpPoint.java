/**
 * GpPoint.java
 *
 *	The Points in a configuration
 *
 * Created: Sat May 11 16:05:45 2002
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: GpPoint.java 1.1 2003/05/07 22:05:39 NoboruM Exp NoboruM $
 */

import java.awt.*;

public class GpPoint {

    //-
    //-	Member variables - - - - - - - - - - - - - - - - - - - - 
    //- 

    // xy-coordinates of the point
    private double x, y;
    public double getX() { return x; }
    public void setX(double  v) { this.x = v; }
    public double getY() { return y; }
    public void setY(double  v) { this.y = v; }

    // xy-coordinates of the label
    private double lx, ly;
    public double getLx() { return lx; }
    public void setLx(double  v) { this.lx = v; }
    public double getLy() { return ly; }
    public void setLy(double  v) { this.ly = v; }

    // Label
    private String label;
    public String getLabel() { return label; }
    public void setLabel(String  v) { this.label = v; }

    // default offset of the label name wrt the point
    final int LABEL_OFFSET = 5;

    // A distance in which two points are condisered to be identical
    final double EPSILON = 10;

    //-
    //-	Constructor - - - - - - - - - - - - - - - - - - - -
    //- 

    public GpPoint ( double x, double y, String l, double lx, double ly ) {

	/*
	if ((lx == 0.0) && (ly == 0.0)) {
	    lx = x + LABEL_OFFSET;
	    ly = y + LABEL_OFFSET;
	}
	*/
	
	/*
	System.out.println("Point " + l +
			   "(" + x + ", " + y + ", " + lx + ", " + ly + ")" );
	*/

	setX( x );
	setY( y );
	setLx( lx );
	setLy( ly );
	setLabel( l );
    }
    
    //-
    //-	Methods - - - - - - - - - - - - - - - - - - - - - - - - -
    //- 
    
    // Move the point to a new place
    public void moveTo( double x, double y ) {
	moveTo( x, y, x + LABEL_OFFSET, y + LABEL_OFFSET );
    }

    void moveTo( double x, double y, double lx, double ly ) {
	this.x = x;
	this.y = y;
	this.lx = lx;
	this.ly = ly;
    }

    // Test if a specified point is close enough to this point.  
    public boolean isInNeighbor( Point p ) {

	double d = p.distance( getX(), getY() );
	// System.out.println("isInNeighbor: d = " + d);
	return ( d < EPSILON? true : false );
    }
}

//
// end of GpPoint
// 
