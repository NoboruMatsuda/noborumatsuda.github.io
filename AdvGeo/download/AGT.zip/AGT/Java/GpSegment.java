/**
 * GpSegment.java
 *
 *	The segments in a configuration
 *
 * Created: Sun May 12 21:43:38 2002
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: GpSegment.java 1.1 2003/05/07 22:05:52 NoboruM Exp NoboruM $
 */

public class GpSegment {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // End points
    private GpPoint endp1, endp2;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public GpSegment(GpPoint endp1, GpPoint endp2) {

	this.endp1 = endp1;
	this.endp2 = endp2;
    }

    /* ------------------------------------------------------------
     *	Access Methods
     * ------------------------------------------------------------*/

    public GpPoint[] getEndpoints() {

	GpPoint[] endpoints = new GpPoint[2];
	endpoints[0] = endp1;
	endpoints[1] = endp2;

	return endpoints;
    }

    String getName() {

	String l1 = endp1.getLabel();
	String l2 = endp2.getLabel();

	return ( l1.compareTo( l2 ) < 0 ? l1 + l2 : l2 + l1 );
    }

}// GpSegment
