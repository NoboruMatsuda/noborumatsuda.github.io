/**
 * InferenceStep.java
 *
 *	Inference Step window
 *
 * Created: Mon Sep 29 12:17:07 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: InferenceStep.java 1.1 2003/09/29 12:55:59 NoboruM Exp NoboruM $
 */

import java.util.*;
import java.awt.*;
import javax.swing.*;

public class InferenceStep extends MyInternalFrame {

    //-
    //- Fields - - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    // Title of this window
    static String theTitle = "Inference Steps";

    // The content pane
    JPanel contentPane;

    // A bag of inference pane
    Vector /* JPanel */ inferencePanes = new Vector();

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     *	The Tabbed pane holding inference panes
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    JTabbedPane tabbedPane;

    InferencePane currentPane;
    void setCurrentPane( InferencePane pane ) { currentPane = pane; }
    InferencePane getCurrentPane() { return currentPane; }

    //-
    //- Constructor - - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    public InferenceStep( Dimension size, Point location ) {

	super( theTitle,
	       false,		// resizable
	       false,		// closable
	       false,		// maximizable
	       false		// iconifiable
	       );
	
	//System.out.println("size: " + size + ", location: " + location );
	
	setPreferredSize( size );
	setLocation( location );

	// Create the content pane
	contentPane = new JPanel();
	contentPane.setSize( size );
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	// Set up forward and backward inference panes
	tabbedPane = new JTabbedPane();
	contentPane.add( tabbedPane );
	
	/*
	System.out.println("inferencePaneSize before pack() -> " +
			   getInferencePaneSize() );
	*/
	
	// Shape up the window
	pack();
	setVisible( true );

	/*
	System.out.println("inferencePaneSize after pack() -> " +
			   getInferencePaneSize() );
	*/
    }
    
    //-
    //- Methods - - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    // Create a new InferencePane and add it to the tabbedPane
    public void newInferencePane() {

	InferencePane newPane = new InferencePane( new JPanel() );
	inferencePanes.add( newPane );
	setCurrentPane( newPane );
	tabbedPane.addTab( "New step", null, newPane, "New proof step" );
	tabbedPane.setSelectedComponent( newPane );
    }

    // Insert an inference step named <step> as a child of <parent>
    // with the <text> as a label string.  <offset> is a position of
    // this step as a substep of parent step
    public void insertStep( String stepName, String label, String parentName,
			    int lptID, int offset ) {

	getCurrentPane().insertStep( stepName, label, parentName,
				     lptID, offset );
	getFocused();
    }

    // Add a new inferenceStep at the end of the inferenceSteps
    public void addStep( String stepName, String label, String parentName,
			 int lptID ) {
	getCurrentPane().addStep( stepName, label, parentName, lptID );
    }

    // Set a title onto the current tab
    public void setTabTitle( String title ) {

	int index = tabbedPane.indexOfComponent( getCurrentPane() );
	tabbedPane.setTitleAt( index, title );
    }

    // Replace a single-line description of an inference step
    public void updateDescription( String stepName, String description ) {

	getFocused();
	getCurrentPane().updateDescription( stepName, description );
    }
    
    public void clearSteps() {
	getCurrentPane().clearSteps();
    }

    public void highlightStepLabel( String stepName ) {

	Step step = getCurrentPane().lookupInferenceStepByName( stepName );
	step.highlightLabel();
    }

    public void cancelHighlightStepLabel( String stepName ) {
	Step step = getCurrentPane().lookupInferenceStepByName( stepName );
	step.cancelHighlightLabel();
    }

    public void stepMarkerOn( String stepName ) {
	Step step = getCurrentPane().lookupInferenceStepByName( stepName );
	step.markerOn();
    }

    public void stepMarkerOff( String stepName ) {
	Step step = getCurrentPane().lookupInferenceStepByName( stepName );
	step.markerOff();
    }

    Dimension getInferencePaneSize() {

	Dimension contentSize = getContentPane().getSize();
	return new Dimension( (int)(contentSize.width * .95 ),
			      (int)(contentSize.height * .80 ) );
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     *	CLASS InferencePane
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    class InferencePane extends JScrollPane {
	
	//-
	//-	Fields - - - - - - - - - - - - - - - - - - - - - - - - - 
	//-

	Vector /* Step */ inferenceSteps = new Vector();
	JPanel thePanel;

	//-
	//-	Constructor - - - - - - - - - - - - - - - - - - - - 
	//-

	public InferencePane( JPanel pane ) {

	    super( pane );
	    setPreferredSize( getInferencePaneSize() );

	    thePanel = pane;
	    thePanel.setBackground( Color.white );
	    thePanel.setLayout( new BoxLayout( thePanel, BoxLayout.Y_AXIS ) );
	}

	//-
	//-	Methods - - - - - - - - - - - - - - - - - - - - - - - - - 
	//-

	public void updateDescription( String stepName, String description ) {
	    Step step = lookupInferenceStepByName( stepName );
	    step.updateDescription( description );
	}

	void addStep( String stepName, String label, String parentName,
		      int lptID ) {

	    Step parentStep = lookupInferenceStepByName( parentName );

	    int indentLevel = 0;
	    if ( parentStep != null ) {
		indentLevel = parentStep.getIndentLevel() +1;
	    }
	    
	    Step inferenceStep =
		new Step( stepName, label, indentLevel, lptID );

	    insertStepAt( inferenceStep, inferenceSteps.size() );
	}

	public void insertStep( String stepName, String label,
				String parentName, int lptID, int offset ) {
	
	    int indentLevel = 0;
	    Step parentStep = lookupInferenceStepByName( parentName );

	    /*
	    System.out.println("insertStep: " + stepName + ", " + parentName);
	    System.out.println("parent index = " +
			       inferenceSteps.indexOf( parentStep ));
	    */

	    if ( parentStep != null ) {
		indentLevel = parentStep.getIndentLevel() +1;
	    }
	
	    Step inferenceStep =
		new Step( stepName, label, indentLevel, lptID );
				       
	    if ( parentStep == null ) {
		insertStepAt( inferenceStep, 0 );
	    } else {
		int index = inferenceSteps.indexOf( parentStep ) + 1;
		insertStepAt( inferenceStep, index + offset );
	    }
	}

	// Insert a <step> just below <index>
	void insertStepAt( Step step, int index ) {
	    
	    // Register the <step> into the inferenceSteps vector
	    addInferenceStepAt( step, index );

	    // Add the Step to the inference tab
	    if ( index == 0 )
		thePanel.add( step );
	    else
		thePanel.add( step, index );

	    thePanel.revalidate();
	}

	void clearSteps() {
	    thePanel.removeAll();
	    inferenceSteps = new Vector();
	}

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	A bag of inference steps
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	// Add <step> into inferenceSteps Vector
	void addInferenceStepAt( Step step, int index ) {
	    if ( index == 0 )
		inferenceSteps.add( step );
	    else
		inferenceSteps.insertElementAt( step, index );
	}

	// Returns an inference step with the specified name
	Step lookupInferenceStepByName( String name ) {

	    for (int i = 0; i < inferenceSteps.size(); i++) {
		Step theStep = (Step)inferenceSteps.elementAt(i);
		if ( theStep.getName().equals( name ) )
		    return theStep;
	    }
	    return null;
	}
    }
}

//
// end of $RCSfile: InferenceStep.java $
//
