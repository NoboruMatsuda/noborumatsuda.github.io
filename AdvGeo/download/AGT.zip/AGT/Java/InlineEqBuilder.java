/**
 * InlineEqBuilder.java
 *
 *	An equation builder that appeared just in the place where the
 *	equation is supposed to be entered
 *
 * Created: Mon Apr 05 11:51:13 2004
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id$
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class InlineEqBuilder extends JPanel {

    //-
    //-	Fields
    //-

    // A name of the component that holds the Inline Equation Builder
    String holder;
    public String getHolder() { return holder; }
    public void setHolder(String newHolder) { this.holder = newHolder; }

    // A list of equations students can compose
    JComboBox eqSelector;

    // Labels on the buttons followed by tool tip texts.  Do not try
    // to delete or reorder the labels for they are used everywhere in
    // this module in the way that the order matters.  
    String validEquations[][] = { {"select proposition", ""},
				  {"�ځQ���ځQ", "Angle equality"},
				  {"�Q���Q", "Segment equality"},
				  {"���Q�߁��Q", "Triangle congruence"},
				  {"�Q//�Q", "Segment parallel"} };
    
    // A compound of symbols and labels that consists of an equation
    EqField eqField;

    // A menu button
    // Icon menuButtonIcon = new ImageIcon( "img/menuButton.gif" );
    // JButton menuButton = new JButton( menuButtonIcon );
    JButton menuButton = new JButton( ">" );
    MenuButtonActionListener menuButtonAL = new MenuButtonActionListener();

    // A popup menu
    JPopupMenu popupMenu = new JPopupMenu();
    // String popupMenuItems[] = { "Discard", "Done" };
    String popupMenuItems[] = { "Discard" };

    // Type of equation
    final int ANG_EQ = 1;	// Angle equality
    final int SEG_EQ = 2;	// Segment equality
    final int TRI_CONG = 3;	// Triangle congruence
    final int SEG_PARA = 4;	// Segment parallel

    // Tue May 11 23:04:27 2004
    // A list of valid points, which can be used in an equation
    Vector /* String */ validPoints = new Vector();
    Vector getValidPoints() { return validPoints; }
    // <points> must be a space separated list of point names
    void setValidPoints( String points ) {
	validPointNames = points;
	validPoints = new Vector();
	if ( !points.equals( "" ) ) {
	    StringTokenizer thePoints = new StringTokenizer( points );
	    while ( thePoints.hasMoreTokens() ) {
		validPoints.add( thePoints.nextToken() );
	    }
	}
    }
    String validPointNames = "";
    String getValidPointNames() { return validPointNames; }

    //-
    //-	Constructor - - - - - - - - - - - - - - - - - - - - 
    //-

    public InlineEqBuilder() {

	initPopupMenu();

	eqSelector = new JComboBox();
	eqSelector.setFont( AGT.getDisplayFont14() );
	for ( int i = 0; i < validEquations.length; i++ ) {
	    eqSelector.addItem( validEquations[i][0] );
	}
	eqSelector.addActionListener( new EqSelectorActionListener() );

	FlowLayout layout = (FlowLayout)getLayout();
	layout.setAlignment( FlowLayout.LEFT );

	add( eqSelector );
	setBackground( Color.yellow );
    }

    public InlineEqBuilder( String holder ) {
	this();
	setHolder( holder );
    }

    //-
    //-	Method - - - - - - - - - - - - - - - - - - - -
    //-

    // Called when the user selects an equation type from seSelector
    void composeEquation( int eqType ) {

	// Take the equation selector away
	remove( eqSelector );
	// revalidate();

	// Add an EqField and the nemu button
	eqField = new EqField( eqType );
	add( eqField );

	// menuButton.setMaximumSize( new Dimension( 10, 0 ) );
	// Image img = Toolkit.getDefaultToolkit().getImage( "img/menuButton.gif" );
	// Icon icon = new ImageIcon( img );
	// menuButton = new JButton( icon );

	// menuButtonIcon = new ImageIcon( "img/menuButton.gif" );
	// menuButton = new JButton( menuButtonIcon );

	menuButton.setToolTipText( "Popup menu" );
	// menuButton.setPreferredSize( new Dimension( 20, 20 ) );
	menuButton.setMargin( new Insets( 0, 0, 0, 0 ) );
	// menuButton.setBackground( Color.white );
	menuButton.addActionListener( menuButtonAL );
	add( menuButton );
	
	revalidate();
	eqField.grabInputFocus();
    }

    // initialize popup menu
    void initPopupMenu() {

	PopupMenuActionListener popupMenuAL = new PopupMenuActionListener();

	for (int i = 0; i < popupMenuItems.length; i++) {
	    JMenuItem menuItem = new JMenuItem( popupMenuItems[i] );
	    menuItem.addActionListener( popupMenuAL );
	    popupMenu.add( menuItem );
	}
    }

    // reset the builder
    void reset() {
	discardComposition();
    }

    // Avandon current composition and start over from the beginning
    void discardComposition() {
	remove( menuButton );
	remove( eqField );
	eqSelector.setSelectedIndex( 0 );
	add( eqSelector );
	revalidate();
	repaint();
    }

    // Verify inputs and finlize composition
    void completeComposition() {
	
	if ( eqField.gotValidInput() ) {
	    String equation = eqField.getEquation();
	    System.out.println("Equation: " + equation);

	    ComManager comManager = AGT.getComManager();
	    String methodCall = "<feedFromInlineEquationBuilder><String>";
	    methodCall += "\"" + equation + "\"";
	    methodCall += "</String></feedFromInlineEquationBuilder>";
	    
	    comManager.dispatch( getHolder(), methodCall );
	}
    }

    /* ------------------------------------------------------------
     *	EqField class
     * ------------------------------------------------------------ */

    class EqField extends JPanel {

	int eqType;
	public int getEqType() { return eqType; }
	public void setEqType(int newEqType) { this.eqType = newEqType; }

	// A Symbol that represents geometric objects that the
	// equation is referring to (e.g., ��,��, etc)
	String geoSymbol; 

	// A symbol that represents the relation among the geometric
	// objects involved in the equation (e.g., ��,��, //, etc)
	String relationSymbol;

	// Number of geometric elements involved
	int arity;

	// Text field to enter labels
	JTextField arg1 = new JTextField();
	JTextField arg2 = new JTextField();
	final int textLength = 3;
	EqFieldActionListener eqFieldAL = new EqFieldActionListener();

	//-
	//-	Constructor - - - - - - - - - - - - - - - - 
	//-

	public EqField( int eqType ) {

	    setEqType( eqType );

	    initSymbols( eqType );
	    arg1.setColumns( textLength );
	    arg1.addActionListener( eqFieldAL );
	    arg2.setColumns( textLength );
	    arg2.addActionListener( eqFieldAL );
	    
	    JLabel geoSymbolLabel1 = new JLabel( geoSymbol );
	    geoSymbolLabel1.setFont( AGT.getDisplayFont14() );
	    JLabel geoSymbolLabel2 = new JLabel( geoSymbol );
	    geoSymbolLabel2.setFont( AGT.getDisplayFont14() );
	    JLabel relationSymbolLabel = new JLabel( relationSymbol );
	    relationSymbolLabel.setFont( AGT.getDisplayFont14() );

	    add( geoSymbolLabel1 );
	    add( arg1 );
	    add( relationSymbolLabel );
	    add( geoSymbolLabel2 );
	    add( arg2 );
	}

	//-
	//-	Method - - - - - - - - - - - - - - - - - - - - 
	//-

	void initSymbols( int eqType ) {

	    switch ( eqType) {
	    case SEG_EQ:
		arity = 2;
		geoSymbol = "";
		relationSymbol = "��";
		break;
		
	    case  ANG_EQ:
		arity = 2;
		geoSymbol = "��";
		relationSymbol = "��";
		break;
		
	    case  TRI_CONG:
		arity = 2;
		geoSymbol = "��";
		relationSymbol = "��";
		break;
		
	    case  SEG_PARA:
		arity = 2;
		geoSymbol = "";
		relationSymbol = "//";
		break;
	    }
	}

	// Return true if the composition is valid, namely, both
	// arguments gets value
	boolean gotValidInput() {

	    boolean messageProvided = false;
	    boolean isValid = true;
	    String str1 = arg1.getText();
	    String str2 = arg2.getText();

	    if ( str1.equals("") ) {
		FatalMessage fatalMessage = AGT.getFatalMessage();
		String msg = "Enter labels for the first element.";
		fatalMessage.display( msg );
		messageProvided = true;
		isValid = false;
	    }

	    if ( str2.equals("") ) {
		if ( !messageProvided ) {
		    FatalMessage fatalMessage = AGT.getFatalMessage();
		    String msg = "Enter labels for the second element.";
		    fatalMessage.display( msg );
		    messageProvided = true;
		}
		isValid = false;
	    }

	    switch ( getEqType() ) {
	    case SEG_EQ:
	    case SEG_PARA:
		if ( str1.length() != 2 || str2.length() != 2 ) {
		    if ( !messageProvided ) {
			FatalMessage fatalMessage = AGT.getFatalMessage();
			String msg = "You have selected segment " + 
			    (getEqType() == SEG_EQ ? "equality" : "parallel") +
			    ".  A segment must have exactly two letters.";
			fatalMessage.display( msg );
			messageProvided = true;
		    }
		    isValid = false;
		}
		break;
		
	    case TRI_CONG:
	    case ANG_EQ:
		if ( str1.length() != 3 || str2.length() != 3 ) {
		    if ( !messageProvided ) {
			FatalMessage fatalMessage = AGT.getFatalMessage();
			String msg = "You have selected " +
			    (getEqType() == TRI_CONG ?
			     "triangle congruence" :
			     "equal angles" ) +
			    ".  They must have exactly three letters.";
			fatalMessage.display( msg );
			messageProvided = true;
		    }
		    isValid = false;
		}
		break;
	    }

	    if ( isValid )
		for (int i = 0; i < str1.length(); i++)
		    if ( !isValidPointName( "" + str1.charAt(i) ) ||
			 !isValidPointName( "" + str2.charAt(i) ) ) {
			isValid = false;
			FatalMessage fatalMessage = AGT.getFatalMessage();
			String msg =
			    "You can only use " + getValidPointNames();
			fatalMessage.display( msg );
			break;
		    }

	    return isValid;
	}

	boolean isValidPointName( String name ) {

	    boolean validity = getValidPoints().isEmpty();

	    if ( validity != true ) {
		for (int i = 0; i < getValidPoints().size(); i++) {
		    String label = (String)getValidPoints().elementAt(i);
		    if ( label.toUpperCase().equals( name.toUpperCase() ) ) {
			validity = true;
			break;
		    }
		}
	    }
	    return validity;
	}

	String getEquation() {

	    String equation = "(";

	    switch ( getEqType() ) {
	    case SEG_EQ:
	    case ANG_EQ:
		equation += ":EQ ";
		break;
		
	    case TRI_CONG:
		equation += ":CONG ";
		break;
		
	    case SEG_PARA:
		equation += ":PARALLEL "; 
		break;
	    }

	    equation += decode( arg1.getText() ) + decode( arg2.getText() );
	    equation += ")";

	    return equation;
	}

	String decode( String arg ) {

	    String equation = "(";

	    switch ( getEqType() ) {
	    case SEG_EQ:
	    case SEG_PARA:
		equation += ":S";
		break;
		
	    case ANG_EQ:
		equation += ":A";
		break;
		
	    case TRI_CONG:
		equation += ":TRIANGLE";
		break;
	    }

	    // (:triangle (:P X) (:P Y) (:P Z))
	    // (:S X Y) (:A U V X)
	    for (int i = 0; i < arg.length(); i++) {
		if ( getEqType() == TRI_CONG )
		    equation += " (:P " + arg.charAt(i) + ")";
		else
		    equation += " " + arg.charAt(i);
	    }
	    equation += ")";

	    return equation;
	}

	void grabInputFocus() {
	    arg1.grabFocus();
	}
    }

    /* ------------------------------------------------------------
     *	Action Listerer for Popup Menu
     * ------------------------------------------------------------ */

    class PopupMenuActionListener implements ActionListener {

	public void actionPerformed(ActionEvent actionEvent) {

	    JMenuItem source = (JMenuItem)actionEvent.getSource();
	    String command = source.getText();
	    // System.out.println("Popup Menu: " + source.getText());

	    if ( command.equals( popupMenuItems[0] ) ) {

		// "Discard"
		discardComposition();
		
	    } else if ( command.equals( popupMenuItems[1] ) ) {
		
		// "Done"
		completeComposition();
	    }
	}
    }

    /* ------------------------------------------------------------
     *	Action Listener for MenuButton
     * ------------------------------------------------------------ */

    class MenuButtonActionListener implements ActionListener {

	public void actionPerformed(ActionEvent actionEvent) {
	    
	    popupMenu.show( menuButton, menuButton.getWidth(), 0 );
	}
    }

    /* ------------------------------------------------------------
     *	Action Listener for EqField
     * ------------------------------------------------------------ */

    class EqFieldActionListener implements ActionListener {

	public void actionPerformed(ActionEvent actionEvent) {
	    completeComposition();
	}
    }

    /* ------------------------------------------------------------
     *	Action Listener for EqSelector
     * ------------------------------------------------------------ */
    
    class EqSelectorActionListener implements ActionListener {
	
	public void actionPerformed(ActionEvent e) {

	    String eqName = (String)eqSelector.getSelectedItem();

	    System.out.println( "InlineEqBuilder: comboBox action " + eqName );

	    for (int i = 1; i <= 4; i++) {
		if ( eqName.equals( validEquations[i][0] ) )
		    composeEquation( i );
	    }
	}
    }
}

//
// end of $RCSfile$
// 
