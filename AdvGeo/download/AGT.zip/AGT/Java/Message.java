/**
 * Message.java
 *
 *
 * Created: Wed Oct 01 11:57:31 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: Message.java 1.1 2003/11/18 21:11:34 NoboruM Exp NoboruM $
 */

// import java.beans.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Message extends MyInternalFrame {

    //-
    //-	Fields * * * * * * * * * * * * * * * * * * * * * * * * * 
    //-

    // Title of the window
    static String theTitle = "Message Window";
    // Font
    // Font messageFont = new Font( "Times New Roman", Font.PLAIN, 16 );
    // Font messageFont = new Font( "MS UI Gothic", Font.PLAIN, 18 );
    Font messageFont = AGT.getDisplayFont();
    // Margin
    Insets messageMargin = new Insets( 10, 10, 10, 10 );
    // Height of the button area
    int TOOLBAR_HEIGHT = 38;

    // The content pane
    JPanel contentPane;

    // Bag of messages
    Vector /* MessagePane */ messagePool = new Vector();
    // The position of the current message in messagePool
    int messageIndex = 0;

    // The message pane that is displayed on the Message window
    static MessagePane theMessagePane;
    static MessagePane getMessagePane() { return theMessagePane; }
    void setMessagePane( MessagePane mPane ) {

	// Remove the old messagePane
	if ( getMessagePane() != null )
	    getContentPane().remove( getMessagePane() );

	// Set new message pane
	theMessagePane = mPane;
	getContentPane().add( mPane );
	pack();
    }

    String currentMessage;
    JTextArea currentMessageArea;
    public JTextArea getCurrentMessageArea() { return currentMessageArea; }
    public void setCurrentMessageArea(JTextArea newCurrentMessageArea) {
	this.currentMessageArea = newCurrentMessageArea;
    }

    // The initial message
    String initialText = "";

    // Message Option Types
    // No button, no text field.  Just message
    static final int NO_OPTION = 1;
    // Single [OK] button
    static final int OK_OPTION = 2;
    // Text field to input a string
    static final int INPUT_OPTION = 3;
    // Disabled [OK] button at the beginning
    static final int OK_OPTION_AT_INPUT = 4;
    // Binary radio buttons for a yes-no question
    static final int YES_NO = 5;
    // Multiple choice
    static final int MULTIPLE_CHOICE = 6;
    // Input Equations with the InlineEqBuilder
    static final int INLINE_EQ_INPUT = 7;

    Vector /* String */ selectionItems = new Vector();
    Vector getSelectionItems() { return selectionItems; }
    void addSelectionItems( String item ) { selectionItems.add( item ); }
    void setSelectionItems(Vector newSelectionItems) {
	this.selectionItems = newSelectionItems;
    }

    // Strings input in the text field
    String inputText = "X";
    public String getInputText() { return inputText; }
    public void setInputText(String newInputText) {
	this.inputText = newInputText;
    }
    final int INPUT_FIELD_LEN = 50;
    final String INPUT_ACTION_COMMAND = "input field";

    /*
      // [OK] button
      JButton theOkeyButton;
      public JButton getTheOkeyButton() { return theOkeyButton; }
      public void setTheOkeyButton(JButton newTheOkeyButton) {
      this.theOkeyButton = newTheOkeyButton;
      }
      final String OK_ACTION_COMMAND = "ok button";
    */

    // The Inline EquBuilder will call feedFromInlineEqBuilder method
    // when an input is completed
    InlineEqBuilder inlineEqB = new InlineEqBuilder( "Message" );
    // Number of equations fed by Equation Builder
    int numEquationFed = 0;
    String validPointNames = "";

    // Is the input fed by Equation builder?
    boolean fedByEquationBuilder = false;
    public boolean isFedByEquationBuilder() { return fedByEquationBuilder; }
    public void setFedByEquationBuilder(boolean newFedByEquationBuilder) {
	this.fedByEquationBuilder = newFedByEquationBuilder;
    }

    // Flag to make Message Window modal
    boolean messageRead = false;
    public boolean isMessageRead() { return messageRead; }
    public void setMessageRead(boolean newMessageRead) {
	this.messageRead = newMessageRead;
    }

    // For a message type OK_OPTION_AT_INPUT where the input is fed by
    // other component, this flag indicates whether the input is fed
    // or not.  The target component must call setInputFed method with
    // its name as an ID
    static boolean inputFed;
    public boolean isInputFed() { return inputFed; }
    public void setInputFed( boolean newInputFed ) {
	this.inputFed = newInputFed;
    }
    static public void setInputFed( boolean newInputFed, String ID ) {
	System.out.println("setInputFed(" + newInputFed + "," + ID + ")");
	if ( getInputSource().equals( ID ) ) {
	    inputFed = newInputFed;
	    getMessagePane().enableForwardButton();
	} else {
	    System.out.println("setInputFed: got an input from " +
			       ID + ", which should be " +
			       getInputSource() );
	}
    }

    // The prospective component for the input for OK_OPTION_AT_INPUT
    // message type
    static String inputSource;
    static public String getInputSource() { return inputSource; }
    public void setInputSource(String newInputSource) {
	this.inputSource = newInputSource;
    }

    //-
    //-	Constructor * * * * * * * * * * * * * * * * * * * * * *
    //- 

    public Message( Dimension size, Point location ) {

	super( theTitle, 
	       false,		// resizable
	       false,		// closing
	       false,		// maximizable
	       false		// iconifiable
	       );

	// System.out.println("Message window size -> " + size);

	setPreferredSize( size );
	setLocation( location );

	/*
	  System.out.println("Message window init contentPane size -> " +
	  getContentPane().getPreferredSize() );
	*/

	// Content pane
	contentPane = new JPanel();
	contentPane.setPreferredSize( size );
	contentPane.setLayout(new BoxLayout( contentPane, BoxLayout.Y_AXIS ));
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	// Initial Message is just displayed, no acknowledge needed.
	newMessagePane( initialText, NO_OPTION );

	// Put things togther
	pack();
	setVisible( true );
    }
    
    //-
    //-	Methods * * * * * * * * * * * * * * * * * * * * * * * * * 
    //- 

    // The time when the message was displayed
    long startDisplay;
    public long getStartDisplay() { return startDisplay; }
    public void setStartDisplay(long newStartDisplay) {
	this.startDisplay = newStartDisplay;
    }

    // Called by LISP backend.  Display <message> and log student's
    // responce.  <items> is a space separated list of items that must
    // be displaied by radio buttons.  <source> specifies the
    // component to which the student input someting (the default is
    // the Message window).
    public void displayMessage( String message, int optionType,
				String items, String source ) {

	// Replace LISP expressions with human friendly math equations
	message = Equation.reformMessage( message );
	message = convertNL( message );

	if ( optionType == YES_NO ) {
	    setSelectionItems( new Vector() );
	    addSelectionItems( "YES" );
	    addSelectionItems( "NO" );
	    optionType = MULTIPLE_CHOICE;
	}

	if ( !items.equals( "" ) ) {

	    System.out.println("displayMessage:: items = " + items);

	    if ( optionType == INLINE_EQ_INPUT ) {
		validPointNames = items;
	    } else {
		StringTokenizer itemToken = new StringTokenizer( items );
		setSelectionItems( new Vector() );
		while ( itemToken.hasMoreTokens() )
		    addSelectionItems( itemToken.nextToken() );
		optionType = MULTIPLE_CHOICE;
	    }
	}

	if ( !source.equals( "" ) ) {
	    setInputSource( source );
	    setInputFed( false );
	}

	newMessagePane( message, optionType );

	// Logging a message opening 
	ComManager comManager = AGT.getComManager();
	String log = "(LOG:WRITE-LOG MESSAGE-OPEN \"" + message + "\")";
	comManager.sendAgtCommand( "Message", log );
	// Measure a time the message has been read 
	setStartDisplay( new Date().getTime() );
	
	// Rest some variables
	setMessageRead( false );
	setFedByEquationBuilder( false );
	numEquationFed = 0;
	setInputText( "" );

	if ( optionType == INPUT_OPTION ) {
	    getMessagePane().grabInputFocus();
	}

	// Wed Mar 17 16:51:32 2004 Because GUI events would happen
	// hereafter (i.e., after displaying message and before the
	// studen click [OK] or complete to input some text, this
	// method must be end here so that mailLoop in comManager can
	// resume its job.  When an expected follow-up event for this
	// method happen (i.e., either clicking [OK] or completing
	// text input, then closeDisplayMessage() is called
    }

    void closeDisplayMessage() {

	long end = new Date().getTime();
	// Logging a message closing
	String log =
	    "(LOG:WRITE-LOG MESSAGE-CLOSED " + (end - getStartDisplay()) + ")";
	ComManager comManager = AGT.getComManager();
	comManager.sendAgtCommand( "Message", log );
    }

    /*
      String convertNL( String message ) {
	
      return message.replaceAll( "\\\\n", "\n" );
      }
    */
    
    String convertNL( String message ) {
	
	String newStr = "";
	int idx = message.indexOf( "\\n" );
	if ( idx != -1 )
	    newStr =
		message.substring(0, idx-1) + "\n" + message.substring(idx+2);
	else
	    newStr = message;

	if ( newStr.indexOf( "\\n" ) != -1 ) {
	    newStr = convertNL( newStr );
	}

	return newStr;
    }

    // Report that OK button is interrupted by voidOkButton()
    void voidDisplayMessage() {

	long end = new Date().getTime();
	// Logging a message closing
	String log =
	    "(LOG:WRITE-LOG MESSAGE-VOID " + (end - getStartDisplay()) + ")";
	ComManager comManager = AGT.getComManager();
	comManager.sendAgtCommand( "Message", log );
    }

    // Compose a new message window with options speficied with
    // <optionType>
    void newMessagePane( String message, int optionType ) {

	MessagePane mPane = new MessagePane( message, optionType );
	
	addMessagePool( mPane );
	setMessagePane( mPane );
    }

    // An equation fed by InlineEquationBuilder
    public void feedFromInlineEquationBuilder( String equation ) {

	// Remove the Inline Equation Builder
	getMessagePane().remove( inlineEqB );
	// Reset the Inline Equation Builder
	inlineEqB.reset();

	// Substitute the equation builder with a plain text equation
	currentMessage += equation + "\n";
	String msg = Equation.reformMessage( currentMessage );
	getCurrentMessageArea().setText( msg );

	// Send the equation to the LIST backend
	ComManager comManager = AGT.getComManager();
	comManager.sendStringInput( "Message", equation );
	
	// Enable forward button
	getMessagePane().forwardButton.setEnabled( true );
    }

    // An equation sent from Postulate Builder (obsolete)
    public void feedFromPostulateBuilder( String equation ) {

	// System.out.println("feedFromPostulateBuilder got " + equation);
	setFedByEquationBuilder( true );
	getMessagePane().forwardButton.setEnabled( true );
	getMessagePane().forwardButton.setText( "DONE" );
	getMessagePane().forwardButton.setBackground( Color.yellow );

	System.out.println("[BEFORE] inputText = " + inputText);

	inputText += equation + " ";
	numEquationFed++;

	System.out.println("[AFTER] inputText = " + inputText);

	currentMessage += equation + "\n";
	String msg = Equation.reformMessage( currentMessage );
	getCurrentMessageArea().setText( msg );
    }

    // Append new message pane into the messagePool and update
    // messageIndex
    void addMessagePool( JPanel messagePane ) {

	// Add the new message pane into the messagePool
	messagePool.add( messagePane );
	messageIndex = messagePool.size() -1;
    }

    // Returns the size of message area which is 90% of the whole frame
    Dimension getMessageAreaSize() {

	// Size of the Content Pane
	Dimension cpSize = getContentPane().getPreferredSize();
	int width = (int)(cpSize.getWidth() * .9);
	int height = (int)((cpSize.getHeight() - TOOLBAR_HEIGHT ) * .9);
	
	/*
	  System.out.println("MessageArea width: " + width
	  + ", height: " + height);
	*/

	return new Dimension( width, height );
    }

    // Pretend that OK button is clicked
    public void voidOkButton() {
	Color buttonBackgroundColor = getMessagePane().buttonBackgroundColor;
	getMessagePane().forwardButton.setBackground( buttonBackgroundColor );
	getMessagePane().forwardButton.setEnabled( false );
	getMessagePane().forwardButton.setText( " >> " );
	voidDisplayMessage();
    }

    /* ----------------------------------------------------------------
     *	CLASS MessagePane
     * ---------------------------------------------------------------- */

    class MessagePane extends JPanel implements ActionListener {

	// ToolBar to proceed (both forwards and backwards) a session
	JButton backButton, forwardButton;
	final String BACKWARD_COMMAND = "back button";
	final String FORWARD_COMMAND = "forward button";

	int optionType;
	public int getOptionType() { return optionType; }
	public void setOptionType(int newOptionType) { 
	    this.optionType = newOptionType;
	}

	ButtonGroup buttonGroup;
	public ButtonGroup getButtonGroup() { return buttonGroup; }
	public void setButtonGroup(ButtonGroup newButtonGroup) {
	    this.buttonGroup = newButtonGroup;
	}

	Color buttonBackgroundColor;

	// Text input box
	JTextField inputField; 

	public MessagePane( String message, int optionType ) {

	    setOptionType( optionType );

	    setLayout( new BoxLayout( this, BoxLayout.Y_AXIS ) );
	    setPreferredSize( getMessageAreaSize() );
	    
	    Dimension maSize = getMessageAreaSize();
	    Dimension minSize = new Dimension( (int)(maSize.width * .9), 0 );

	    // Message texts must be line wrap
	    JTextArea textArea = new JTextArea( message );
	    textArea.setLineWrap( true );
	    textArea.setWrapStyleWord( true );
	    textArea.setMinimumSize( minSize );
	    textArea.setMargin( messageMargin );
	    textArea.setEditable( false );
	    setCurrentMessageArea( textArea );
	    currentMessage = message + "\n\n";
	    add( textArea );
	    
	    // Font
	    // Font textAreaFont = textArea.getFont();
	    // String fontName = textAreaFont.getFontName();
	    // fontName -> "Dialog.plain" 
	    // messageFont = new Font( fontName, Font.PLAIN, 16 );
	    textArea.setFont( messageFont );

	    // For text input option, setup a text input field
	    if ( optionType == INPUT_OPTION ) {
		// for INPUT_OPTION, place a text field at the bottom
		inputField = new JTextField( INPUT_FIELD_LEN );
		inputField.setMargin( messageMargin );
		inputField.setActionCommand( INPUT_ACTION_COMMAND );
		inputField.addActionListener( this );
		add( inputField );
		inputField.grabFocus();
	    }
	    
	    // For a multiple choice option, setup a radio buttons
	    if ( optionType == MULTIPLE_CHOICE ) {
		JPanel selectionPane = new JPanel();
		setButtonGroup( new ButtonGroup() );
		for (int i = 0; i < getSelectionItems().size(); i++) {
		    String item = (String)getSelectionItems().elementAt(i);
		    JRadioButton button = new JRadioButton( item );
		    button.setActionCommand( item );
		    button.addActionListener( this );
		    selectionPane.add( button );
		    getButtonGroup().add( button );
		}
		add( selectionPane );
	    }

	    if ( optionType == INLINE_EQ_INPUT ) {
		inlineEqB.setValidPoints( validPointNames );
		add( inlineEqB );
	    }

	    // finally, setup a toolbar, which holds back and forward
	    // buttons
	    add( newToolBar() );

	    // Enable forward button for an OK_OPTION message
	    if ( optionType == OK_OPTION ) {
		forwardButton.setBackground( Color.yellow );
		forwardButton.setText( " OK " );
		forwardButton.setEnabled( true );
	    }
	    
	    // Enable backward button for not-the-first messages
	    if ( messageIndex != 0 )
		backButton.setEnabled( true );
	}

	JPanel newToolBar () {

	    // Page turn buttons
	    JPanel toolBar = new JPanel();
	    FlowLayout layout = (FlowLayout)toolBar.getLayout();
	    layout.setAlignment( FlowLayout.LEFT );
	    int toolBarWidth = (int)getPreferredSize().getWidth();
	    Dimension toolBarSize =
		new Dimension( toolBarWidth, TOOLBAR_HEIGHT );
	    toolBar.setPreferredSize( toolBarSize );
	    
	    backButton = new JButton( " << " );
	    backButton.setToolTipText( "Back" );
	    backButton.setActionCommand( BACKWARD_COMMAND );
	    backButton.addActionListener( this );
	    backButton.setEnabled( false );
	    
	    forwardButton = new JButton( " >> " );
	    forwardButton.setToolTipText( "Forward" );
	    forwardButton.setActionCommand( FORWARD_COMMAND );
	    forwardButton.addActionListener( this );
	    forwardButton.setEnabled( false );
	    buttonBackgroundColor = forwardButton.getBackground();
	    
	    toolBar.add( backButton );
	    toolBar.add( forwardButton );

	    return toolBar;
	}

	void enableForwardButton() {

	    forwardButton.setBackground( Color.yellow );
	    forwardButton.setText( " OK " );
	    forwardButton.setEnabled( true );
	}

	void disableRadioButtons() {

	    Enumeration buttons = getButtonGroup().getElements();
	    while ( buttons.hasMoreElements() ) {
		((JRadioButton)buttons.nextElement()).setEnabled( false );
	    }
	}

	void grabInputFocus() {
	    inputField.grabFocus();
	}

	//- 
	//-	Implementation of java.awt.event.ActionListener - - - - - - -
	//-
	
	public void actionPerformed(ActionEvent actionEvent) {
	    
	    String command = actionEvent.getActionCommand();

	    if ( command.equals( FORWARD_COMMAND ) ) {

		if ( messageIndex == messagePool.size() -1 ) {

		    // At the end of message pool, namely, the system is
		    // waiting for the user's responce
		    setMessageRead( true );
		    ComManager comManager = AGT.getComManager();

		    if ( isFedByEquationBuilder() ) {

			// Some equations have been fed by Equation Builder
			if ( numEquationFed > 1 )
			    inputText = "(" + inputText + ")";

			comManager.sendStringInput( "Message", inputText );
			System.out.println("inputText " + inputText + "sent");

		    } else if ( getOptionType() == MULTIPLE_CHOICE ) {

			String itemSelected = 
			    getButtonGroup().getSelection().getActionCommand();
			comManager.sendStringInput( "Message", itemSelected );
			disableRadioButtons();

		    } else {

			comManager.sendAgtMessage(":OK-CLICK", "Message", "OK");
		    }

		    forwardButton.setBackground( buttonBackgroundColor );
		    forwardButton.setEnabled( false );
		    forwardButton.setText( " >> " );
		    closeDisplayMessage();

		} else {

		    // At the middle of turning the pages of message pool
		    MessagePane mp =
			(MessagePane)messagePool.elementAt( ++messageIndex );
		    setMessagePane( mp );

		    ComManager comManager = AGT.getComManager();
		    String log = "(LOG:WRITE-LOG MESSAGE-FORWARD)";
		    comManager.sendAgtCommand( "Message", log );

		}

	    } else if ( command.equals( BACKWARD_COMMAND ) ) {
	    
		MessagePane mp =
		    (MessagePane)messagePool.elementAt( --messageIndex );
		setMessagePane( mp );
		mp.forwardButton.setEnabled( true );

		ComManager comManager = AGT.getComManager();
		String log = "(LOG:WRITE-LOG MESSAGE-BACK)";
		comManager.sendAgtCommand( "Message", log );

	    } else if ( command.equals( INPUT_ACTION_COMMAND ) ) {

		// input completed
		JTextField inputField = (JTextField)actionEvent.getSource();
		String theInput = inputField.getText();

		if ( !theInput.equals("") ) {
		    System.out.println("INPUT_ACTION_COMMAND: " + theInput );
		    ComManager comManager = AGT.getComManager();
		    comManager.sendStringInput( "Message", theInput );
		    setInputText( theInput );
		}
		closeDisplayMessage();

	    } else if ( getSelectionItems().contains( command ) ) {

		// Multiple choice is done
		enableForwardButton();
	    }
	}
    }
}

//
// end of $RCSfile: Message.java $
// 
