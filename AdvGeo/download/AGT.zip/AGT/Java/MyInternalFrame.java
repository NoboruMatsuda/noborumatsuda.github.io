/**
 * MyInternalFrame.java
 *
 *
 * Created: Mon Nov 03 15:24:35 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: MyInternalFrame.java 1.1 2003/11/18 21:09:05 NoboruM Exp NoboruM $
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MyInternalFrame extends JInternalFrame implements MouseListener {

    //-
    //-	Fields = = = = = = = = = = = = = = = = = = = = = = = = = 
    //- 

    int borderWidth = 10;
    public int getBorderWidth() { return borderWidth; }

    //-
    //-	Constructor = = = = = = = = = = = = = = = = = = = =
    //-

    public MyInternalFrame() {
	ComManager.registerComponent( this );
    }

    public MyInternalFrame( String title,
			    boolean resizable, boolean closable,
			    boolean maximizable, boolean iconifiable ) {
	super( title, resizable, closable, maximizable, iconifiable );
	// super( title, false, false, false, false );

	/*
	setBorder( BorderFactory.createMatteBorder( borderWidth,
						    borderWidth,
						    borderWidth,
						    borderWidth,
						    getBackground() ) );
	*/

	ComManager.registerComponent( this );
	addMouseListener( this );
    }

    //-
    //-	Methods = = = = = = = = = = = = = = = = = = = = = = = = = 
    //-

    public void getFocused() {

    	try {
	    setSelected( true );
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    void dropFromComMamager() {
	ComManager.dropComponent( this );
    }

    // =
    // = Implementation of java.awt.event.MouseListener ===============
    // = 

    public void mouseClicked(MouseEvent mouseEvent) {}

    public void mousePressed(MouseEvent mouseEvent) {}

    public void mouseReleased(MouseEvent mouseEvent) {}

    public void mouseEntered(MouseEvent mouseEvent) {
	// getFocused();
    }

    public void mouseExited(MouseEvent mouseEvent) {}

}

//
// end of $RCSfile: MyInternalFrame.java $
// 
