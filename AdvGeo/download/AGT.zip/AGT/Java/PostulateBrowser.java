/**
 * PostulateBrowser.java
 *
 *
 * Created: Mon Oct 27 10:41:06 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: PostulateBrowser.java 1.3 2004/02/27 03:28:29 NoboruM Exp NoboruM $
 */

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/* ------------------------------------------------------------
 *	Postulate Browser
 * ------------------------------------------------------------ */

public class PostulateBrowser extends MyInternalFrame {

    //-
    //-	Fields - - - - - - - - - - - - - - - - - - - - 
    //-

    // The window title
    static String windowTitle = "Postulate Browser";
    int pbWidth, pbHeight;
    
    // The content pane
    JPanel contentPane;

    // Postulate Selector
    int psWidth, psHeight;
    final int PS_HEIGHT = 40;

    // JComboBox holding DS names
    JComboBox comboBox;
    public JComboBox getComboBox() { return comboBox; }

    // JButton to [Select this postulate]
    JButton selectButton;
    final String selectButtonCommand = "select";

    // Geometry configucation
    DiagramDisplay diagramDisplay;
    int ddWidth, ddHeight;

    // Description 
    JTextArea descriptionArea; 
    int daWidth, daHeight;
    // Font messageFont = new Font( "Times New Roman", Font.PLAIN, 14 );
    // Font messageFont = new Font( "MS UI Gothic", Font.PLAIN, 18 );
    Font messageFont = AGT.getDisplayFont();
    Insets messageMargin = new Insets( 10, 10, 10, 10 );
    
    // List of Deductions
    JTextArea deductionList;
    int dlWidth, dlHeight;

    // Postulate descriptions and configurations; incrementally
    // accumulated on demand
    Hashtable /* String */ postulateDescription = new Hashtable(); 
    Hashtable /* Figure */ postulateConfiguration = new Hashtable();
    Hashtable /* String */ firstLoadHash = new Hashtable();
    Hashtable /* String */ requestedHash = new Hashtable();

    //-
    //- Constructor - - - - - - - - - - - - - - - - - 
    //-

    public PostulateBrowser( Dimension size, Point location ) {

	super( windowTitle,
	       false,		// resizable
	       false,		// closable
	       false,		// maximizable
	       false		// iconifiable
	       );

	setPreferredSize( size );
	setLocation( location );
	pbWidth = size.width;
	pbHeight = size.height;

	setupComponents();

	pack();
	setVisible( true );
	
	/*
	  System.out.println("pbHeight: " + pbHeight + ", pbWidth: " + pbWidth);
	  System.out.println("contentPane: " + getContentPane().getSize());
	  System.out.println("rootPane: " + getRootPane().getSize());
	  System.out.println(getRootPane().getWidth() + ":::" +
	  getRootPane().getHeight() );
	*/
    }
	
    void setupComponents() {

	// Set up the content pane
	contentPane = new JPanel();
	contentPane.setLayout( new BoxLayout( contentPane,
					      BoxLayout.Y_AXIS ) );
	contentPane.setOpaque( true );
	setContentPane( contentPane );
	pack();
	
	/*
	  System.out.println("pbHeight: " + pbHeight + ", pbWidth: " + pbWidth);
	  System.out.println("contentPane: " + getContentPane().getSize());
	*/

	// The first row is for postualte selector.  Postulate
	// Selector provides a combo box to select a postulte to brows
	// 
	JTextField psLabel = new JTextField( "Postulate : " );

	comboBox = new JComboBox();
	comboBox.addActionListener( new ComboBoxActionListener() );

	selectButton = new JButton( "Selecet" );
	selectButton.setActionCommand( selectButtonCommand );
	selectButton.addActionListener( new SelectButtonActionListener() );
	selectButton.setEnabled( false );
	String sbTipText = "Click this button to select the postulate";
	selectButton.setToolTipText( sbTipText );

	JPanel postulateSelector = new JPanel();
	FlowLayout layout = (FlowLayout)postulateSelector.getLayout();
	layout.setAlignment( FlowLayout.LEFT  );
	psWidth = pbWidth;
	psHeight = PS_HEIGHT;
	Dimension psDimension = new Dimension( psWidth, psHeight );
	postulateSelector.setPreferredSize( psDimension );
	postulateSelector.add( psLabel );
	postulateSelector.add( comboBox );
	// postulateSelector.add( selectButton );

	contentPane.add( postulateSelector );

	// The second row shows of a diagram configuration
	ddWidth = pbWidth;
	ddHeight = ( pbHeight - psHeight ) / 2;
	diagramDisplay = new DiagramDisplay( ddWidth, ddHeight );
	
	contentPane.add( diagramDisplay );

	// The third row is for the postulate's description
	JPanel da = new JPanel();
	daWidth = pbWidth;
	daHeight = ( pbHeight - psHeight ) / 2;
	Dimension daDimension = new Dimension( daWidth, daHeight );
	da.setPreferredSize( daDimension );

	JLabel daLabel = new JLabel( " Description: " );
	daLabel.setPreferredSize( new Dimension( daWidth, PS_HEIGHT ) );

	descriptionArea = new JTextArea();
	descriptionArea.setLineWrap( true );
	descriptionArea.setWrapStyleWord( true );
	descriptionArea.setFont( messageFont );
	descriptionArea.setMargin( messageMargin );
	Dimension daSize = new Dimension( daWidth, daHeight - PS_HEIGHT );
	descriptionArea.setPreferredSize( daSize );
	JScrollPane daScroll = new JScrollPane( descriptionArea );

	// da.setLayout( new BoxLayout( da, BoxLayout.Y_AXIS ) );
	// da.add( daLabel, BorderLayout.PAGE_START );
	// daLabel.setAlignmentX( Component.LEFT_ALIGNMENT );
	da.add( daScroll, BorderLayout.CENTER );
	// daScroll.setAlignmentX( Component.LEFT_ALIGNMENT );
	
	contentPane.add( da );
    }

    //-
    //-	Methods - - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    // Display <name> in the ComboBox
    public void setSelectedPostulate( String name ) {

	getComboBox().setSelectedItem( name );
    }

    // Enable the selecetButton
    public void enableSelectButton() {

	selectButton.setEnabled( true );
    }

    // Called when the comboBox is clicked empty
    void requestLoadDsName() {
	AGT.getComManager().sendAgtCommand( "PostulateBrowser",
					    "(AGT:BR-LOAD-DS-NAME)" );
	System.out.println("requestLoadDsName: AGT-COMMAND sent");
    }

    // dsNames is a string that contains DS names with single spaces
    // as a separator
    public void loadDsName( String dsNames ) {

	StringTokenizer items = new StringTokenizer( dsNames );

	while ( items.hasMoreTokens() ) {
	    String name = items.nextToken();
	    getComboBox().addItem( name );
	    // requestLoadPostulate( name );
	    // displayPostulate( name );
	    setSelectedPostulate( name );
	}
    }
    
    // Display the description and the configuration of the postulate
    // given by <name>
    void displayPostulate( String name ) {

	// Retrieve description from the hashtable
	String description = (String)postulateDescription.get( name );

	if ( description == null ) {
	    // if the description has never been loaded, then do it
	    // now.
	    String requested = (String)requestedHash.get( name );
	    if ( requested == null ) {
		requestLoadPostulate( name );
		requestedHash.put( name, "" );
	    }
	    // When the request is accepted by the LISP-backend, it
	    // acknowledges by invoking loadPostulate(), which in turn
	    // calls this very method displayPostulate. 
	} else {

	    Figure figure = (Figure)postulateConfiguration.get( name );
	    
	    descriptionArea.setText( description );
	    diagramDisplay.setFigure( figure );

	    String firstLoad = (String)firstLoadHash.get( name );
	    if ( firstLoad == null ) {
		diagramDisplay.xyCanonicalizeFigure();
		diagramDisplay.flipVertical();
		diagramDisplay.repaint();
		firstLoadHash.put( name, "" );
	    }
	}
    }

    // Load a postulate configuration and description
    void requestLoadPostulate( String name ) {

	String funCall = "(AGT:BR-LOAD-POSTULATE " + name + ")";
	AGT.getComManager().sendAgtCommand( "PostulateBrowser", funCall );
    }

    // Assert a postulate's description and configuration.  This
    // method is invoked by the LISP-end as an acknowledge for
    // requestLoadPostulate, which is called by displayPostulate
    public void loadPostulate( String name,
			       String description, String configuration ) {

	postulateDescription.put( name, description );

	System.out.println("loadPostulate: new figure...");
	Figure figure = new Figure( configuration );
	postulateConfiguration.put( name, figure );
	System.out.println("... done");

	displayPostulate( name );
    }

    // Assign new xy-coordinates to a configuration.  
    public void changeXY( String name, String newXY ) {
	Figure figure = (Figure)postulateConfiguration.get( name );
	// newXY -> "A 10 20 12 23$B 20 12 4 2$C ..."
	figure.changeXY( newXY );

	// Quite ad-hoc, but quick hack for TRI-CONG
	if ( name.equals("CPCTC") || name.equals("SAS") ||
	     name.equals("ASA") || name.equals("SSS") )
	    figure.separateTriangles();
	    
	diagramDisplay.xyCanonicalizeFigure( figure );
	figure.flipVertical();
	diagramDisplay.repaint();
    }

    //-
    //- Inner Class - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    /* ------------------------------------------------------------
     *	Action Listener
     * ------------------------------------------------------------ */

    class ComboBoxActionListener implements ActionListener {

	public void actionPerformed(ActionEvent e) {

	    // System.out.println("ActionEvent -> " + e);

	    // There is only one comboBox hence the source of event is
	    // obvious
	    // 
	    // JComboBox comboBox = (JComboBox)e.getSource();

	    // if there has been no items installed, then load items
	    // (by sending a request to the LISP back-end to feed
	    // items)
	    if ( comboBox.getItemCount() != 0 ) {

		String name = (String)comboBox.getSelectedItem();
		displayPostulate( name );

		ComManager comManager = AGT.getComManager();
		String log = "(LOG:WRITE-LOG POSTULATE-BROWSER " + name + " )";
		comManager.sendAgtCommand( "Message", log );
		
	    }
	}
    }

    class SelectButtonActionListener implements ActionListener {
	
	public void actionPerformed(ActionEvent actionEvent) {

	    if (actionEvent.getActionCommand().equals( selectButtonCommand)) {

		selectButton.setEnabled( false );

		String postulate = (String)comboBox.getSelectedItem();

		ComManager comManager = AGT.getComManager();
		comManager.sendStringInput( "PostulateBrowser", postulate );

	    }
	}
    }
}

//
// end of $RCSfile: PostulateBrowser.java $
// 
