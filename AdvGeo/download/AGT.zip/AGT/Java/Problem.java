/**
 * Problem.java
 *
 *	Description of a problem
 *
 * Created: Sat May 11 12:10:15 2002
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: Problem.java 1.1 2003/05/07 22:06:05 NoboruM Exp NoboruM $
 */

import java.io.*;
import java.awt.*;
import javax.swing.*;

public class Problem extends Component {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // Directory which holds problem files
    private String fileDir = "f:\\Home\\Gramy\\lisp\\problem\\";
    private String fileName = "";

    // Problem figure
    private Figure figure;

    // Problem premises and goal
    Object premises, goal;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public Problem () {
	figure = new Figure();
    }

    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------*/

    /**
     *	Return fileName
     */
    String getFileName() {
	return fileName;
    }

    Figure getFigure() {
	return figure;
    }

    /**
     *	Load a problem file
     */
    void loadProblem() {

	// Open up a file dialog and get file name
	final JFileChooser fc = new JFileChooser( fileDir );
	int result = fc.showOpenDialog( this );

	// if no file is selected, then return
	if ( result != JFileChooser.APPROVE_OPTION ) {
	    return;
	}

	fileDir = fc.getCurrentDirectory().getAbsolutePath();
	fileName = fc.getSelectedFile().getName();

	String filePath = fileDir + "\\" + fileName;
	System.out.println(filePath);
	// Invoke a Problem method to load a problem
	readProblem( filePath );
    }

    /**
     *	Read a problem file
     */
    void readProblem( String filePath ) {

	FileInputStream in;
	try {
	    in = new FileInputStream( filePath );
	} catch ( IOException e ) {
	    System.err.println( "Can't open file: " + filePath );
	    e.printStackTrace();
	    return;
	}

	readProblem( in );
    }

    void readProblem( InputStream in ) {

	// Setup a stream to read LISP expressions
	lisp.LispInterpreter interpreter = new lisp.LispInterpreter( in );
	Object elements = null;

	try {
	    elements = interpreter.getReader().read();
	    // The first list may be for :theorem (e.g., P132)
	    String car = ((lisp.LispCons)elements).getCar().toString();
	    if ( !car.equals( ":description-element" ) ) {
		elements = interpreter.getReader().read();
	    } // end of if ()
	    premises = interpreter.getReader().read();
	    goal = interpreter.getReader().read();
	} catch ( lisp.LispException e ) {
	    e.printStackTrace();
	} catch ( Exception e ) {
	    e.printStackTrace();
	}

	// read problem configuration into figure object
	figure.readConfigurationFromLispExp( elements );

	// Close the problem file
	try {
	    in.close();
	} catch (IOException e) {
	    e.printStackTrace();
	}
    }
}

//
// end of $RCSfile$
// 
