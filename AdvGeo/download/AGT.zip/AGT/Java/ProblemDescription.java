/**
 * ProblemDescription.java
 *
 *	Problem Description window
 *
 * Created: Wed Sep 24 14:53:40 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: ProblemDescription.java 1.1 2003/09/24 14:56:52 NoboruM Exp NoboruM $
 */

import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ProblemDescription extends MyInternalFrame {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // Title of the application frame
    static String theTitle = "Problem Description";

    // The DiagramDisplay
    EditableDiagramDisplay diagramDisplay;
    final int DISPLAY_MARGIN = 20;
    // Ratio of the diagramDisplay to the whole window
    final double DD_RATIO = .5;

    // Text statements
    JTextArea problemStatement;
    Insets psMargin = new Insets( 15, 15, 15, 15 );
    // Font
    // Font psFont = new Font( "Times New Roman", Font.PLAIN, 16 );
    // Font psFont = new Font( "MS UI Gothic", Font.PLAIN, 18 );
    Font psFont = AGT.getDisplayFont();

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public ProblemDescription( Dimension size, Point location ) {

	// Make an internal frame
	super( theTitle,
	       false,		// resizable
	       false,		// closable
	       false,		// maximizable
	       false		// iconifiable
	       );

	setPreferredSize( size );
	setLocation( location );

	Insets insets = getInsets();
	System.out.println("insets: " + insets);

	int pdWidth = (int)(size.getWidth() - insets.right - insets.left);
	int pdHeight = (int)(size.getHeight() - insets.top - insets.bottom);
	
	// Diagram Diaplay 
	int ddWidth = (int)(pdWidth * DD_RATIO );
	int ddHeight = pdHeight;
	Dimension ddSize = new Dimension( ddWidth, ddHeight );
	diagramDisplay = new EditableDiagramDisplay( ddSize );
	diagramDisplay.setDisplayMargin( DISPLAY_MARGIN );

	// Problem statement
	int psWidth = pdWidth - ddWidth;
	int psHeight = pdHeight;
	Dimension psSize = new Dimension( psWidth, psHeight );
	problemStatement = new JTextArea();
	problemStatement.setPreferredSize( psSize );
	problemStatement.setMargin( psMargin );
	problemStatement.setLineWrap( true );
	problemStatement.setWrapStyleWord( true );
	problemStatement.setEditable( false );
	// problemStatement.setBackground( Color.yellow );

	// Font
	// Font defaultFont = problemStatement.getFont();
	// String defaultFontName = defaultFont.getFontName();
	// psFont = new Font( defaultFontName, Font.PLAIN, 16 );
	problemStatement.setFont( psFont );

	getContentPane().setLayout( new BoxLayout( getContentPane(),
						   BoxLayout.X_AXIS ) );
	getContentPane().add( problemStatement );
	getContentPane().add( diagramDisplay );

	pack();
	setVisible( true );
    }

    //-
    //-	Methods
    //- 

    // Construction
    public void turnOnDrawing() {
	diagramDisplay.turnOnDrawing();
	getFocused();
    }

    public void turnOffDrawing() {
	diagramDisplay.turnOffDrawing();
    }

    public void notifyMessageWindowConstruction() {
	diagramDisplay.setNotifyMessageWindowConstruction( true );
    }

    public void resetNotifyMessageWindowConstruction() {
	diagramDisplay.setNotifyMessageWindowConstruction( false );
    }

    public void highlightSegment( String segment ) {
	System.out.println("ProblemDescription: highlight segment " + segment);
	diagramDisplay.getFigure().highlightSegment( segment );
	diagramDisplay.repaint();
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     *	Load problem configuration
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    public void readProblemStatement( String statement ) {
	problemStatement.setText( Equation.reformMessage(statement) );
    }

    // (:description-element (:point ...) (:segment ...) (:collinear ...))
    public void loadProblemConfiguration( String config ) {

	Figure figure = new Figure( config );
	setProblemFigure( figure );
    }

    /**
     *	Setup a problem figure
     **/
    void setProblemFigure( Figure figure ) {
	diagramDisplay.setFigure( figure );
	diagramDisplay.xyCanonicalizeFigure();
	diagramDisplay.flipVertical();
	diagramDisplay.repaint();
    }

    /**
     *	Paiting methods
     **/
    public void paintComponent( Graphics g ) {
	diagramDisplay.paintComponent( g );
    }

}

//
// end of $RCSfile: ProblemDescription.java $
//
