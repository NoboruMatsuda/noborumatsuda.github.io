/**
 * ProblemViewer.java
 *
 *	Problem viewer that reads and displays a problem.
 *
 * Fri May 10 17:24:24 2002
 *
 * @author Noboru Matsuda
 * @version $Id$
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ProblemViewer extends JFrame implements ActionListener {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // Title of the application frame
    static String theTitle = "Problem Viewer";

    // Menu Items
    final String MENU[][] = {
	// File menu
	{ "File", "Load", "Exit" },
	// Figure menu
	{ "Figure", "Vertical Flip" }
    };
    
    // The Problem
    Problem problem;

    // The DiagramDisplay
    DiagramDisplay diagramDisplay;
    // size of the diagramDisplay
    int ddWidth = 600;
    int ddHeight = 400;

    // The Goal/Premises/Facts display
    // GpfDisplay gpfDisplay;
    // size of the gpfDisplay
    int gpfWidth = 100;
    int gpfHeight = ddHeight;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public ProblemViewer() {

	// Set title
	super( theTitle );

	try {
	    String af = UIManager.getCrossPlatformLookAndFeelClassName();
	    UIManager.setLookAndFeel( af );
	} catch ( Exception e ) {
	    System.out.println( "LookAndFeel: error " + e );	    
	} // end of try-catch

	// Menu bar
	JMenuBar menuBar = setupMenubar();
	setJMenuBar( menuBar );

	// Diagram Diaplay 
	diagramDisplay = new DiagramDisplay();

	getContentPane().setLayout( new FlowLayout() );
	getContentPane().add( diagramDisplay );

	pack();
	setVisible( true );
    }

    /* ------------------------------------------------------------
     *	main method
     * ------------------------------------------------------------*/

    public static void main( String[] args ) {
	ProblemViewer problemViewer = new ProblemViewer();
    }

    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------*/

    /**
     *	Setup a menu bar
     **/
    JMenuBar setupMenubar() {

	JMenuBar menubar = new JMenuBar();
	JMenu menu;
	JMenuItem menuItem;

	// File menu
	menu = new JMenu( MENU[0][0] );
	menu.setMnemonic( KeyEvent.VK_F );
	menubar.add( menu );
	
	menuItem = new JMenuItem( MENU[0][1], KeyEvent.VK_L );
	menuItem.addActionListener( this );
	menu.add( menuItem );
	
	menuItem = new JMenuItem( MENU[0][2], KeyEvent.VK_X );
	menuItem.addActionListener( this );
	menu.add( menuItem );
	
	// Figure menu
	menu = new JMenu( MENU[1][0] );
	menubar.add( menu );
	
	menuItem = new JMenuItem( MENU[1][1] );
	menuItem.addActionListener( this );
	menu.add( menuItem );
	
	return menubar;
    }

    /**
     *	Event listener
     */
    public void actionPerformed( ActionEvent event ) {
	
	String command = event.getActionCommand();
	
	if ( command.equals( MENU[0][1] ) ) {
	    // Load problem file
	    problem = new Problem();
	    problem.loadProblem();
	    // Update the title
	    setTitle( this.theTitle + " [" + problem.getFileName() + "]" );
	    // Set problem figure to DiagramDisplay
	    if ( problem.getFigure() != null )
		diagramDisplay.setFigure( problem.getFigure() );
	} else if ( command.equals( MENU[0][2] ) ) {
	    dispose();
	    System.exit(0);
	} else if ( command.equals( MENU[1][1] ) ) {
	    diagramDisplay.flipVertical();
	}
    }

    public void paintComponent( Graphics g ) {
	diagramDisplay.paintComponent( g );
    }

} // ProblemViewer
