/**
 * ProofTable.java
 *
 *	Proof Table window
 *
 * Created: Thu Sep 25 16:14:31 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: ProofTable.java 1.1 2003/09/29 12:56:15 NoboruM Exp NoboruM $
 */

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/* ------------------------------------------------------------
 *	ProofTable
 * ------------------------------------------------------------ */

public class ProofTable extends MyInternalFrame { 
    
    //-
    //-	Fields ==================================================
    //-

    // The window title
    static String theTitle = "Proof Table";

    // The Content Pane
    JPanel contentPane;

    // The Proof Pane
    //
    ProofPane proofPane;
    public ProofPane getProofPane() { return proofPane; }
    public void setProofPane(ProofPane newProofPane) {
	this.proofPane = newProofPane;
    }
    
    // Size of the scroll window inside of the proof pane
    Dimension ppScrollSize;
    // Size of a left and right cell in the proof pane
    Dimension cellSize;
    int cellHeight = 25;
    // Margin
    Insets cellMargin = new Insets( 5, 5, 5, 5 );
    // Size of a text field showing a line number
    Dimension IDsize = new Dimension( 25, 25 );
    // Size of a proof row
    Dimension prSize; 

    // Size of the initial proof table 
    int ppInitSize;
    void setPpInitSize( int size ) { ppInitSize = size; }
    // Amount of increase of the proof table
    int ppIncSize = 5;
    void setPpIncSize( int size ) { ppIncSize = size; }

    // Rows in the proof table
    Vector /* ProofRow */ proofRows = new Vector();
    public Vector /* ProofRow */ getProofRows() { return proofRows; }
    public void setProofRows(Vector newProofRows) {
	this.proofRows = newProofRows;
    }
    void addProofRows( ProofRow proofRow ) { proofRows.add( proofRow ); }

    // Header of the proof table
    String[] columnNames = { "Proposition", "Justification" };
    // 
    final String CLICK_HERE_MESSAGE = 
	"Click here to input your justification";
    //
    final String BLANK_TEXT_FIELD = "";
    final String BLANK_PREMISE = "   ";
    final int SUPPORTER_COLUMNS = 8;
    final int PREMISES_COLUMNS = 3;
    final int INPUT_COLUMNS = 2;

    // ActionCommands Proof Row
    final int PROPOSITION_FIELD = 1;
    final int SUPPORTER_FIELD = 2;
    final int PREMISE_FIELD = 3;

    // The top most empty supporter filed in right column
    Vector /* JTextField */ currentOpenSupporter = new Vector();
    public Vector /* JTextField */ getCurrentOpenSupporter() {
	return currentOpenSupporter;
    }
    public void addCurrentOpenSupporter(JTextField currentOpenSupporter) {
	this.currentOpenSupporter.add( currentOpenSupporter );
    }

    // A proposition cell that is empty hence waiting for an input
    Proposition currentOpenProposition;
    public Proposition getCurrentOpenProposition() {
	return currentOpenProposition;
    }
    public void setCurrentOpenProposition(Proposition currentOpenProposition) {
	this.currentOpenProposition = currentOpenProposition;
    }

    // Amount of indentaion for premises hanging under postulate name
    int PREMISE_INDENT = 20;

    // Ratio of the proof table to the window size
    double TABLE_RATIO = .8;

    // Highlight level, which is used as an index of highlightColor[]
    final int HIGHLIGHT_LEVEL_NORMAL = 0;
    final int HIGHLIGHT_LEVEL_WARNING = 1;
    Color[] highlightColor = {Color.yellow, Color.red};

    // Background color
    Color backgroundColor = Color.white;

    // Font
    // Font proofFont = new Font( "MS UI Gothic", Font.PLAIN, 18 );
    Font proofFont = AGT.getDisplayFont();
    Font headerFont = new Font( "Verdana", Font.PLAIN, 17 );

    //-
    //- Constructor ==================================================
    //-

    public ProofTable( Dimension size, Point location ) {
	
	// Make an internal frame
	super( theTitle,
	       false,		// resizable
	       false,		// closable
	       false,		// maximizable
	       false		// iconifiable
	       );
	
	// System.out.println("size: " + size + ", location: " + location );
	
	setPreferredSize( size );
	setLocation( location );

	// Create the content pane
	contentPane = new JPanel();
	// contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	// Shape up the window
	pack();
	setVisible( true );
    }
    
    //-
    //- Class methods ===============================================
    //-

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // Maintain proof table
    // ====================

    public void initializeProofTable( int initSize, int incSize ) {

	setPpInitSize( initSize );
	setPpIncSize( incSize );

	// Window size
	Dimension ppSize = getProofTableInnerSize();
	ppScrollSize = new Dimension((int)(ppSize.width * .9),
				     (int)(ppSize.height * .98));
	cellSize = new Dimension( (int)((ppScrollSize.width / 2) * .8),
				  25 );
	prSize = new Dimension( (int)(ppScrollSize.width * .9), 25 );

	//System.out.println("ProofTable size :" + getProofTableSize());
	//System.out.println("ProofTable inner size:" + getProofTableBounds());

	// Make empty proof table
	numProofRow = 0;
	for (int i = 0; i < ppInitSize; i++)
	    addProofRows( new ProofRow() );

	// Proof pane
	setProofPane( new ProofPane( getProofRows() ) );
	JScrollPane ppScroll = new JScrollPane( getProofPane() );
	ppScroll.setPreferredSize( ppScrollSize );
	ppScroll.setBackground( backgroundColor );
	contentPane.add( ppScroll );
	pack();

    }

    // Update the proposition and the supporter in the specified proof
    // row
    public void setProofRowText( int index,
				 String proposition, String supporter ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.setPropositionText( proposition );
	proofRow.setSupporterText( supporter );
    }

    // Add empty proof rows at the bottom of the proof pane
    public void expandProofRows() {

	for (int i = 0; i < ppIncSize; i++) {
	    ProofRow proofRow = new ProofRow();
	    addProofRows( proofRow );
	    getProofPane().add( proofRow );
	}
    }

    // Highlight a line number of the proof row specified by <index>
    public void highlightLineNumber( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.highlightLineNumber();
    }

    public void cancelHighlightingLineNumber( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.cancelHighlightLineNumber();
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // Proposition
    // ===========

    public void highlightProposition( int index ){
	highlightProposition( index, HIGHLIGHT_LEVEL_NORMAL );
    }

    public void highlightProposition( int index, int level ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.highlightProposition( level );
    }

    public void cancelHighlightingProposition( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.cancelHighlighting();
    }

    public int numberOfPropositions() {

	int n = 0;
	for (int i = 0; i < getProofRows().size(); i++) {
	    ProofRow proofRow = (ProofRow)getProofRows().elementAt(i);
	    if ( !proofRow.isEmpty() ) {
		Proposition proposition = proofRow.getProposition();
		if ( proposition.getPropositionText() != "" ) {
		    n++;
		}
	    }
	}

	System.out.println("numberOfPropositions: " + n);
	return n;
    }

    // Open Inline Equation Builder at the top most empty proposition
    // cell
    public void enterPropositionInline() {
	enterPropositionInline( "" );
    }
    
    public void enterPropositionInline( String points ) {

	// System.out.println("enterPropositionInline: " + points);

	ProofRow proofRow = lookupEmptyProofRow();
	proofRow.getProposition().enterPropositionInline( points );
    }
    
    // An equation sent from Inline Equation Builder
    public void feedFromInlineEquationBuilder( String equation ) {
	ProofRow proofRow = lookupEmptyProofRow();
	proofRow.getProposition().feedFromInlineEquationBuilder( equation );
    }
    
    // An equation sent from Postulate Builder
    public void feedFromPostulateBuilder( String equation ) {
	ProofRow proofRow = lookupEmptyProofRow();
	proofRow.getProposition().feedFromPostulateBuilder( equation );
    }
    
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    // Justification
    // =============

    // Enable text input
    public void enableInputJustification( int index ) {
	
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().getSupporter().setEditable( true );
    }

    public void disableInputJustification( int index ) {

	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().getSupporter().setEditable( false );
    }

    // Spporter field gets focus
    public void supporterGetFocused( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().getSupporter().grabFocus();
    }

    // Place a text field at the end of Justification cell to enter a
    // line number of a premise
    public void openPremiseLineNumberInput( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().openPremiseLineNumberInput();
    }

    // 
    public void closePremiseLineNumberInput( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().closePremiseLineNumberInput();
    }

    // Spporter field gets focus
    public void lineNumberInputGetFocused( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().premiseInput.grabFocus();
    }

    // Add a line number of a premise into a list of the line numbers
    // for the proposition at index
    public void addPremiseLineNumber( int index, String number ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().addPremiseLineNumber( number );
    }

    // Clear the contents of the premise input field
    public void clearPremiseField( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().clearPremiseField();
    }

    // Get rid of the line number entered most recently as a premise
    public void eraseLastPremiseLineNumber( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().eraseLastPremiseLineNumber();
    }

    public void displayPremiseList( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().displayPremiseList();
    }

    public void highlightJustification( int index ) {
	highlightJustification( index, HIGHLIGHT_LEVEL_NORMAL );
    }

    public void highlightJustification( int index, int level ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().highlight( level );
    }

    public void cancelHighlightingJustification( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	proofRow.getJustification().cancelHighlighting();
    }
 
    public void highlightPremiseInput( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	Justification justification = proofRow.getJustification();
	justification.highlightPremiseInput( HIGHLIGHT_LEVEL_NORMAL );
    }

    public void cancelHighlightingPremiseInput( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	Justification justification = proofRow.getJustification();
	justification.cancelHighlightingPremiseInput();
    }

    public void enableLineNumberInput( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	Justification justification = proofRow.getJustification();
	justification.enableLineNumberInput();
    }

    public void disableLineNumberInput( int index ) {
	ProofRow proofRow = lookupProofRow( index );
	Justification justification = proofRow.getJustification();
	justification.disableLineNumberInput();
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // Lookup
    // ======
    
    // Returns a ProofRow that has <id> as its ID
    ProofRow lookupProofRow( int id ) {

	Enumeration proofRowElements = proofRows.elements();
	while ( proofRowElements.hasMoreElements() ) {
	    ProofRow proofRow = (ProofRow)proofRowElements.nextElement();
	    if ( proofRow.getID() == id ) {
		return proofRow;
	    }
	}
	return null;
    }

    // Returns a ProofRow that has <equation> as its proposition
    ProofRow lookupProofRowWithProposition( String equation ) {
	// Tue Apr 13 17:06:36 2004
	// So, this is an obsolete method
	// 
	// Now, the students can enter isomorphic propositions, hence a
	// proposition must be looked up by the LISP backend who knows
	// more about equivalent equations.  
	// 
	Enumeration proofRowElements = proofRows.elements();
	while ( proofRowElements.hasMoreElements() ) {
	    ProofRow proofRow = (ProofRow)proofRowElements.nextElement();
	    String proposition =
		proofRow.getProposition().getPropositionText();
	    
	    if ( proposition.equals( equation ) ) {
		return proofRow;
	    }
	}
	return null;
    }

    // Returns the index of the proof row within ProofRows that has
    // proposition.  Returns -1 if no such proof row found.
    int indexOf( Proposition proposition ) {

	for (int i = 0; i < proofRows.size(); i++) {

	    ProofRow proofRow = (ProofRow)proofRows.elementAt( i );
	    if ( proofRow.getProposition() == proposition )
		return i;
	}

	return -1;
    }

    // Returns the top-most empty proof row
    ProofRow lookupEmptyProofRow() {

	int i;
	for (i = 0; i < getProofRows().size(); i++) {

	    ProofRow proofRow = (ProofRow)getProofRows().elementAt(i);
	    if ( proofRow.isEmpty() )
		return proofRow;
	}

	// There is no empty proof row hence need to make them
	int index = i;
	expandProofRows();

	return (ProofRow)getProofRows().elementAt(index);
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // Window size
    // ===========

    // returns a width of proof table, which is supposed to be as big
    // as TABLE_RATIO of the ProofTable window
    int getProofTableWidth() {
	return (int)(getPreferredSize().getWidth() * TABLE_RATIO);
    }

    Dimension getProofTableSize() { return getPreferredSize(); }

    // Returns "bounds" of the content pane, which is smaller than the
    // top-level container by the menu bar and the borders
    Rectangle getProofTableBounds() { return getContentPane().getBounds(); }

    // Convert "bounds" into "dimension" for the size of the content
    // pane
    Dimension getProofTableInnerSize() {
	Rectangle bounds = getProofTableBounds();
	return new Dimension( bounds.width, bounds.height );
    }

    /* ------------------------------------------------------------
     *	CLASS ProofPane
     * ------------------------------------------------------------ */

    // A proof table that holds proof rows.  Each time a row is added
    // or removed, a new proofPane is created and added onto the
    // contentPane of the top-most inner frame
    //
    class ProofPane extends JPanel {

	public ProofPane( Vector /* ProofRow */ tableRows ) {

	    setLayout(new BoxLayout( this, BoxLayout.Y_AXIS ));

	    JPanel header = newHeader();
	    add( header );

	    Enumeration theTableRows = tableRows.elements();
	    while ( theTableRows.hasMoreElements() ) {
		ProofRow row = (ProofRow)theTableRows.nextElement();
		add( row );
	    }
	}

	// Make a header for a proof table
	JPanel newHeader() {

	    JPanel proposition = new JPanel();
	    proposition.setBackground( backgroundColor );
	    JLabel pLabel = new JLabel( columnNames[0] );
	    pLabel.setFont( headerFont );
	    proposition.add( pLabel );
	    
	    JPanel justification = new JPanel();
	    justification.setBackground( backgroundColor );
	    JLabel jLabel = new JLabel( columnNames[1] );
	    jLabel.setFont( headerFont );
	    justification.add( jLabel );

	    JPanel header = new JPanel();
	    header.setPreferredSize( prSize );
	    header.setLayout( new BoxLayout(header, BoxLayout.X_AXIS) );
	    header.add( proposition );
	    header.add( justification );

	    return header;
	}
    }

    /* ------------------------------------------------------------
     *	CLASS ProofRow
     * ------------------------------------------------------------ */

    // Number of ProofRows created.  Inner class can't have a static
    // field
    static int numProofRow = 0;

    // A row in the proof table that consists of a Proposition and a
    // Justification
    //
    class ProofRow extends JPanel {

	//-
	//-	Field
	//-
	
	// Unique number to identify each ProofRow object
	int ID;
	public int getID() { return ID; }

	Proposition proposition;
	public Proposition getProposition() { return proposition; }

	Justification justification;
	public Justification getJustification() { return justification; }

	//- 
	//-	Constructor
	//-

	public ProofRow() {

	    ID = numProofRow++;
	    setPreferredSize( prSize );
	    
	    this.proposition = new Proposition( ID, cellSize );
	    this.justification = new Justification( ID, cellSize );

	    setLayout( new GridLayout( 1, 2 ) );
	    // setLayout( new FlowLayout() );
	    // setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
	    add( this.proposition );
	    add( this.justification );
	}

	// a proof statement with a single justification, i.e.,
	// "Premise"
	public ProofRow( String proposition, String justification ) {

	    this();

	    this.proposition.setPropositionText( proposition );
	    this.justification.setJustification( justification );
	}

	//-
	//-	Method
	//-

	public boolean isEmpty() {

	    /*
	      boolean a =
	      ( getPropositionText().equals( BLANK_TEXT_FIELD ) ) &&
	      ( getSupporterText().equals( BLANK_TEXT_FIELD ) );

	      System.out.println("isEmpty: " + a );
	    */

	    return ( getPropositionText().equals( BLANK_TEXT_FIELD ) )
		&& ( getSupporterText().equals( BLANK_TEXT_FIELD ) );
	}

	String getPropositionText() {
	    return getProposition().getPropositionText();
	}

	public void setPropositionText( String proposition ) {
	    getProposition().setPropositionText( proposition );
	}

	// Return supporter field in the justification 
	public JTextField getSupporter() {
	    return getJustification().getSupporter();
	}

	void setSupporterText( String supporter ) {
	    getJustification().setSupporterText( supporter );
	}

	String getSupporterText() {
	    return getJustification().getSupporterText();
	}

	// Called when a supporter is filled up
	public void supporterFed() {
	    getJustification().supporterFed();
	}

	/*
	  void openPremiseFields() {
	  getJustification().openPremiseFields();
	  }
	*/

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	Some scaffolding
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

	// Change background color of the proposition field
	public void highlightProposition( int level ) {
	    getProposition().highlight( level );
	}

	public void cancelHighlighting() {
	    getProposition().cancelHighlighting();
	}

	public void highlightLineNumber() {
	    getProposition().highlightLineNumber();
	}

	public void cancelHighlightLineNumber() {
	    getProposition().cancelHighlightLineNumber();
	}
    }

    /* ------------------------------------------------------------
     *	CLASS Proposition
     * ------------------------------------------------------------ */

    class Proposition extends JPanel implements ActionListener, MouseListener {

	//-
	//-	Fields = = = = = = = = = = = = = = = = = = = = 
	//- 

	// The ID of this object
	int ID;
	int getID() { return ID; }
	void setID( int id ) { this.ID = id; }
	JTextField idField;
	
	String propositionText = "";

	// String representation of the proposition itself stored in a
	// text box
	JTextField equation;

	// public String getProposition() { return proposition; }
	public String getPropositionText() { return this.propositionText; }
	public void setPropositionText( String proposition ) {
	    this.propositionText = proposition;
	    equation.setText( Equation.toEquation( proposition ) );
	    equation.setFont( proofFont );
	}

	// The Inline EquBuilder will call
	// feedFromInlineEqBuilder@ProofTable method when an input is
	// completed
	InlineEqBuilder inlineEqB = new InlineEqBuilder( "ProofTable" );

	//-
	//-	Constructor = = = = = = = = = = = = = = = = = = = = 
	//-

	public Proposition( int ID, Dimension size ) {

	    setID( ID );

	    setLayout( new BorderLayout() );
	    setPreferredSize( size );

	    idField = new JTextField( (ID + 1) + "." );
	    idField.setHorizontalAlignment( JTextField.RIGHT );
	    idField.setBorder( BorderFactory.createEmptyBorder() );
	    idField.setEditable( false );
	    idField.setPreferredSize( IDsize );
	    idField.setBackground( backgroundColor );
	    add( idField, BorderLayout.LINE_START );

	    equation = new JTextField();
	    equation.setEditable( false );
	    equation.setBackground( backgroundColor );
	    equation.setMargin( cellMargin );
	    equation.addMouseListener( this );
	    equation.setActionCommand( ID + ""); 
	    equation.addActionListener( this );
	    add( equation, BorderLayout.CENTER );
	}

	//-
	//-	Method = = = = = = = = = = = = = = = = = = = = 
	//-

	// Change background color into the highlight color
	public void highlight( int level ) {
	    System.out.println("Proposition " + getID() +
			       " gets highlighted level " + level );
	    equation.setBackground( highlightColor[level] );
	}

	public void cancelHighlighting() {
	    equation.setBackground( backgroundColor );
	}

	public void highlightLineNumber() {
	    idField.setBackground( Color.blue );
	}

	public void cancelHighlightLineNumber() {
	    idField.setBackground( backgroundColor );
	}

	// Open an Inline Eqation Builder
	void enterPropositionInline( String points ) {

	    // Replace equation cell with the inline eq. builder
	    remove( equation );
	    inlineEqB.setValidPoints( points );
	    add( inlineEqB, BorderLayout.CENTER );
	    revalidate();
	    repaint();
	}

	// An equation sent from Postulate Builder
	public void feedFromInlineEquationBuilder( String eqString ) {
	    
	    // Replace the Inline Equation Builder with the equation
	    // cell
	    remove( inlineEqB );
	    add( equation );
	    revalidate();
	    repaint();
	    
	    setPropositionText( eqString );
	    ComManager comManager = AGT.getComManager();
	    comManager.sendStringInput( "PROPOSITION", eqString );
	}
	
	// An equation sent from Postulate Builder
	public void feedFromPostulateBuilder( String equation ) {
	    
	    setPropositionText( equation );
	    ComManager comManager = AGT.getComManager();
	    comManager.sendStringInput( "PROPOSITION", equation );
	}
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// Action Listener
	// 
	public void actionPerformed(ActionEvent actionEvent) {

	    // Block editing
	    // setEditable( false );

	    ComManager comManager = AGT.getComManager();
	    comManager.sendStringInput( "PROPOSITION", getPropositionText() );
	}
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// Mouse Listener
	// 
	public void mouseClicked(MouseEvent mouseEvent) {

	    String proposition = getPropositionText();

	    if ( !proposition.equals("") ) {
		ComManager comManager = AGT.getComManager();
		comManager.sendMouseClick( "ProofTable", proposition );
	    }
	}

	public void mousePressed(MouseEvent mouseEvent) {}
	public void mouseReleased(MouseEvent mouseEvent) {}
	public void mouseEntered(MouseEvent mouseEvent) {}
	public void mouseExited(MouseEvent mouseEvent) {}
    }

    /* ------------------------------------------------------------
     *	Class Justification 
     * ------------------------------------------------------------ */

    // The Justification object that gets focus on
    Justification currentJustification = null;
    Justification getCurrentJustification() {
	return currentJustification;
    }
    void setCurrentJustification (Justification justification) {
	currentJustification = justification;
    }

    // The premise that is supporsed to be filled 
    JTextField targetPremiseField;
    public JTextField getTargetPremiseField() {
	return targetPremiseField;
    }
    void setTargetPremiseField( JTextField premise ) {
	targetPremiseField = premise;
	targetPremiseField.setFont( proofFont );
    }

    class Justification extends JPanel implements ActionListener {

	//-
	//-	Fields - - - - - - - - - - - - - - - - - - - - 
	//-

	// The same number as its parent's ID
	int ID;
	void setID( int id ) { this.ID = id; }
	int getID() { return this.ID; }

	// The name of a postulate that support this justification, or
	// other text string (e.g., "premise") that explain the
	// justification
	String supporterName;
	JTextField supporter;
	public JTextField getSupporter() { return supporter; }
	public void setSupporterText( String supporter ) {
	    this.supporter.setText( supporter );
	    this.supporter.setFont( proofFont );
	}
	String getSupporterText() { return this.supporter.getText(); }
	public void setJustification( String justification ) {
	    setSupporterText( justification );
	}

	// A text field that holds premises
	JTextField premises;
	// A editable text field to enter a line number for a premise
	JTextField premiseInput;
	// A list of premises 
	Vector /* int */ premiseList = new Vector();
	Vector /* int */ getPremiseList() { return premiseList; }

	//- 
	//-	Constructor - - - - - - - - - - - - - - - - - - - - 
	//-

	public Justification( int ID, Dimension size ) {

	    setLayout( new BorderLayout() );
	    setPreferredSize( size );

	    setID( ID );

	    // setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
	    //FlowLayout layout = (FlowLayout)getLayout();
	    // layout.setAlignment( FlowLayout.LEFT  );

	    supporter = new JTextField();
	    supporter.setEditable( false );
	    supporter.setBackground( backgroundColor );
	    // supporter.setColumns( SUPPORTER_COLUMNS );
	    supporter.setMargin( cellMargin );
	    supporter.setActionCommand( SUPPORTER_FIELD + ":" + ID );
	    supporter.addActionListener( this );
	    add( supporter, BorderLayout.CENTER );

	    premises = new JTextField();
	    // premises.setColumns( PREMISES_COLUMNS );
	    premises.setEditable( false );
	    premises.setBackground( backgroundColor );
	    // add( premises, BorderLayout.LINE_END );
	    premises.setFont( proofFont );

	    premiseInput = new JTextField();
	    // premiseInput.setColumns( INPUT_COLUMNS );
	    premiseInput.setMargin( cellMargin );
	    premiseInput.setActionCommand( PREMISE_FIELD + ":" + ID );
	    premiseInput.addActionListener( this );
	    premiseInput.setFont( proofFont );
	}

	//-
	//-	Class Methods - - - - - - - - - - - - - - - - - - - - 
	//-

	// Called when the supporter gets typed in
	public void supporterFed() {

	    String support = supporter.getText();

	    if ( isPostulateName( support ) ) {
		// User input a posulate as a support hence need to
		// let the user input premises
		// openPremiseFields();

		// Mon Dec 01 16:38:38 2003
		// ToDo
		// 
		// Notify Communication Manager 
		// ComManager comManager = AGT.getComManager();
		// comManager.dispatch( supporter, support );

	    } else if ( !isValidSupport( support ) ) {
		System.out.println("Invalid support: " + support);
	    }
	}

	// Verify if the <support> is a postulate name
	boolean isPostulateName( String support ) {
	    return true;
	}

	// verify if the <support> is a valid statement
	boolean isValidSupport( String support ) {
	    return true;
	}

	// ============================================================
	// Premise input
	// 
	public void openPremiseLineNumberInput() {


	    // Backup the proposition name
	    supporterName = getSupporterText();
	    // Display an open parenthesis following the proposition
	    // name
	    setSupporterText( supporterName + "  ( " );
	    // Set up the premise input field
	    premiseInput.setText( "" );

	    // Put things together
	    removeAll();
	    add( supporter, BorderLayout.LINE_START );
	    add( premiseInput, BorderLayout.CENTER );
	    revalidate();
	}

	public void closePremiseLineNumberInput() {

	    supporter.setText( supporterName );
	    String pStr = "  ( " + commaSeparatedList( premiseList ) + " )";
	    premises.setText( pStr );

	    removeAll();
	    add( supporter, BorderLayout.LINE_START );
	    add( premises, BorderLayout.CENTER );
	    revalidate();
	}

	void enableLineNumberInput() {
	    premiseInput.setEditable( true );
	}

	void disableLineNumberInput() {
	    premiseInput.setEditable( false );
	}

	// Called when the user entered a line number into the
	// premiseInput text field
	public void premiseEntered() {

	    String premise = premiseInput.getText();

	    int inputValidity = 0;
	    int n = -1;
	    // Check a type of input
	    try {
		n = Integer.parseInt( premise );
		// Check the line number is in a proper range
		if ( n < 1 || numberOfPropositions() < n )
		    inputValidity = 1;
	    } catch (NumberFormatException e) {
		inputValidity = 2;
	    }

	    FatalMessage fatalMessage = AGT.getFatalMessage();
	    String message;

	    switch (inputValidity) {
	    case 1:
		// The input is out of range
		message = "Input a line number from 1 to " +
		    numberOfPropositions();
		fatalMessage.display( message );
		break;

	    case 2:
		// The input is not a number
		message = premise + " is not a number.  " +
		    "Try again and input a line number this time.";
		fatalMessage.display( message );
		break;

	    default:
		addPremiseLineNumber( premise );
		clearPremiseField();
		displayPremiseList();
		ComManager comManager = AGT.getComManager();
		comManager.sendStringInput( "PREMISENUMBER", premise );
	    }
	}

	//
	public void enterPremiseNumberIntoPremiseField( String no ) {
	    premiseInput.setText( no );
	}

	public void clearPremiseField() {
	    premiseInput.setText( "" );
	}

	// Add the line number of a premise into a list of the line
	// numbers of the premise input so far
	public void addPremiseLineNumber( String no ) {
	    if ( premiseInput.getText().equals( "" ) ) {
		enterPremiseNumberIntoPremiseField( no );
	    }
	    premiseList.add( no );
	}

	// Show the line numbers of the premises stored in premiseList
	// at the end of the postulate name (supporter name)
	public void displayPremiseList() {
	    String tmpPremises = "  ( ";
	    tmpPremises += commaSeparatedList( premiseList );
	    supporter.setText( supporterName + tmpPremises + " ");
	    
	    removeAll();
	    add( supporter, BorderLayout.LINE_START );
	    add( premiseInput, BorderLayout.CENTER );
	    revalidate();
	    repaint();
	}

	// Return a string that is a list of premises separated by
	// comma.  E.g.,  "1, 3, 4"
	String commaSeparatedList( Vector premiseList ) {

	    String tmpPremises = "";

	    if ( !premiseList.isEmpty() ) {
		for (int i = 0; i < premiseList.size(); i++) 
		    tmpPremises += (String)premiseList.elementAt(i) + ", ";
		
		tmpPremises =
		    tmpPremises.substring( 0, tmpPremises.length() -2 );
	    }
	    return tmpPremises;
	}
	
	// Extract an int from "command" which is in the form "PREMISE:x:y"
	int getPremiseID( String command ) {
	    
	    int firstPos = command.indexOf( ':' );
	    int secondPos = command.indexOf( ':', firstPos + 1 );
	    String id = command.substring( secondPos + 1 );
	    return Integer.parseInt( id );
	}

	public void eraseLastPremiseLineNumber() {

	    int n = premiseList.size() - 1;
	    premiseList.removeElementAt( n );
	    premiseInput.setText( "" );
	    displayPremiseList();
	}

	public void highlightPremiseInput( int level ) {
	    premiseInput.setBackground( highlightColor[level] );
	}

	public void cancelHighlightingPremiseInput() {
	    premiseInput.setBackground( backgroundColor );
	}

	public void highlight( int level ) {
	    supporter.setBackground( highlightColor[level] );
	}

	public void cancelHighlighting() {
	    supporter.setBackground( backgroundColor );
	}

	// ============================================================
	// Implementation of java.awt.event.ActionListener
	// 
	public void actionPerformed(ActionEvent actionEvent) {

	    String command = actionEvent.getActionCommand();
	    int componentType = getComponentType( command );

	    ComManager comManager = AGT.getComManager();

	    switch ( componentType ) {

	    case PREMISE_FIELD:
		String premise = premiseInput.getText();
		if ( !premise.equals( "" ) )
		    premiseEntered();
		break;
		
	    case  SUPPORTER_FIELD:
		String supporter = getSupporterText();
		if ( !supporter.equals( "" ) )
		    if ( isGoodSupporter( supporter ) ) {
			comManager.sendStringInput( "SUPPORTER", supporter );
		    } else {
			FatalMessage fatalMessage = AGT.getFatalMessage();
			String msg = "You can only enter alphabet letters.";
			fatalMessage.display( msg );
		    }
		break;
	    }
	}

	boolean isGoodSupporter( String supporter ) {

	    boolean isGood = true;

	    String upperStr = supporter.toUpperCase();

	    for (int i = 0; i < upperStr.length(); i++) {
		char c = upperStr.charAt(i);
		if ( ! ( 'A' <= c && c <= 'Z' ) ) {
		    isGood = false;
		    break;
		}
	    }
	    return isGood;
	}

	// Extract component name (e.g., "SUPPORTER") out of the
	// <actionCommand>, which must be "SUPPORTER:ID"
	int getComponentType( String actionCommand ) {

	    int delimiterPos = actionCommand.indexOf( ':' );
	    String type = actionCommand.substring( 0, delimiterPos );
	    return Integer.parseInt( type );
	}

    }
    
}

// 
// end of $RCSfile: ProofTable.java $
//
