/**
 * PropositionBuilder.java
 *
 *	Proposition Builder window
 
 * Created: Wed Sep 24 16:43:32 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: PropositionBuilder.java 1.1 2004/02/24 21:36:03 NoboruM Exp NoboruM $
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PropositionBuilder extends MyInternalFrame implements ActionListener {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------ */

    // The window title
    static String theTitle = "Proposition Buider";

    // The DiagramDisplay object that is a subject of clicking to
    // enter elements
    DiagramDisplay diagramDisplay;

    // The Content Pane
    JPanel contentPane;

    // The pane that lists buttons.  Placed on the left side
    JPanel buttonPane;

    // Labels on the buttons followed by tool tip texts.  Do not try
    // to delete or reorder the labels for they are used everywhere in
    // this module in the way that the order matters.  
    String buttonLabel[][] = {{"�ځQ���ځQ", "Angle equality"},
			      {"�Q���Q", "Segment equality"},
			      {"���Q�߁��Q", "Triangle congruence"},
			      {"�Q//�Q", "Segment parallel"},
			      {"�Q midpoint �Q", "Midpoint"}
    };

    // Done button
    JButton doneButton;
    public JButton getDoneButton() { return doneButton; }
    final String DONE_BUTTON_LABEL = "DONE";
    final String DONE_BUTTON_TIP_TEXT = "Press to complete your input";
    final String doneButtonID = "doneButton";

    // The pane that holds text areas.  Placed on the right side
    JPanel textPane;
    JTextArea messageArea;
    JTextField inputArea;
    public JTextField getInputArea() { return inputArea; }
    final int INPUT_AREA_SIZE = 15;
    final String inputAreaID = "inputArea";

    // The proposition made by student
    final String THE_PROPOSITION_MSG = "Proposition made: ";
    String lastInput = "";
    JLabel thePropositionLabel;
    String theProposition = "";

    String propositionType = "";
    public String getPropositionType() { return propositionType; }
    public void setPropositionType(String newPropositionType) {
	propositionType = newPropositionType;
    }
    
    // LISP expression representing theProposition
    String propExpression = "";
    // The prefix of arguments (e.g., :A, :S, :TRIANGLE) appeared in
    // propExpression
    String argPrefix = "";

    // Flag to tell if one can make an input
    boolean allowReadInput = false;

    // The MyInternalFrame component that is supposed to receive the
    // propositino built
    String feeder;
    public String getFeeder() { return feeder;}
    public void setFeeder(String newFeeder) { this.feeder = newFeeder; }

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public PropositionBuilder( Dimension size, Point location ) {
	
	// Make an internal frame
	super( theTitle,
	       false,		// resizable
	       false,		// closable
	       false,		// maximizable
	       false		// iconifiable
	       );

	// setPreferredSize( size );
	setLocation( location );
	setPreferredSize( size );
	
	// Create the content pane
	contentPane = new JPanel();
	contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	// Create the button pane
	buttonPane = new JPanel();
	buttonPane.setLayout(new BoxLayout(buttonPane, BoxLayout.Y_AXIS));
	makeButtons( buttonPane );
	contentPane.add( buttonPane );

	// Create the text pane
	textPane = new JPanel();
	textPane.setLayout(new BoxLayout(textPane, BoxLayout.Y_AXIS));
	makeTextAreas( textPane );
	contentPane.add( textPane );

	pack();
	// setVisible( true );

    } // PropositionBuilder constructor
    
    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------ */

    /**
     *	Add Buttons
     **/
    void makeButtons( JPanel buttonPane ) {

	for ( int i = 0; i < buttonLabel.length; i++ ) {

	    JButton button = new JButton( buttonLabel[i][0] );
	    button.setToolTipText( buttonLabel[i][1] );
	    button.setActionCommand( buttonLabel[i][0] );
	    button.addActionListener( this );
	    buttonPane.add( button );
	    
	} // end of for ()

	doneButton = new JButton( DONE_BUTTON_LABEL );
	doneButton.setToolTipText( DONE_BUTTON_TIP_TEXT );
	doneButton.setActionCommand( doneButtonID );
	doneButton.addActionListener( this );
	buttonPane.add( doneButton );
	doneButton.setEnabled( false );
    }

    /**
     *	Layout text fields
     **/
    void makeTextAreas( JPanel textPane ) {

	// The message area
	messageArea = new JTextArea( "A message appears here." );
	messageArea.setLineWrap(true);
	messageArea.setWrapStyleWord(true);
	JScrollPane areaScrollPane = new JScrollPane( messageArea );
	areaScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	areaScrollPane.setPreferredSize( new Dimension(250, 100) );
	textPane.add( areaScrollPane );

	// The input area
	inputArea = new JTextField( INPUT_AREA_SIZE );
	inputArea.setActionCommand( inputAreaID );
	inputArea.addActionListener( this );
	JLabel inputAreaLabel = new JLabel( "Enter here: " );
	inputAreaLabel.setLabelFor( inputArea );
	JPanel inputAreaPane = new JPanel();
	inputAreaPane.setLayout( new BoxLayout( inputAreaPane,
						BoxLayout.X_AXIS ) );
	inputAreaPane.add( inputAreaLabel );
	inputAreaPane.add( inputArea );
	textPane.add( inputAreaPane );
	// No input allowed at the beginning
	disableInput();

	// The output Area
	thePropositionLabel = new JLabel( THE_PROPOSITION_MSG );
	textPane.add( thePropositionLabel );
	
    }

    // Update texts in the messagArea
    void setMessage( String message ) {
	messageArea.setText( message );
    }

    /**
     *	Enable and disable the builder
     **/

    // Activate Proposition Builder for <feeder>, which is a
    // MyInternalFrame component who must have a method
    // feedFromPostulateBuilder( String )
    public void openBuilder( String feeder ) {
	setVisible( true );
	getFocused();
	setFeeder( feeder );
	enableInput();
    }

    public void closeBuilder() {
	disableInput();
	setVisible( false );
    }

    // Get ready to read input
    void enableInput() {
	allowReadInput = true;
	inputArea.setEnabled( true );
    }

    // Shutdown input channel
    void disableInput() {
	allowReadInput = false;
	inputArea.setEnabled( false );
    }

    /**
     *	Scaffolding to make each type of proposition
     **/

    // Angle Equality
    void assistAngEqual() {

	setPropositionType( buttonLabel[0][0] );
	String message =
	    "Specify two angles, one at a time, using a keyboard.  " +
	    "To specify an angle, only enter a name of the angle, " +
	    "which are three letters, in " +
	    "the text box below and hit an enter key.\n" +
	    "Enter [Done] when you input a desierd angle." + 
	    "Click [Cancel] if you wish to quit and try anything else.\n";

	setMessage( message );
	setProposition( buttonLabel[0][0] );
	propExpression = "(:EQ ";
	argPrefix = ":A";
	enteringFirstElement();
    }

    // Segment Equality
    void assistSegEqual() {

	String message =
	    "Specify two segments, one at a time, using a keyboard.  " +
	    "To specify a segment, enter its name, which are two letters, " +
	    "in the text box below and hit the enter key.\n" + 
	    "Enter [Done] when you input a desierd angle." + 
	    "Click [Cancel] if you wish quit this and try anything else.\n";

	setMessage( message );
	setProposition( buttonLabel[1][0] );
	propExpression = "(:EQ ";
	argPrefix = ":S";
	enteringFirstElement();
    }

    // Triangle Congruence
    void assistTriCong() {

	String message =
	    "Specify two triangles, one at a time, using a keyboard.  " +
	    "To specify a triangle, enter only its name, " +
	    "which are three letters in the text box below.\n" +
	    "Enter [Done] when you input a desierd angle." + 
	    "Click [Cancel] if you wish quit this and try anything else.\n";

	setMessage( message );
	setProposition( buttonLabel[2][0] );
	propExpression = "(:CONG ";
	argPrefix = ":TRIANGLE";
	enteringFirstElement();
    }

    // Segment Parallel
    void assistSegParallel() {

	String message = 
	    "Specify two segments, one at a time, using a keyboard.  " +
	    "To specify a segment, enter its name, which are two letters, " +
	    "in the text box below and hit the enter key.\n" + 
	    "Enter [Done] when you input a desierd angle." + 
	    "Click [Cancel] if you wish quit this and try anything else.\n";

	setMessage( message );
	setProposition( buttonLabel[3][0] );
	propExpression = "(:PARALLEL ";
	argPrefix = ":S";
	enteringFirstElement();
    }

    // Midpoint
    void assistMidPoint() {

	String message = "";
	setMessage( message );
	setProposition( buttonLabel[4][0] );
	enteringFirstElement();
    }

    // Get an element that is either entered by keyboard or clicked on
    // the figure.  This method is also called by DiagramDisplay
    // object when it is clicked.
    public void getGeometricElement( String obj ) {

	// Verify if it's a good time to read an element or not.
	if ( allowReadInput ) {
	    // Verify if it's a right type of element
	    if ( isCorrectType( getPropositionType(), obj ) ) {

		// Update proposition
		String newProposition = modifyProposition( obj );

		String arg = "(" + argPrefix;
		if ( argPrefix.equals( ":TRIANGLE" ) ) {
		    for (int i = 0; i < obj.length(); i++)
			arg += " " + "(:P " + obj.charAt(i) + ")";
		} else {
		    for (int i = 0; i < obj.length(); i++)
			arg += " " + obj.charAt(i);
		}
		arg += ")";
		propExpression += arg;
		
		ageInput( newProposition );

		if ( !isCompleteProposition( newProposition ) ) {
		    // If the proposition has two arguments and this is
		    // the firt input, then do the second half of input,
		    enteringSecondElement();
		    propExpression += " "; 
		} else {
		    // else activate [DONE] button so that
		    // completeProposition can be called
		    propExpression += ")";
		    doneButton.setEnabled( true );
		    disableInput();
		}
	    }
	}
    }

    // 
    void ageInput( String proposition ) {
	lastInput = theProposition;
	setProposition( proposition );
    }

    // Update proposition entered
    void setProposition( String tmpProposition ) {
	theProposition = tmpProposition;
	thePropositionLabel.setText( THE_PROPOSITION_MSG + theProposition );
    }

    // replace '_' in <theProposition> with the <element>
    String modifyProposition( String element ) {
	return theProposition.replaceFirst( "�Q", element );
    }

    // Verify if <proposition> has been filled up, i.e., all the '_'
    // have been replaced
    boolean isCompleteProposition( String proposition ) {
	return ( proposition.indexOf( "�Q" ) == -1 );
    }

    // Verifty if <obj> fits in the <propositionType>
    boolean isCorrectType( String propositionType, String obj ) {
	return true;
    }

    // Let the proposition builder that the user is about to input the
    // first element of the target proposition
    void enteringFirstElement() {
	enableInput();
    }

    // The user is now about to input the second element
    void enteringSecondElement() {
	;
    }

    // =
    // = Implementation of java.awt.event.ActionListener
    // = 

    /**
     * Describe <code>actionPerformed</code> method here.
     *
     * @param actionEvent an <code>ActionEvent</code> value
     */
    public void actionPerformed(ActionEvent e) {

	String command = e.getActionCommand();

	// for buttons to compose a proposition
	if ( command.equals( buttonLabel[0][0] ) ) {
	    assistAngEqual();
	} else if ( command.equals( buttonLabel[1][0] ) ) {
	    assistSegEqual();
	} else if ( command.equals( buttonLabel[2][0] ) ) {
	    assistTriCong();
	} else if ( command.equals( buttonLabel[3][0] ) ) {
	    assistSegParallel();
	} else if ( command.equals( buttonLabel[4][0] ) ) {
	    assistMidPoint();
	} else if ( command.equals( doneButtonID ) ) {
	    completeProposition();
	} else if ( command.equals( inputAreaID ) ) {
	    getGeometricElement( inputArea.getText() );
	    inputArea.setText("");
	}
    }

    // Activated by [Done] button.  
    public void completeProposition() {

	disableInput();
	doneButton.setEnabled( false );
	ageInput( theProposition );

	System.out.println("theProposition -> " + theProposition);
	System.out.println("propExpression -> " + propExpression);

	ComManager comManager = AGT.getComManager();
	String methodCall = "<feedFromPostulateBuilder><String>";
	methodCall += "\"" + propExpression + "\"";
	methodCall += "</String></feedFromPostulateBuilder>";

	comManager.dispatch( getFeeder(), methodCall );
    }
}

//
// end of $RCSfile: PropositionBuilder.java $
// 
