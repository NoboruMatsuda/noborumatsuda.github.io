head	1.2;
access;
symbols;
locks
	noboru:1.2; strict;
comment	@# @;


1.2
date	2003.12.09.22.06.45;	author NoboruM;	state Exp;
branches;
next	1.1;

1.1
date	2003.09.24.13.56.47;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.2
log
@*** empty log message ***
@
text
@/**
 * AGT.java
 *
 *	AdvGeo tutor executable module
 *
 * Created: Wed Sep 24 13:11:28 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id: AGT.java 1.1 2003/09/24 13:56:47 NoboruM Exp NoboruM $
 */

import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.*; import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;


public class AGT extends Applet implements WindowListener, ActionListener {

    //-
    //-	Fields
    //- 

    // Version
    static String advGeoVersion = "1.1";

    // Flag telling if the tutor is running as a model tracer
    static boolean mtMode;
    static public boolean isMtMode() { return mtMode; }
    static public void setMtMode(boolean newMtMode) {
	mtMode = newMtMode;
    }

    // Problem ID
    Problem problem;

    // Communication Manager
    static ComManager comManager;
    public static ComManager getComManager() { return comManager; }
    public void setComManager(ComManager newComManager) {
	this.comManager = newComManager;
    }

    // The proposition asserted by the most reacent FC.  Used by
    // scaffolding in Inference Step
    static String fcLastAssertion;
    static public String getFcLastAssertion() { return fcLastAssertion; }
    static public void setFcLastAssertion(String newFcLastAssertion) {
	fcLastAssertion = newFcLastAssertion;
    }
    
    /**
     *	GUI components
     */

    // Full Screen size
    Dimension screenSize;

    // Container 
    // JDesktopPane desktop;

    // Problem Description window
    ProblemDescription problemDescription;
    int pdXratio = 45;
    int pdYratio = 30;

    // PropositionBuilder
    static PropositionBuilder propositionBuilder;
    public static PropositionBuilder getPropositionBuilder() {
	return propositionBuilder;
    }
    int pbXratio = 45;
    int pbYratio = 20;

    // Proof Table
    static ProofTable proofTable;
    public static ProofTable getProofTable() {
	return proofTable;
    }
    int ptXratio = 45;
    int ptYratio = 40;

    // Inference Step
    static InferenceStep inferenceStep;
    public static InferenceStep getInferenceStep() {
	return inferenceStep;
    }
    int isXratio = 53;
    int isYratio = 46;

    // Postulate Browser
    static PostulateBrowser postulateBrowser;
    int pobXratio = 53;
    int pobYratio = 46;

    // Message window
    Message message;

    // Menu Items
    final String MENU[][] = {
	// File menu
	{ "File", "Load", "Exit" }
    };
    
    //-
    //- Constructor
    //-

    public AGT() {

	// super( "AdvGeo Tutor " + advGeoVersion );

	// Must run in English 
	Locale.setDefault( Locale.ENGLISH  );

	// Initiate a communication manager
	setComManager( new ComManager() );
	// Register this "component" as a message receiver recognized
	// by the communication manager
	ComManager.registerComponent( this );

	// Automatically hide and dispose the frame after invoking any
	// registered WindowListener objects
	// setDefaultCloseOperation( JFrame.DO_NOTHING_ON_CLOSE );
	// addWindowListener( this );

	/*
	  // Window decorations
	  try {
	  String af = UIManager.getCrossPlatformLookAndFeelClassName();
	  UIManager.setLookAndFeel( af );
	  } catch ( Exception e ) {
	  System.err.println( "LookAndFeel: error " + e );
	  shutdownTutor();
	  }
	*/

	// Set window size and location
	screenSize = Toolkit.getDefaultToolkit().getScreenSize();

	// Initialize a desktop pane
	desktop = new JDesktopPane();
	/* Following two lines draws a red line around the desktop,
           which is just inside of the outer most frame and below menu
           bar */
	//Border desktopBorder = BorderFactory.createLineBorder(Color.red);
	//desktop.setBorder( desktopBorder ); 
	// setContentPane( desktop ); 

	Dimension desktopSize =
	    new Dimension( screenSize.width, screenSize.height );

	// desktop.setPreferredSize( desktopSize );
	// pack();
	setVisible( true );
	
	/*
	insets = desktop.getInsets();
	System.out.println("Desktop insets after pack() (left,right,top,bottom) = (" +
			   insets.left + "," + insets.right + "," +
			   insets.top + "," + insets.bottom + ")");

	Insets insets = UIManager.getInsets( this );
	System.out.println("UIManager insets (left,right,top,bottom) = (" +
			   insets.left + "," + insets.right + "," +
			   insets.top + "," + insets.bottom + ")");
	*/

	// Menu bar
	JMenuBar menuBar = setupMenubar();
	// setJMenuBar( menuBar );

	// Create and Initialize GUI components
	setupWindows();

    }
    
    public static void main(String[] args) {

	JFrame.setDefaultLookAndFeelDecorated( true );

	/* 
	   for (int i = 0; i < args.length; i++) {
	   System.out.println("args[" + i + "] = " + args[i] + " ");
	   }
	*/
	
	// When "-mt" is fed as an option, 
	if ( args.length != 0 ) {
	    if ( args[0].equals( "-mt" ) ) {
		setMtMode( true );
		System.out.println("Model tracing mode is ON");
	    }
	}

	AGT agt = new AGT();
	agt.runSession();
	// agt.demo();
    }

    //-
    //-	Run as an applet - - - - - - - - - - - - - - - - - - - - 
    //-
    public void init() {

	AGT agt = new AGT();
	agt.runSession();
    }

    //-
    //-	Class Methods
    //- 

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *	Main loop
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    void runSession() {

	getComManager().setTutorUp( true );
	getComManager().mainLoop();
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *	Create and initialize GUI components used in AdvGeo
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
    void setupWindows( JDesktopPane desktop ) {

	// Problem Description 
	Dimension pdSize = windowSize( pdXratio, pdYratio );
	Point pdLocation = new Point( 0, 0 );
	problemDescription = new ProblemDescription( pdSize, pdLocation );
	problemDescription.setVisible( true );
	desktop.add( problemDescription );

	// Proof Table
	Dimension ptSize = windowSize( ptXratio, ptYratio );
	int ptY = problemDescription.getY() + problemDescription.getHeight();
	Point ptLocation = new Point( 0, ptY );
	proofTable = new ProofTable( ptSize, ptLocation );
	// This was for a prototype 
	// String goal = "<APM = <BQM";
	// Vector premises = new Vector();
	// premises.add( "M midpoint AB" );
	// premises.add( "AP = BQ" );
	// proofTable = new ProofTable( ptSize, ptLocation, goal, premises );
	desktop.add( proofTable );

	// Proposition Builder
	Dimension pbSize = windowSize( pbXratio, pbYratio );
	int pbY = proofTable.getY() + proofTable.getHeight();
	Point pbLocation = new Point( 0, pbY );
	propositionBuilder = new PropositionBuilder( pbSize, pbLocation );
	// propositionBuilder.setVisible( true );
	desktop.add( propositionBuilder );

	// Inference Step
	Dimension isSize = windowSize( isXratio, isYratio );
	int isX = problemDescription.getX() + problemDescription.getWidth();
	Point isLocation = new Point( isX, 0 );
	inferenceStep = new InferenceStep( isSize, isLocation );
	desktop.add( inferenceStep );

	// Postulate Browser
	Dimension pobSize = windowSize( pobXratio, pobYratio );
	int pobX = isX;
	int pobY = inferenceStep.getY() + inferenceStep.getHeight();
	Point pobLocation = new Point( pobX, pobY );
	postulateBrowser = new PostulateBrowser( pobSize, pobLocation );
	desktop.add( postulateBrowser );

	// Message
	message = new Message();
    }

    Dimension windowSize( int xRatio, int yRatio ) {

	return new Dimension( screenSize.width * xRatio / 100,
			      screenSize.height * yRatio / 100 );
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *	Setup a menu bar
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
    JMenuBar setupMenubar() {

	JMenuBar menubar = new JMenuBar();
	JMenu menu;
	JMenuItem menuItem;

	// File menu
	menu = new JMenu( MENU[0][0] );
	menu.setMnemonic( KeyEvent.VK_F );
	menubar.add( menu );
	
	menuItem = new JMenuItem( MENU[0][1], KeyEvent.VK_L );
	menuItem.addActionListener( this );
	menu.add( menuItem );
	
	menuItem = new JMenuItem( MENU[0][2], KeyEvent.VK_X );
	menuItem.addActionListener( this );
	menu.add( menuItem );
	
	return menubar;
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
     *	Shutdown AdvGeo
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    void shutdownTutor() {
	
	System.out.println("Shutting down the tutor...");
	
	dispose();
	getComManager().shutdown();
	System.exit( 0 );
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     *	Misc methods relating to communication manager
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    //-
    //-	Login - - - - - - - - - - - - - - - - - - - - - - - - - 
    //-

    // Login window shared by login and acknowledgeLogin
    Login login;

    // Let a student identify himself
    public void login() {

	String loginMsg =
	    "Welcome to AGT\n" + 
	    "Please input a user name and a password";

	login = new Login( loginMsg );
	desktop.add( login );
	login.toFront();
	login.grabInputFocus();
    }

    // 
    public void acknowledgeLogin() {
	if ( login != null ) {
	    login.dispose();
	}
    }

    //-
    //-	Loading Problem - - - - - - - - - - - - - - - - - - - - 
    //-

    // Request the LISP backend to feed a problem
    void requestProblem() {

	getComManager().sendAgtCommand( "AGT", "(AGT:AGT-FEED-PROBLEM)" );
    }

    void requestProblem( String problem ) {

	String command = "(AGT:AGT-FEED-PROBLEM " + problem + ".lisp)";
	getComManager().sendAgtCommand( "AGT", command );
    }

    /* ------------------------------------------------------------
     *	Action Listener
     * ------------------------------------------------------------ */

    public void actionPerformed( ActionEvent event ) {
	
	String command = event.getActionCommand();
	
	if ( command.equals( MENU[0][1] ) ) {
	    // [File][load] 

	    // Load a problem
	    requestProblem();

	} else if ( command.equals( MENU[0][2] ) ) {
	    // [File][exit] 
	    
	    // Exit tutor
	    shutdownTutor();
	}
    }

    /* ------------------------------------------------------------
     *	window Listner
     * ------------------------------------------------------------ */

    public void windowClosing(WindowEvent windowEvent) {
	shutdownTutor();
    }
    public void windowClosed(WindowEvent windowEvent) {
    }
    public void windowOpened(WindowEvent windowEvent) {}
    public void windowIconified(WindowEvent windowEvent) {}
    public void windowDeiconified(WindowEvent windowEvent) {}
    public void windowActivated(WindowEvent windowEvent) {}
    public void windowDeactivated(WindowEvent windowEvent) {}
    
    //
    //  Code for demo & debug -------------------------------------
    //
    void demo() {

	/**
	   String goal = "<APM = <BQM";
	   Vector premises = new Vector();
	   premises.add( "M midpoint AB" );
	   premises.add( "AP = BQ" );

	   proofTable.setPremise( premises );
	   proofTable.setGoal( goal );
	*/

	inferenceStep.selectTab( InferenceStep.BACKWARD_TAB );
	
	/*
	  String postulate = "MidPointLaw";
	  Vector dsPremise = new Vector();
	  dsPremise.add( "x midpoint ab" );
	  Vector premise = new Vector();
	  premise.add( "M midpoint AB" );
	  String dsConsequence = "ax = bx";
	  String consequence = "AM = BM";

	  inferenceStep.dispatchForwardInference( postulate,
	  dsPremise,
	  premise,
	  dsConsequence,
	  consequence );
	*/

	// Must initiated by dispatchForwardInference method
	// theForwardInference.scaffolding();

	// inferenceStep.insertStep( new StepSelectPostulate() );
	// inferenceStep.insertStep( new StepPickupPostulate() );
    }

}

//
// end of $RCSfile: AGT.java $
// 
@


1.1
log
@Initial revision
@
text
@d1 451
a451 43
/**
 * AGT.java
 *
 *	AdvGeo tutor executable module
 *
 * Created: Wed Sep 24 13:11:28 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import 

public class AGT extends JFrame {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // Version
    String advGeoVersion = "$Id";

    // Container 
    JDesctopPane desktop;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public AGT() {

	super( "AdvGeo Tutor " + advGeoVersion );

    }
    
    public static void main(String[] args) {
	
    }
}

//
// end of $RCSfile$
// 
@
