head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2003.10.04.17.15.48;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * ComManager.java
 *
 *	Maintain commucation channels among various window components
 *
 * Created: Fri Oct 03 11:23:53 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import java.util.*;

public class ComManager {

    /* ------------------------------------------------------------
     *	Fields
     * ------------------------------------------------------------ */

    /*
      static final int PROOF_TABLE = 1;
      static final int INFERENCE_STEP = 2;
    */

    Vector eventQueue = new Vector();
     

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------ */

    public ComManager() {}
    
    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------ */

    void pushEventQueue( CcEvent event ) {
	eventQueue.add( event );
    }

    void popEventQueue() {
	eventQueue.removeElementAt( 0 );
    }

    // This method must be called when a component gets an event fired
    public void dispatch( Object sender, String message ) {

	// Dispatch first event waiting in the queue, if any.
	if ( !eventQueue.isEmpty() ) {

	    CcEvent event = (CcEvent)eventQueue.firstElement();
	    if ( event.getSender().contains( sender ) ) {
		event.dispatch( message );
		eventQueue.removeElementAt( 0 );
	    }
	}
    }

    // ============================================================
    // Let the comunication manager know who's ready to get input.
    // Methods must follow a convention: cc_Sender_Receiver()
    //

    // StepPickupPostulate waiting for a justification-supporter in
    // the ProofTable
    public void cc_ProofTable_StepPickupPostulate( Vector supporter,
						   StepPickupPostulate spp ) {
	pushEventQueue( new Supporter_StepPickupPostulate( supporter, spp ) );
    }

    // StepIdentifyPremises waiting for DS premises input 
    public void cc_Premise_StepIdentifyPremises( Vector /* JTextField */ s,
						 StepIdentifyPremises sip ) {
	pushEventQueue( new Premise_StepIdentifyPremises( s, sip ) );
    }
						 
    // StepUnifyPremises waiting for premise input
    public void cc_Premise_StepUnifyPremises( Vector /* JTextFiled */ s,
					      StepUnifyPremises sup ) {
	pushEventQueue( new Premise_StepUnifyPremises( s, sup ) );
    }
						 

    // ------------------------------------------------------------
    // Inner class for message handling event
    // 
    abstract class CcEvent {

	/* - - - - - - - - - - - - - - - - - - - - - - - - - 
	 *	Fields
	 * - - - - - - - - - - - - - - - - - - - - - - - - - */

	// a component expecting to receive a message
	Object receiver;
	public Object getReceiver() { return receiver; }
	public void setReceiver(Object newReceiver) {
	    this.receiver = newReceiver;
	}

	// A component that initiated a message passing
	Vector sender;
	public Vector getSender() { return sender; }
	public void setSender( Vector newSender ) { this.sender = newSender; }

	/* - - - - - - - - - - - - - - - - - - - - - - - - - 
	 *	Constructor
	 * - - - - - - - - - - - - - - - - - - - - - - - - - */

	public CcEvent( Vector sender, Object receiver ) {
	    setSender( sender );
	    setReceiver( receiver );
	}

	/* - - - - - - - - - - - - - - - - - - - - - - - - - 
	 *	Method
	 * - - - - - - - - - - - - - - - - - - - - - - - - - */

	// This method is called by ComManager when a component gets
	// an event fired
	abstract void dispatch( String msg );
    }

    // StepPickupPostulate waiting for postulate fed in Justfication
    // supporter field
    class Supporter_StepPickupPostulate extends CcEvent {

	public Supporter_StepPickupPostulate( Vector /* JTextField */ source,
					      StepPickupPostulate spp ) {
	    super( source, spp );
	}

	public void dispatch( String msg ) {
	    ((StepPickupPostulate)getReceiver()).ccInputReady( msg );
	}
    }

    // StepIdentifyPremises waiting for DS premises input at
    // Proposition Builder and DS Browser
    class Premise_StepIdentifyPremises extends CcEvent {

	public Premise_StepIdentifyPremises( Vector /* JTextField */ source,
					     StepIdentifyPremises sip ) {
	    super( source, sip );
	}

	public void dispatch( String msg ) {
	    ((StepIdentifyPremises)getReceiver()).ccInputReady( msg );
	}
    }

    // StepUnifyPremises waiting for premise in the justification cell
    // filled up
    class Premise_StepUnifyPremises extends CcEvent {

	public Premise_StepUnifyPremises( Vector /* JTextField */ source,
					  StepUnifyPremises sup ) {
	    super( source, sup );
	}

	public void dispatch( String msg ) {
	    ((StepUnifyPremises)getReceiver()).ccInputReady( msg );
	}
    }
					     
}

//
// $RCSfile$
//
@
