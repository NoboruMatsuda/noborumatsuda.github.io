head	1.2;
access;
symbols;
locks
	noboru:1.2; strict;
comment	@# @;


1.2
date	2003.05.07.22.02.24;	author NoboruM;	state Exp;
branches;
next	1.1;

1.1
date	2003.05.07.22.01.51;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.2
log
@*** empty log message ***
@
text
@/**
 * $RCSfile$
 *
 *	The most basic panel that displays a problem figure.
 *
 *	Must have a Figure object, which is held in a problem, in
 *	which the configuration of problem figuer is specified.
 *
 * Created: Sat May 11 16:23:13 2002
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id: DiagramDisplay.java 1.1 2003/05/07 22:01:51 NoboruM Exp NoboruM $
 */

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class DiagramDisplay extends JPanel implements ComponentListener {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // Mergin around the diagram.
    final int FRAME_MERGIN = 50;
    static int WIDTH = 600;
    static int HEIGHT = 400;

    // Dimension of the frame
    int width;
    int height;
    Dimension preferredSize;

    // the problem diagram to be displayed
    Figure figure;
    
    /**
     * Get the value of figure.
     * @@return value of figure.
     */
    public Figure getFigure() {
	return figure;
    }
    
    /**
     * Set the value of figure.
     * @@param v  Value to assign to figure.
     */
    public void setFigure(Figure  figure) {
	this.figure = figure;
	xyCanonicalizeFigure();
	flipVertical();
    }
    
    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/
    
    public DiagramDisplay () {
	this( WIDTH, HEIGHT );
    }

    public DiagramDisplay ( int width, int height ) {

	this.width = width;
	this.height = height;
	this.preferredSize = new Dimension( width, height );
       
	Border raisedBevel = BorderFactory.createRaisedBevelBorder();
	Border loweredBevel = BorderFactory.createLoweredBevelBorder();
	Border compound = BorderFactory.createCompoundBorder( raisedBevel,
							      loweredBevel );
	setBorder(compound);
	setBackground( Color.white ); 
	
	addComponentListener(this);
    }

    
    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------*/

    // Must define this method to get the window displayed in a desired size.
    public Dimension getPreferredSize() {
	return preferredSize;
    }

    public void xyCanonicalizeFigure() {
	figure.xyCanonicalize( this.width, this.height, FRAME_MERGIN );
    }

    /**
     *	Flips the problem figure upside down.
     */
    public void flipVertical() {
	figure.flipVertical( this.height, FRAME_MERGIN );
    }

    //=
    //= Draw configuration =========================================
    //=
    
    /**
     *
     * @@param g <description>
     */
    public void paintComponent(Graphics g) {

	// paint background
	super.paintComponent(g); 

	// if a configuration hasn't been read, then do nothing
	if ( this.figure == null || this.figure.notReadYet() )
	    return;

	figure.drawFigure(g);
    }

    //=
    //=	Listeners =====================================================
    //= 

    /**
     *
     * @@param e <description>
     */
    public void componentResized(ComponentEvent e) {

	height = getHeight();
	width = getWidth();

	if ( this.figure != null ) xyCanonicalizeFigure();
    }

    /**
     *
     * @@param param1 <description>
     */
    public void componentMoved(ComponentEvent param1)
    {
	// TODO: implement this java.awt.event.ComponentListener method
    }

    /**
     *
     * @@param param1 <description>
     */
    public void componentShown(ComponentEvent param1)
    {
	System.out.println("componentShown...");
	
	// TODO: implement this java.awt.event.ComponentListener method
    }

    /**
     *
     * @@param param1 <description>
     */
    public void componentHidden(ComponentEvent param1)
    {
	// TODO: implement this java.awt.event.ComponentListener method
    }

} // end of DiagramDisplay
@


1.1
log
@Initial revision
@
text
@d2 1
a2 1
 * DiagramDisplay.java
d12 1
a12 1
 * @@version $Id$
@
