head	1.1;
access;
symbols;
locks
	NoboruM:1.1; strict;
comment	@# @;


1.1
date	2004.01.22.20.31.09;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * EditableDiagramDisplay.java
 *
 *	An extension of DiagramDisplay that allows to draw lines
 *
 * Created: Wed Jan 21 17:03:12 2004
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * $Id$
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EditableDiagramDisplay extends DiagramDisplay
    implements MouseMotionListener, MouseListener {

    //-
    //-	Fields - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    // Flag telling if the drawing function has been on 
    boolean drawing = false;
    public boolean isDrawing() {
	return drawing;
    }
    public void setDrawing(boolean newDrawing) {
	this.drawing = newDrawing;
    }

    // The 1st point for "connect two points"
    GpPoint p1;
    public GpPoint getP1() { return p1; }
    public void setP1(GpPoint newP1) { this.p1 = newP1; }

    // A point at which the mouse is located.  Used to draw a temporal
    // line when the mouse is dragged.
    Point tmpPnt;

    // State description
    //
    // Nothing happened 
    final int NS = 0;
    // "Connect points" selected
    final int C2P = 1;
    // The first point is selected for C2P
    final int GOT1ST = 2;
    // "Extend a line" selected
    final int XLINE = 3;

    // The initial status
    int status = NS;

    // Tool box that holds a bunch of icons for drawing
    JInternalFrame toolBox;

    //-
    //-	Constructor - - - - - - - - - - - - - - - - - - - - - 
    //- 

    public EditableDiagramDisplay( Dimension size ) {
	super( size );
	addMouseListener( this );
	addMouseMotionListener( this );

	// debug -----
	turnOnDrawing();
	status = C2P;
    }
    
    //-
    //-	Methods - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    // Turn on and off the drawing function
    public void turnOnDrawing() {
	setDrawing( true );
	status = NS;
    }

    public void turnOffDrawing() {
	setDrawing( false );
    }

    // Draw a new line connecting two points
    void connectPoints( GpPoint p1, GpPoint p2 ) {
	System.out.println("connectPoints: " + p1 + " - " + p2);
	// Compose a list of point labels as an argument of input
	String arg = "(" + p1.getLabel() + " " + p2.getLabel() + ")";
	ComManager comManager = AGT.getComManager();
	comManager.sendStringInput( "EditableDiagramDisplay", arg );
    }

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    // Implementation of java.awt.event.MouseListener
    // 
    public void mouseClicked(MouseEvent mouseEvent) {

	System.out.println("Mouse Clicked...");

	if ( isDrawing() ) {

	    Point point = mouseEvent.getPoint();
	    int button = mouseEvent.getButton();
	    GpPoint p;

	    System.out.println("Button: " + button + ", Point: " + point);

	    switch ( status ) {

	    case C2P: /* "Connect two points" */

		// Left button is clicked
		if ( button == MouseEvent.BUTTON1 ) {
		    p = getFigure().lookupPointByPosition( point );
		    if ( p != null ) {
			status = GOT1ST;
			setP1( p );
			tmpPnt = point;
		    }
		}
		break;

	    case GOT1ST: /* "connect two points with the 1st point */

		switch ( button ) {

		case MouseEvent.BUTTON1:

		    // Left button specified the 2nd point
		    p = getFigure().lookupPointByPosition( point );
		    if ( p != null ) {
			drawAuxLine( getP1(), tmpPnt );
			connectPoints( getP1(), p );
			status = NS;
		    }
		    break;

		case MouseEvent.BUTTON2:
		case MouseEvent.BUTTON3:

		    // Right button canceled the 1st selection
		    // XOR the aux line drawn most recently
		    drawAuxLine( getP1(), tmpPnt );
		    status = C2P;
		    break;
		}
		break;
	    }
	}
    }

    public void mouseEntered(MouseEvent mouseEvent) {}
    public void mouseExited(MouseEvent mouseEvent) {}
    public void mousePressed(MouseEvent mouseEvent) {}
    public void mouseReleased(MouseEvent mouseEvent) {}

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    // Implementation of java.awt.event.MouseMotionListener
    //
    public void mouseDragged(MouseEvent mouseEvent) {}

    public void mouseMoved(MouseEvent mouseEvent) {

	Point p = mouseEvent.getPoint();

	switch ( status ) {
	case GOT1ST:

	    drawAuxLine( getP1(), tmpPnt );
	    drawAuxLine( getP1(), p );
	    tmpPnt = p;
	    break;
	}
    }

    void drawAuxLine( GpPoint p1, Point p2 ) {

	Graphics g = getGraphics();
	g.setXORMode( Color.red );
	g.drawLine( (int)p1.getX(), (int)p1.getY(),
		    (int)p2.getX(), (int)p2.getY() );
    }
}

// 
// end of $RCSfile$
// 
@
