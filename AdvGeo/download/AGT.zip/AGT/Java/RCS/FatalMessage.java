head	1.1;
access;
symbols;
locks
	NoboruM:1.1; strict;
comment	@# @;


1.1
date	2004.01.21.20.31.52;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * FatalMessage.java
 *
 *	Pop-up message window for a fatal operation.  This message
 *	window is modal, which means it blocks all operation but
 *	clicking an OKAY button to proceed to a next operation.  
 *
 * Created: Tue Jan 20 17:17:10 2004
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * $Id$
 */

import java.util.*;
import java.awt.*;
import javax.swing.*;

public class FatalMessage extends JOptionPane {

    //
    //	Fields - - - - - - - - - - - - - - - - - - - -
    //

    Component parentComponent;
    ComManager comManager;
    
    Dimension messageSize = new Dimension( 200, 100 );
    Insets messageMargin = new Insets( 20, 20, 20, 20 );

    //
    //	Constructor - - - - - - - - - - - - - - - - - - - -
    //
    
    public FatalMessage( Component parentComponent, ComManager comManager ) {
	this.parentComponent = parentComponent;
	this.comManager = comManager;
    }
    
    //
    //	Methods - - - - - - - - - - - - - - - - - - - - 
    //

    public void display( String msg ) {

	JTextArea messageArea = new JTextArea( msg );
	messageArea.setPreferredSize( messageSize );
	messageArea.setMargin( messageMargin );
	messageArea.setLineWrap( true );

	ComManager comManager = AGT.getComManager();
	String cmd = "(LOG:WRITE-LOG FATAL-MESSAGE \"" + msg + "\")";
	comManager.sendAgtCommand( "FatalMessage", cmd );

	// Measure a time the message has been read 
	long start = new Date().getTime();

	JOptionPane.showInternalMessageDialog( parentComponent,
					       messageArea,
					       "Oops!",
					       JOptionPane.ERROR_MESSAGE );
	
	long end = new Date().getTime();
	cmd = "(LOG:WRITE-LOG FATAL-MESSAGE " + (end - start) + ")";
	comManager.sendAgtCommand( "FatalMessage", cmd );
    }
}

//
// end of $RCSfile$
// 
@
