head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2003.05.07.22.03.54;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * Figure.java
 *
 *	Description of problem configuration
 *
 * Created: Sat May 11 12:48:07 2002
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import java.awt.*;

public class Figure {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // maximum number of points and segments in a problem figure
    int MAX_P = 20;
    int MAX_S = 100;

    // Points
    GpPoint[] p = new GpPoint[MAX_P];
    int numP = 0;

    // Segments represented by two endpoints
    GpSegment[] s = new GpSegment[MAX_S];
    int numS = 0;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public Figure () {}

    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------*/

    //=
    //=	Read a configuration from LISP data =========================
    //= 

    /**
     *	Read LISP expressions into p and s
     */
    void readConfigurationFromLispExp( Object data ) {

	Object gDat[] = new Object[3]; 
	
	gDat[0] = ((lisp.LispCons)data).getSecond();
	gDat[1] = ((lisp.LispCons)data).getThird();
	gDat[2] = ((lisp.LispCons)data).getFourth();
	
	// System.out.println( gDat[0] );
	
	for ( int i = 0; i < 3; i++ ) {
	    
	    String car = ((lisp.LispCons)gDat[i]).getCar().toString();
	    Object cdr = ((lisp.LispCons)gDat[i]).getCdr();
	    
	    // System.out.println( car );
	    // System.out.println( cdr );
	    
	    if ( car.equals( ":point" ) )
		readPoints( cdr );
	    else if ( car.equals( ":segment" ) )
		readSegments( cdr );
	}
    }

    /**
     *	Read point data from a list of points
     */
    void readPoints( Object points ) {
	
	Object thePoint;
	String label;
	String numString;
	double px, py, lx, ly;

	while ( points != lisp.LispCons.emptyList ) {

	    thePoint = ((lisp.LispCons)points).getCar();
	    label = ((lisp.LispCons)thePoint).getCar().toString();

	    // x-coordinate of the point
	    numString = ((lisp.LispCons)thePoint).getSecond().toString();
	    px = stringToDouble( numString );

	    // y-coordinate of the point
	    numString = ((lisp.LispCons)thePoint).getThird().toString();
	    py = stringToDouble( numString );

	    // x-coordinate of the point label
	    numString = ((lisp.LispCons)thePoint).getFourth().toString();
	    lx = stringToDouble( numString );

	    // y-coordinate of the point label
	    numString = ((lisp.LispCons)thePoint).getFifth().toString();
	    ly = stringToDouble( numString );

	    // Make a new point and put it into the point pool.
	    p[numP++] = new GpPoint( px, py, label, lx, ly );
	    
	    points = ((lisp.LispCons)points).getCdr();
	}
    }

    /**
     *	Read segment data from a list of segments
     */
    void readSegments( Object segs ) {

	Object theSegment;
	String endp1Label, endp2Label;
	GpPoint endp1, endp2;
	
	while ( segs != lisp.LispCons.emptyList ) {

	    theSegment = ((lisp.LispCons)segs).getCar();
	    
	    endp1Label = ((lisp.LispCons)theSegment).getFirst().toString();
	    endp2Label = ((lisp.LispCons)theSegment).getSecond().toString();
	    endp1 = lookupPointByLabel( endp1Label );
	    endp2 = lookupPointByLabel( endp2Label );

	    // Make a new segment and put it into the segment pool.
	    s[numS++] = new GpSegment( endp1, endp2 );

	    segs = ((lisp.LispCons)segs).getCdr();
	}

	System.out.println(numS + " segments read");
    }

    //=
    //=	Lookup methods ===================================================
    //=

    /**
     *	Lookup element by its labels
     */
    GpPoint lookupPointByLabel( String l ) {
	for ( int i = 0; i < numP; i++ )
	    if ( l.equals( p[i].label ) )
		return p[i];
	return null;
    }
    
    //=
    //=	Drawing configuration =========================================
    //= 

    void drawFigure( Graphics g ) {
	drawSegments(g);
	drawPointLabels(g);
    }

    void drawPointLabels( Graphics g ) {

	for ( int i = 0; i < numP; i++ ) {
	    g.drawString( p[i].getLabel().toUpperCase(),
			  (int)p[i].getLx(), (int)p[i].getLy() );
	} // end of for ()
    }

    void drawSegments( Graphics g ) {

	for ( int i = 0; i < numS; i++ ) {
	    s[i].drawSegment(g);
	} // end of for ()
    }

    //=
    //= Misc methods ==================================================
    //=

    /**
     *	return true if the configuration hasn't been read yet
     */
    public boolean notReadYet() {
	if ( numP == 0 )
	    return true;
	else
	    return false;
    }

    /**
     *	Flip the figure vertically
     */
    public void flipVertical( int height, int mergin ) {

	for ( int i = 0; i < numP; i++ ) {
	    p[i].setY( height - p[i].getY() + mergin );
	    p[i].setLy( height - p[i].getLy() + mergin );
	} // end of for ()
    }

    /**
     *	Adjust figure size into a given dimension
     */
    public void xyCanonicalize( int width, int height, int mergin ) {

	// System.out.println("xyCanonicalize " + width + ":" + height);
	
	double max_x = 0;
	double max_y = 0;
	double min_x = Double.MAX_VALUE;
	double min_y = Double.MAX_VALUE;

	for ( int i = 0; i < numP; i++ ) {
	    if ( max_x < p[i].getX() ) max_x = p[i].getX();
	    if ( max_y < p[i].getY() ) max_y = p[i].getY();
	    if ( min_x > p[i].getX() ) min_x = p[i].getX();
	    if ( min_y > p[i].getY() ) min_y = p[i].getY();
	} // end of for ()
	
	double x_offset = min_x;
	double y_offset = min_y;

	double w_ratio = (width - (mergin * 2)) / (max_x - min_x);
	double h_ratio = (height - (mergin * 2)) / (max_y - min_y);
	double ratio;

	if ( w_ratio < h_ratio ) {
	    ratio = w_ratio;
	} // end of if ()
	else {
	    ratio = h_ratio;
	} // end of if ()else
	
	double x, y;
	for ( int i = 0; i < numP; i++ ) {

	    // System.out.print("p[" + i + "] = (" + p[i].getX() + ", ");
	    // System.out.println(p[i].getY() + ")");

	    x = ((p[i].getX() - x_offset) * ratio) + mergin;
	    y = ((p[i].getY() - y_offset) * ratio) + (mergin * 1.5);
	    p[i].moveTo( x, y );

	    // System.out.print("p[" + i + "] = (" + p[i].getX() + ", ");
	    // System.out.println(p[i].getY() + ")");

	} // end of for ()
    }

    /**
     *	Translate a string representing LISP number into a real number
     */
    double stringToDouble( String num ) {
	
	if ( num.indexOf( (int)'/' ) == -1 )
	    return new Double( num ).doubleValue();
	else {
	    int idx = num.indexOf( (int)'/' );
	    int numerator, denominator;
	    
	    // System.out.println( "index: " + idx );
	    
	    numerator = Integer.valueOf(num.substring(0, idx)).intValue();
	    denominator = Integer.valueOf(num.substring(idx + 1)).intValue();
	    
	    // System.out.println( numerator + " / " + denominator );
	    
	    return ((double)numerator) / ((double)denominator);
	}
    }
    
} // end of Figure
@
