head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2003.05.07.22.05.39;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * GpPoint.java
 *
 *	The Points in a configuration
 *
 * Created: Sat May 11 16:05:45 2002
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

public class GpPoint {

    /*------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // xy-coordinates of the point
    double x, y;
    // xy-coordinates of the label
    double lx, ly;
    // Label
    String label;

    // default offset of the label name wrt the point
    final int LABEL_OFFSET = 5;

    /**
     * Get the value of y.
     * @@return value of y.
     */
    public double getY() {
	return y;
    }
    
    /**
     * Set the value of y.
     * @@param v  Value to assign to y.
     */
    public void setY(double  v) {
	this.y = v;
    }
    
    /**
     * Get the value of x.
     * @@return value of x.
     */
    public double getX() {
	return x;
    }
    
    /**
     * Set the value of x.
     * @@param v  Value to assign to x.
     */
    public void setX(double  v) {
	this.x = v;
    }
    
    /**
     * Get the value of lx.
     * @@return value of lx.
     */
    public double getLx() {
	return lx;
    }
    
    /**
     * Set the value of lx.
     * @@param v  Value to assign to lx.
     */
    public void setLx(double  v) {
	this.lx = v;
    }
    
    /**
     * Get the value of ly.
     * @@return value of ly.
     */
    public double getLy() {
	return ly;
    }
    
    /**
     * Set the value of ly.
     * @@param v  Value to assign to ly.
     */
    public void setLy(double  v) {
	this.ly = v;
    }
    
    /**
     * Get the value of label.
     * @@return value of label.
     */
    public String getLabel() {
	return label;
    }
    
    /**
     * Set the value of label.
     * @@param v  Value to assign to label.
     */
    public void setLabel(String  v) {
	this.label = v;
    }

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public GpPoint ( double x, double y, String l, double lx, double ly ) {

	if ((lx == 0.0) && (ly == 0.0)) {
	    lx = x + LABEL_OFFSET;
	    ly = y + LABEL_OFFSET;
	}
	
	this.x = x;
	this.y = y;
	this.label = l;
	this.lx = lx;
	this.ly = ly;
    }
    
    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------*/

    /**
     *	Move the point to a new place
     */
    void moveTo( double x, double y ) {
	this.x = x;
	this.y = y;
	this.lx = x + LABEL_OFFSET;
	this.ly = y + LABEL_OFFSET;
    }

}// GpPoint
@
