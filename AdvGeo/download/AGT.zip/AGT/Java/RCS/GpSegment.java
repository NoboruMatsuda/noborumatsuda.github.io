head	1.1;
access;
symbols;
locks
	NoboruM:1.1; strict;
comment	@# @;


1.1
date	2003.05.07.22.05.52;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * GpSegment.java
 *
 *	The segments in a configuration
 *
 * Created: Sun May 12 21:43:38 2002
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import java.awt.*;

public class GpSegment {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // End points
    GpPoint endp1, endp2;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public GpSegment(GpPoint endp1, GpPoint endp2) {

	this.endp1 = endp1;
	this.endp2 = endp2;
    }

    //=
    //=	Graphic methods ============================================
    //= 

    public void drawSegment( Graphics g ) {
	g.drawLine( (int)endp1.getX(), (int)endp1.getY(),
		    (int)endp2.getX(), (int)endp2.getY() );
    }

}// GpSegment
@
