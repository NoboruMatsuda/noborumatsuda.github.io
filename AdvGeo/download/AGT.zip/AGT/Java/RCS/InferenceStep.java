head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2003.09.29.12.55.59;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * InferenceStep.java
 *
 *	Inference Step window
 *
 * Created: Mon Sep 29 12:17:07 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import java.awt.*;
import javax.swing.*;

public class InferenceStep extends JInternalFrame {

    /* ------------------------------------------------------------
     *	Fields
     * ------------------------------------------------------------*/

    // Title of this window
    static String theTitle = "Inference Steps";

    // The content pane
    JPanel contentPane;

    // A panel showing forward inference steps
    JPanel forwardPane;
    String forwardPaneName = "Forward Inference Steps";
    // and for backward inference steps
    JPanel backwardPane;
    String backwardPaneName = "Backward Inference Stpes";

    // The Tabbed pane containing forwardPane and backward Pane
    JTabbedPane tabbedPane;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public InferenceStep( Dimension size, Point location ) {

	super( theTitle,
	       true,		// resizable
	       true,		// closable
	       true,		// maximizable
	       true		// iconifiable
	       );
	
	//System.out.println("size: " + size + ", location: " + location );
	
	setPreferredSize( size );
	setLocation( location );

	// Create the content pane
	contentPane = new JPanel();
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	// Set up forward and backward inference panes
	tabbedPane = new JTabbedPane();

	forwardPane = new JPanel();
	forwardPane.setName( forwardPaneName );
	tabbedPane.add( forwardPane );

	backwardPane = new JPanel();
	backwardPane.setName( backwardPaneName );
	tabbedPane.add( backwardPane );
	
	// Shape up the window
	pack();
	setVisible( true );
    }
    
    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------*/

    

}

//
// end of $RCSfile$
//
@
