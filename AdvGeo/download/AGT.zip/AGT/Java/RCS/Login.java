head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2003.11.19.22.04.38;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * Login.java
 *
 *	A small window to identify a user with password
 *
 * Created: Fri Nov 14 14:52:33 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Login extends MyInternalFrame implements ActionListener {

    //-
    //-	Field
    //-

    static String theTitle = "LOGIN";
    final int WIDTH = 250;
    final int HEIGHT = 150;

    // The content pane
    JPanel contentPane;

    // User Name and Password fields
    JTextField userNameField;
    final String UNCMD = "username";
    JPasswordField passwordField;
    final String PWCMD = "password";
    // Column length
    final int WORDLEN = 10;

    //-
    //-	Constructor
    //-

    public Login( String loginMsg ) {
	
	//--------------------------------------------------
	// Initialize a window
	super( theTitle,
	       true,		// resizable
	       false,		// closable
	       false,		// maximizable
	       false		// iconifiable
	       );

	Dimension size = new Dimension( WIDTH, HEIGHT );
	setPreferredSize( size );

	// setLocation( location );

	//--------------------------------------------------
	// Setup input fields

	// User Name Field
	userNameField = new JTextField( WORDLEN );
	userNameField.setEditable( true );
	userNameField.setActionCommand( UNCMD );
	userNameField.addActionListener( this );

	JLabel unLabel = new JLabel( "Name: ");
	unLabel.setLabelFor( userNameField );
	JPanel unPane = new JPanel();
	FlowLayout unLayout = (FlowLayout)unPane.getLayout();
	unLayout.setAlignment( FlowLayout.LEFT  );
	unPane.add( unLabel );
	unPane.add( userNameField );

	// Password Field
	passwordField = new JPasswordField( WORDLEN );
	passwordField.setEchoChar( '*' );
	passwordField.setActionCommand( PWCMD );
	passwordField.addActionListener( this );

	JLabel pwLabel = new JLabel( "Password: " );
	pwLabel.setLabelFor( passwordField );
	JPanel pwPane = new JPanel();
	FlowLayout pwLayout = (FlowLayout)pwPane.getLayout();
	pwLayout.setAlignment( FlowLayout.LEFT  );
	pwPane.add( pwLabel );
	pwPane.add( passwordField );

	// Message Area underneath the password field
	JTextArea loginText = new JTextArea( loginMsg );
	
	//--------------------------------------------------
	// Setup the content pane
	contentPane = new JPanel();
	contentPane.setLayout(new BoxLayout( contentPane, BoxLayout.Y_AXIS ));
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	unPane.setAlignmentX( Component.LEFT_ALIGNMENT );
	contentPane.add( unPane );
	pwPane.setAlignmentX( Component.LEFT_ALIGNMENT );
	contentPane.add( pwPane );
	loginText.setAlignmentX( Component.LEFT_ALIGNMENT );
	contentPane.add( loginText );

	pack();
	setVisible( true );
    }

    //-
    //-	Methods
    //-

    public void grabInputFocus() {
	userNameField.grabFocus();
    }    

    //------------------------------------------------------------
    //	Action Listener
    //------------------------------------------------------------

    public void actionPerformed(ActionEvent actionEvent) {
	
	String cmd = actionEvent.getActionCommand();

	// When the action was fired at either user name or password
	// field, then ...
	if ( cmd.equals( UNCMD ) || cmd.equals( PWCMD ) ) {

	    // Retrieve user name and password
	    String userName = userNameField.getText();
	    String password = new String( passwordField.getPassword() );

	    System.out.println( "User name ==> " + userName );
	    System.out.println( "Password ==> " + password );

	    // if both user name and password is filled, then send it
	    // to the LISP backend
	    if ( !userName.equals( "" ) && !password.equals( "" ) ) {
		ComManager comManager = AGT.getComManager();
		String fn =
		    "(AGT:AGT-LOGIN " + userName + " " + password + ")";
		comManager.sendAgtCommand( "Login", fn );
	    }
	}
    }
}

//
// $RCSfile$
// 
@
