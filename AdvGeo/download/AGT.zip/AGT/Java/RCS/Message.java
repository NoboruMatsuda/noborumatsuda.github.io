head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2003.11.18.21.11.34;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * Message.java
 *
 *
 * Created: Wed Oct 01 11:57:31 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import javax.swing.*;
import java.awt.*;

public class Message extends MyInternalFrame {

    //*
    //*	Fields * * * * * * * * * * * * * * * * * * * * * * * * * 
    //*

    // Appearance
    Dimension messageSize = new Dimension( 100, 40 );
    Color messageBackground = Color.white;

    // Text area where the message is fed
    JTextArea messageArea = new JTextArea();

    //*
    //*	Constructor * * * * * * * * * * * * * * * * * * * * * *
    //* 

    public Message() {

	super();

	setPreferredSize( messageSize );
	setBackground( messageBackground );
	add( messageArea );

	/*
	  pack();
	  setVisible( true );
	*/
    }
	
    public Message( String msg ) {

	messageArea.setText( msg );

    }

    //*
    //*	Methods * * * * * * * * * * * * * * * * * * * * * * * * * 
    //* 

}

//
// end of $RCSfile$
// 
@
