head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2003.11.18.21.09.05;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * MyInternalFrame.java
 *
 *
 * Created: Mon Nov 03 15:24:35 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import javax.swing.*;

public class MyInternalFrame extends JInternalFrame {

    public MyInternalFrame() {
	ComManager.registerComponent( this );
    }

    public MyInternalFrame( String title,
			    boolean resizable, boolean closable,
			    boolean maximizable, boolean iconifiable ) {
	this();
	super( title, resizable, closable, maximizable, iconifiable );
    }
}

//
// end of $RCSfile$
// 
@
