head	1.1;
access;
symbols;
locks
	NoboruM:1.1; strict;
comment	@# @;


1.1
date	2004.04.15.13.57.02;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * MySocket.java
 *
 *	Socket handling utilities
 *
 * Created: Thu Oct 30 10:59:04 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import java.net.*;
import java.io.*;

public class MySocket extends Socket {

    Socket socket = null;
    PrintWriter socketOut = null;
    BufferedReader socketIn = null;

    public MySocket( String host, int port ) throws IOException {

	try {

	    socket = new Socket( host, port );
	    OutputStream outputStream = socket.getOutputStream();
	    InputStream inputStream = socket.getInputStream();

	    socketOut = new PrintWriter( outputStream, true );
	    socketIn = new BufferedReader(new InputStreamReader(inputStream));

	} catch (UnknownHostException e) {
	    System.err.println( "Unknown host: " + host );
	    System.exit(1);
	} catch (IOException e) {
	    System.err.println( "Failed to connect with " +
				host + ":" + port + " :: " + e );
	    System.exit(1);
	}

    }

    public void close() throws IOException {
	socketOut.close();
	socketIn.close();
	socket.close();
    }

    /**
     *  I/O function
     */

    public String readLine() {
	String str = null;
	try {
	    str = socketIn.readLine();
	} catch ( IOException e ) {
	    e.printStackTrace();
	}
	return str;
    }

    // Read a line 
    public String readLineNoBlock() {

	boolean isReady = false;

	try {
	    isReady = socketIn.ready();
	} catch ( IOException e ) {
	    e.printStackTrace();
	}

	String msg = "";

	if ( isReady ) {
	    try {
		msg = readLine();
	    } catch ( IOException e ) {
		System.out.println("MySocket:readLine() failed");
	    }
	}

	return msg;
    }

    // Write a line
    public void println( Object s ) {
	socketOut.println( s );
    }

}

//
// end of $RCSfile$
//
@
