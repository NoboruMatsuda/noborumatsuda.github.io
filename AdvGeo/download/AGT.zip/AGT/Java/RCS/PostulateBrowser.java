head	1.3;
access;
symbols;
locks
	NoboruM:1.3; strict;
comment	@# @;


1.3
date	2004.02.27.03.28.29;	author NoboruM;	state Exp;
branches;
next	1.2;

1.2
date	2003.12.14.19.36.41;	author noboru;	state Exp;
branches;
next	1.1;

1.1
date	2003.12.01.20.17.29;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.3
log
@*** empty log message ***
@
text
@/**
 * PostulateBrowser.java
 *
 *
 * Created: Mon Oct 27 10:41:06 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id: PostulateBrowser.java 1.2 2003/12/14 19:36:41 noboru Exp noboru $
 */

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/* ------------------------------------------------------------
 *	Postulate Browser
 * ------------------------------------------------------------ */

public class PostulateBrowser extends MyInternalFrame {

    //-
    //-	Fields - - - - - - - - - - - - - - - - - - - - 
    //-

    // The window title
    static String windowTitle = "Postulate Browser";
    int pbWidth, pbHeight;
    
    // The content pane
    JPanel contentPane;

    // Postulate Selector
    int psWidth, psHeight;
    final int PS_HEIGHT = 40;

    // JComboBox holding DS names
    JComboBox comboBox;
    public JComboBox getComboBox() { return comboBox; }

    // JButton to [Select this postulate]
    JButton selectButton;
    final String selectButtonCommand = "select";

    // Geometry configucation
    DiagramDisplay diagramDisplay;
    int ddWidth, ddHeight;

    // Description 
    JTextArea descriptionArea; 
    int daWidth, daHeight;
    Font messageFont = new Font( "Times New Roman", Font.PLAIN, 14 );
    Insets messageMargin = new Insets( 10, 10, 10, 10 );
    
    // List of Deductions
    JTextArea deductionList;
    int dlWidth, dlHeight;

    // Postulate descriptions and configurations; incrementally
    // accumulated on demand
    Hashtable /* String */ postulateDescription = new Hashtable(); 
    Hashtable /* Figure */ postulateConfiguration = new Hashtable();

    //-
    //- Constructor - - - - - - - - - - - - - - - - - 
    //-

    public PostulateBrowser( Dimension size, Point location ) {

	super( windowTitle,
	       false,		// resizable
	       false,		// closable
	       false,		// maximizable
	       false		// iconifiable
	       );

	setPreferredSize( size );
	setLocation( location );
	pbWidth = size.width;
	pbHeight = size.height;

	setupComponents();

	pack();
	setVisible( true );
	
    }
	
    void setupComponents() {

	// Postulate Selector provides a combo box to select a
	// postulte to brows
	// 
	JTextField psLabel = new JTextField( "Postulate : " );
	comboBox = new JComboBox();
	// requestLoadDsName();
	comboBox.addActionListener( new ComboBoxActionListener() );

	selectButton = new JButton( "Selecet" );
	selectButton.setToolTipText( "Click this button to select the postulate" );
	selectButton.setActionCommand( selectButtonCommand );
	selectButton.addActionListener( new SelectButtonActionListener() );
	selectButton.setEnabled( false );

	JPanel postulateSelector = new JPanel();
	FlowLayout layout = (FlowLayout)postulateSelector.getLayout();
	layout.setAlignment( FlowLayout.LEFT  );
	psWidth = pbWidth;
	psHeight = PS_HEIGHT;
	// postulateSelector.setBackground( Color.red );
	postulateSelector.setPreferredSize( new Dimension( psWidth,
							   psHeight ) );
	postulateSelector.add( psLabel );
	postulateSelector.add( comboBox );
	postulateSelector.add( selectButton );

	// The second and third row are put into a split pane
	// 
	// The second row consists of diagram configuration and a
	// description of a postulate.  These two components are put
	// into a holizontal split pane
	//
	ddWidth = pbWidth / 2;
	ddHeight = ( pbHeight - psHeight ) / 2;
	diagramDisplay = new DiagramDisplay( ddWidth, ddHeight );
	
	daWidth = pbWidth / 2;
	daHeight = ( pbHeight - psHeight ) / 2;

	JTextField daLabel = new JTextField( "Description: " );
	daLabel.setMaximumSize( new Dimension( 100, 0 ) );

	descriptionArea = new JTextArea();
	descriptionArea.setLineWrap( true );
	descriptionArea.setWrapStyleWord( true );
	descriptionArea.setFont( messageFont );
	descriptionArea.setMargin( messageMargin );

	JScrollPane daScroll = new JScrollPane( descriptionArea );

	JPanel da = new JPanel();
	da.setLayout( new BoxLayout( da, BoxLayout.Y_AXIS ) );
	da.add( daLabel );
	daLabel.setAlignmentX( Component.LEFT_ALIGNMENT );
	da.add( daScroll );
	daScroll.setAlignmentX( Component.LEFT_ALIGNMENT );

	JSplitPane innerSP = new JSplitPane( JSplitPane.HORIZONTAL_SPLIT,
					     diagramDisplay,
					     da );
	innerSP.setDividerLocation( .5 );

	/*
	// The third row is for the list of deduction
	//
	dlWidth = pbWidth;
	dlHeight = ( pbHeight - psHeight ) / 2;

	JTextField dlLabel = new JTextField( "Deduction: " );
	dlLabel.setMaximumSize( new Dimension( 100, 0 ) );

	deductionList = new JTextArea();
	JScrollPane dlScroll = new JScrollPane( deductionList );

	JPanel dl = new JPanel();
	dl.setLayout( new BoxLayout( dl, BoxLayout.Y_AXIS ) );
	dl.add( dlLabel );
	dlLabel.setAlignmentX( Component.LEFT_ALIGNMENT );
	dl.add( dlScroll );
	dlScroll.setAlignmentX( Component.LEFT_ALIGNMENT );

	JSplitPane splitPane = new JSplitPane( JSplitPane.VERTICAL_SPLIT,
					       innerSP,
					       dl );
	splitPane.setDividerLocation( .5 );
	*/

	// Setup the content pane
	contentPane = new JPanel();
	contentPane.setLayout( new BoxLayout( contentPane,
					      BoxLayout.Y_AXIS ) );
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	postulateSelector.setAlignmentX( Component.LEFT_ALIGNMENT );
	contentPane.add( postulateSelector );
	contentPane.add( splitPane );
    }

    //-
    //-	Methods - - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    // Display <name> in the ComboBox
    public void setSelectedPostulate( String name ) {

	getComboBox().setSelectedItem( name );
    }

    // Enable the selecetButton
    public void enableSelectButton() {

	selectButton.setEnabled( true );
    }

    // Called when the comboBox is clicked empty
    void requestLoadDsName() {
	AGT.getComManager().sendAgtCommand( "PostulateBrowser",
					    "(AGT:BR-LOAD-DS-NAME)" );
	System.out.println("requestLoadDsName: AGT-COMMAND sent");
    }

    // dsNames is a string that contains DS names with single spaces
    // as a separator
    public void loadDsName( String dsNames ) {

	StringTokenizer items = new StringTokenizer( dsNames );

	while ( items.hasMoreTokens() ) {
	    getComboBox().addItem( items.nextToken() );
	}
    }
    
    // Display the description and the configuration of the postulate
    // given by <name>
    void displayPostulate( String name ) {

	// Retrieve description from the hashtable
	String description = (String)postulateDescription.get( name );

	if ( description == null ) {
	    // if the description has never been loaded, then do it
	    // now.
	    requestLoadPostulate( name );
	    // When the request is accepted by the LISP-backend, it
	    // acknowledges by invoking loadPostulate(), which in turn
	    // calls this very method displayPostulate. 
	} else {

	    Figure figure = (Figure)postulateConfiguration.get( name );
	    
	    descriptionArea.setText( description );
	    diagramDisplay.setFigure( figure );
	}
    }

    // Load a postulate configuration and description
    void requestLoadPostulate( String name ) {

	String funCall = "(AGT:BR-LOAD-POSTULATE " + name + ")";
	AGT.getComManager().sendAgtCommand( "PostulateBrowser", funCall );
    }

    // Assert a postulate's description and configuration.  This
    // method is invoked by the LISP-end as an acknowledge for
    // requestLoadPostulate, which is called by displayPostulate
    public void loadPostulate( String name,
			       String description, String configuration ) {

	postulateDescription.put( name, description );

	System.out.println("loadPostulate: new figure...");
	Figure figure = new Figure( configuration );
	postulateConfiguration.put( name, figure );
	System.out.println("... done");

	displayPostulate( name );
    }

    //-
    //- Inner Class - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    /* ------------------------------------------------------------
     *	Action Listener
     * ------------------------------------------------------------ */

    class ComboBoxActionListener implements ActionListener {

	public void actionPerformed(ActionEvent e) {

	    System.out.println("ActionEvent -> " + e);

	    // There is only one comboBox hence the source of event is
	    // obvious
	    // 
	    // JComboBox comboBox = (JComboBox)e.getSource();

	    // if there has been no items installed, then load items
	    // (by sending a request to the LISP back-end to feed
	    // items)
	    if ( comboBox.getItemCount() != 0 ) {
		String name = (String)comboBox.getSelectedItem();
		displayPostulate( name );
	    }
	}
    }

    class SelectButtonActionListener implements ActionListener {
	
	public void actionPerformed(ActionEvent actionEvent) {

	    if (actionEvent.getActionCommand().equals( selectButtonCommand)) {

		selectButton.setEnabled( false );

		String postulate = (String)comboBox.getSelectedItem();

		ComManager comManager = AGT.getComManager();
		comManager.sendStringInput( "PostulateBrowser", postulate );

	    }
	}
    }
}

//
// end of $RCSfile: PostulateBrowser.java $
// 
@


1.2
log
@*** empty log message ***
@
text
@d1 321
a321 315
/**
 * PostulateBrowser.java
 *
 *
 * Created: Mon Oct 27 10:41:06 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id: PostulateBrowser.java 1.1 2003/12/01 20:17:29 NoboruM Exp NoboruM $
 */

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/* ------------------------------------------------------------
 *	Postulate Browser
 * ------------------------------------------------------------ */

public class PostulateBrowser extends MyInternalFrame {

    //-
    //-	Fields - - - - - - - - - - - - - - - - - - - - 
    //-

    // The window title
    static String windowTitle = "Postulate Browser";
    int pbWidth, pbHeight;
    
    // The content pane
    JPanel contentPane;

    // Postulate Selector
    int psWidth, psHeight;
    final int PS_HEIGHT = 40;

    // JComboBox holding DS names
    JComboBox comboBox;
    public JComboBox getComboBox() { return comboBox; }

    // JButton to [Select this postulate]
    JButton selectButton;
    final String selectButtonCommand = "select";

    // Geometry configucation
    DiagramDisplay diagramDisplay;
    int ddWidth, ddHeight;

    // Description 
    JTextArea descriptionArea; 
    int daWidth, daHeight;
    Font messageFont = new Font( "Times New Roman", Font.PLAIN, 14 );
    
    // List of Deductions
    JTextArea deductionList;
    int dlWidth, dlHeight;

    // Postulate descriptions and configurations; incrementally
    // accumulated on demand
    Hashtable /* String */ postulateDescription = new Hashtable(); 
    Hashtable /* Figure */ postulateConfiguration = new Hashtable();

    //-
    //- Constructor - - - - - - - - - - - - - - - - - 
    //-

    public PostulateBrowser( Dimension size, Point location ) {

	super( windowTitle,
	       true,		// resizable
	       true,		// closable
	       true,		// maximizable
	       true		// iconifiable
	       );

	setPreferredSize( size );
	setLocation( location );
	pbWidth = size.width;
	pbHeight = size.height;

	setupComponents();

	pack();
	setVisible( true );
	
    }
	
    void setupComponents() {

	// Postulate Selector provides a combo box to select a
	// postulte to brows
	// 
	JTextField psLabel = new JTextField( "Postulate : " );
	comboBox = new JComboBox();
	requestLoadDsName();
	comboBox.addActionListener( new ComboBoxActionListener() );

	selectButton = new JButton( "Selecet" );
	selectButton.setToolTipText( "Click this button to select the postulate" );
	selectButton.setActionCommand( selectButtonCommand );
	selectButton.addActionListener( new SelectButtonActionListener() );
	selectButton.setEnabled( false );

	JPanel postulateSelector = new JPanel();
	FlowLayout layout = (FlowLayout)postulateSelector.getLayout();
	layout.setAlignment( FlowLayout.LEFT  );
	psWidth = pbWidth;
	psHeight = PS_HEIGHT;
	// postulateSelector.setBackground( Color.red );
	postulateSelector.setPreferredSize( new Dimension( psWidth,
							   psHeight ) );
	postulateSelector.add( psLabel );
	postulateSelector.add( comboBox );
	postulateSelector.add( selectButton );

	// The second and third row are put into a split pane
	// 
	// The second row consists of diagram configuration and a
	// description of a postulate.  These two components are put
	// into a holizontal split pane
	//
	ddWidth = pbWidth / 2;
	ddHeight = ( pbHeight - psHeight ) / 2;
	diagramDisplay = new DiagramDisplay( ddWidth, ddHeight );
	
	daWidth = pbWidth / 2;
	daHeight = ( pbHeight - psHeight ) / 2;

	JTextField daLabel = new JTextField( "Description: " );
	daLabel.setMaximumSize( new Dimension( 100, 0 ) );

	descriptionArea = new JTextArea();
	descriptionArea.setLineWrap( true );
	descriptionArea.setFont( messageFont );
	JScrollPane daScroll = new JScrollPane( descriptionArea );

	JPanel da = new JPanel();
	da.setLayout( new BoxLayout( da, BoxLayout.Y_AXIS ) );
	da.add( daLabel );
	daLabel.setAlignmentX( Component.LEFT_ALIGNMENT );
	da.add( daScroll );
	daScroll.setAlignmentX( Component.LEFT_ALIGNMENT );

	JSplitPane innerSP = new JSplitPane( JSplitPane.HORIZONTAL_SPLIT,
					     diagramDisplay,
					     da );
	innerSP.setDividerLocation( .5 );

	// The third row is for the list of deduction
	//
	dlWidth = pbWidth;
	dlHeight = ( pbHeight - psHeight ) / 2;

	JTextField dlLabel = new JTextField( "Deduction: " );
	dlLabel.setMaximumSize( new Dimension( 100, 0 ) );

	deductionList = new JTextArea();
	JScrollPane dlScroll = new JScrollPane( deductionList );

	JPanel dl = new JPanel();
	dl.setLayout( new BoxLayout( dl, BoxLayout.Y_AXIS ) );
	dl.add( dlLabel );
	dlLabel.setAlignmentX( Component.LEFT_ALIGNMENT );
	dl.add( dlScroll );
	dlScroll.setAlignmentX( Component.LEFT_ALIGNMENT );

	JSplitPane splitPane = new JSplitPane( JSplitPane.VERTICAL_SPLIT,
					       innerSP,
					       dl );
	splitPane.setDividerLocation( .5 );

	// Setup the content pane
	contentPane = new JPanel();
	contentPane.setLayout( new BoxLayout( contentPane,
					      BoxLayout.Y_AXIS ) );
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	postulateSelector.setAlignmentX( Component.LEFT_ALIGNMENT );
	contentPane.add( postulateSelector );
	contentPane.add( splitPane );
    }

    //-
    //-	Methods - - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    // Display <name> in the ComboBox
    public void setSelectedPostulate( String name ) {

	getComboBox().setSelectedItem( name );
    }

    // Enable the selecetButton
    public void enableSelectButton() {

	selectButton.setEnabled( true );
    }

    // Called when the comboBox is clicked empty
    void requestLoadDsName() {
	AGT.getComManager().sendAgtCommand( "PostulateBrowser",
					    "(AGT:BR-LOAD-DS-NAME)" );
	System.out.println("requestLoadDsName: AGT-COMMAND sent");
    }

    // dsNames is a string that contains DS names with single spaces
    // as a separator
    public void loadDsName( String dsNames ) {

	StringTokenizer items = new StringTokenizer( dsNames );

	while ( items.hasMoreTokens() ) {
	    getComboBox().addItem( items.nextToken() );
	}
    }
    
    // Display the description and the configuration of the postulate
    // given by <name>
    void displayPostulate( String name ) {

	// Retrieve description from the hashtable
	String description = (String)postulateDescription.get( name );

	if ( description == null ) {
	    // if the description has never been loaded, then do it
	    // now.
	    requestLoadPostulate( name );
	    // When the request is accepted by the LISP-backend, it
	    // acknowledges by invoking loadPostulate(), which in turn
	    // calls this very method displayPostulate. 
	} else {

	    Figure figure = (Figure)postulateConfiguration.get( name );
	    
	    descriptionArea.setText( description );
	    diagramDisplay.setFigure( figure );
	}
    }

    // Load a postulate configuration and description
    void requestLoadPostulate( String name ) {

	String funCall = "(AGT:BR-LOAD-POSTULATE " + name + ")";
	AGT.getComManager().sendAgtCommand( "PostulateBrowser", funCall );
    }

    // Assert a postulate's description and configuration.  This
    // method is invoked by the LISP-end as an acknowledge for
    // requestLoadPostulate, which is called by displayPostulate
    public void loadPostulate( String name,
			       String description, String configuration ) {

	postulateDescription.put( name, description );

	System.out.println("loadPostulate: new figure...");
	Figure figure = new Figure( configuration );
	postulateConfiguration.put( name, figure );
	System.out.println("... done");

	displayPostulate( name );
    }

    //-
    //- Inner Class - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    /* ------------------------------------------------------------
     *	Action Listener
     * ------------------------------------------------------------ */

    class ComboBoxActionListener implements ActionListener {

	public void actionPerformed(ActionEvent e) {

	    System.out.println("ActionEvent -> " + e);

	    // There is only one comboBox hence the source of event is
	    // obvious
	    // 
	    // JComboBox comboBox = (JComboBox)e.getSource();

	    // if there has been no items installed, then load items
	    // (by sending a request to the LISP back-end to feed
	    // items)
	    if ( comboBox.getItemCount() != 0 ) {
		String name = (String)comboBox.getSelectedItem();
		displayPostulate( name );
	    }
	}
    }

    class SelectButtonActionListener implements ActionListener {
	
	public void actionPerformed(ActionEvent actionEvent) {

	    if (actionEvent.getActionCommand().equals( selectButtonCommand)) {

		selectButton.setEnabled( false );

		String postulate = (String)comboBox.getSelectedItem();

		ComManager comManager = AGT.getComManager();
		comManager.sendMouseClick( "PostulateBrowser", postulate );

	    }
	}
    }
}

//
// end of $RCSfile: PostulateBrowser.java $
// 
@


1.1
log
@Initial revision
@
text
@d8 1
a8 1
 * @@version $Id$
d15 2
d43 4
d51 4
a54 3
    // List of Propositions
    JTextArea propositionList; 
    int plWidth, plHeight;
d60 5
d87 1
d100 6
d116 1
d120 3
a122 3
	// The second row consists of diagram configuration and a list
	// of propositions.  These two components are put into a
	// holizontal split pane
d128 2
a129 2
	plWidth = pbWidth / 2;
	plHeight = ( pbHeight - psHeight ) / 2;
d131 2
a132 2
	JTextField plLabel = new JTextField( "Propositions: " );
	plLabel.setMaximumSize( new Dimension( 100, 0 ) );
d134 11
a144 9
	propositionList = new JTextArea();
	JScrollPane plScroll = new JScrollPane( propositionList );

	JPanel pl = new JPanel();
	pl.setLayout( new BoxLayout( pl, BoxLayout.Y_AXIS ) );
	pl.add( plLabel );
	plLabel.setAlignmentX( Component.LEFT_ALIGNMENT );
	pl.add( plScroll );
	plScroll.setAlignmentX( Component.LEFT_ALIGNMENT );
d148 1
a148 1
					     pl );
d190 12
d220 46
d278 2
d289 19
a307 2
		String name = comboBox.getSelectedItem();
		requestLoadPostulate( name );
d314 1
a314 1
// end of $RCSfile$
@
