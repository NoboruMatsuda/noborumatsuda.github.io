head	1.1;
access;
symbols;
locks
	NoboruM:1.1; strict;
comment	@# @;


1.1
date	2003.05.07.22.06.05;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * Problem.java
 *
 *	Description of a problem
 *
 * Created: Sat May 11 12:10:15 2002
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import java.io.*;

public class Problem {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // Problem figure
    Figure figure;

    // Problem premises and goal
    Object premises, goal;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public Problem () {

	figure = new Figure();
	
    }

    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------*/

    /**
     *	Load a problem
     */
    void loadProblem( String filePath ) {

	FileInputStream in;
	try {
	    in = new FileInputStream( filePath );
	} catch ( IOException e ) {
	    System.err.println( "Can't open file: " + filePath );
	    return;
	}

	// Setup a stream to read LISP expressions
	lisp.LispInterpreter interpreter = new lisp.LispInterpreter( in );
	Object elements = null;

	try {
	    elements = interpreter.getReader().read();
	    this.premises = interpreter.getReader().read();
	    this.goal = interpreter.getReader().read();
	} catch ( lisp.LispException e ) {
	} catch ( Exception e ) {
	}

	// read problem configuration into figure object
	figure.readConfigurationFromLispExp( elements );

	// Close the problem file
	try {
	    in.close();
	} catch (IOException e) {
	}

    }
    
}// Problem
@
