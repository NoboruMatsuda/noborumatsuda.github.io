head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2003.09.29.12.56.15;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * ProofTable.java
 *
 *	Proof Table window
 *
 * Created: Thu Sep 25 16:14:31 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ProofTable extends JInternalFrame { 
    
    /* ------------------------------------------------------------ 
     *	Fields
     * ------------------------------------------------------------*/ 

    // The window title
    static String theTitle = "Proof";

    // The Content Pane
    JPanel contentPane;

    // The proof table
    Vector /* JPanel */ proofRows = new Vector();
    JPanel proofPane;
    String[] columnNames = { "Proposition", "Justification" };
    final String CLICK_HERE_MESSAGE = 
	"Click here to input your justification";
    
    final String BLANK_TEXT_FIELD = "";

    // ActionCommands Proof Row
    final int PROPOSITION_FIELD = 1;
    final int SUPPORTER_FIELD = 2;
    final int PREMISE_FIELD = 3;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public ProofTable( Dimension size, Point location,
		       String goal, Vector premises ) {
	
	// Make an internal frame
	super( theTitle,
	       true,		// resizable
	       true,		// closable
	       true,		// maximizable
	       true		// iconifiable
	       );
	
	//System.out.println("size: " + size + ", location: " + location );
	
	setPreferredSize( size );
	setLocation( location );

	// Create the content pane
	contentPane = new JPanel();
	// contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	proofRows = initialProofRows( goal, premises );
	proofPane = new ProofPane( proofRows );
	contentPane.add( proofPane );

	// Shape up the window
	pack();
	setVisible( true );
    }
    
    /* ------------------------------------------------------------
     *	Class methods
     * ------------------------------------------------------------*/

    // <premises> is a vector of String
    Vector initialProofRows( String goal, Vector /* String */ premises ) {
	
	Vector proofRows = new Vector();

	// Premise
	Enumeration premisesElements = premises.elements();
	while ( premisesElements.hasMoreElements() ) {
	    String premise = (String)premisesElements.nextElement();
	    proofRows.add( new ProofRow( premise, "Premise" ) );
	}

	// Blank row
	proofRows.add( new ProofRow("", "") );

	// Goal
	proofRows.add( new ProofRow( goal, "" ) );

	return proofRows;
    }

    // Insert a new proof row into the proof table
    void insertProofRowAt( String proposition, String premise, int position ) {

	System.out.println("insert proof row at " + position +
			   " for \"" + proposition + "\", \"" +
			   premise + "\"");

	// Make a new proof row
	ProofRow proofRow = new ProofRow( proposition, premise );

	// insert it into the existing proof rows 
	proofRows.insertElementAt( proofRow, position );

	// replace proof table with the new one
	ProofPane newProofPane = new ProofPane( proofRows );
	contentPane.remove( proofPane );
	proofPane = newProofPane;
	contentPane.add( proofPane );
    }

    //-
    //- Lookup
    //- 
    
    // Return a ProofRow that has <id> as its ID
    ProofRow lookupProofRow( int id ) {

	Enumeration proofRowElements = proofRows.elements();
	while ( proofRowElements.hasMoreElements() ) {
	    ProofRow proofRow = (ProofRow)proofRowElements.nextElement();
	    if ( proofRow.getID() == id ) {
		return proofRow;
	    }
	}
	return null;
    }

    // Return a ProofRow that has <equation> as its proposition
    ProofRow lookupProofRowWithProposition( String equation ) {

	Enumeration proofRowElements = proofRows.elements();
	while ( proofRowElements.hasMoreElements() ) {
	    ProofRow proofRow = (ProofRow)proofRowElements.nextElement();
	    String proposition = proofRow.getProposition().getProposition();
	    
	    if ( proposition.equals( equation ) ) {
		return proofRow;
	    }
	}
	return null;
    }

    /* ------------------------------------------------------------
     *	Inner Classes
     * ------------------------------------------------------------*/

    /**
     *	A proof table that holds proof rows.  Each time a row is added
     *	or removed, a new proofPane is created and added onto the 
     *	contentPane of the top-most inner frame
     **/
    class ProofPane extends JPanel {

	public ProofPane( Vector tableRows ) {

	    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

	    add( newHeader() );
	    Enumeration theTableRows = tableRows.elements();
	    while ( theTableRows.hasMoreElements() ) {
		JPanel row = (JPanel)theTableRows.nextElement();
		add( row );
	    } // end of while ()
	}

	// Make a header for a proof table
	JPanel newHeader() {

	    JPanel proposition = new JPanel();
	    proposition.add( new JLabel( columnNames[0] ) );
	    
	    JPanel justification = new JPanel();
	    justification.add( new JLabel( columnNames[1] ) );

	    JPanel header = new JPanel();
	    header.setLayout( new BoxLayout(header, BoxLayout.X_AXIS) );
	    header.add( proposition );
	    header.add( justification );

	    return header;
	}
    }

    // Number of ProofRows created.  Inner class can't have a static
    // field
    static int numProofRow = 0;

    /**
     *	A row in the proof table that consists of a Proposition and a
     *	Justification
     **/
    class ProofRow extends JPanel {

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	Field
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

	// Unique number to identify each ProofRow object
	int ID;

	public int getID() { return ID; }

	Proposition proposition;
	Justification justification;

	public Justification getJustification() { return justification; }
	public Proposition getProposition() { return proposition; }

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	Constructor
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

	// a proof statement with a single justification, i.e.,
	// "Premise"
	public ProofRow( String proposition, String justification ) {

	    ID = numProofRow++;

	    this.proposition = new Proposition( proposition, ID );
	    this.justification = new Justification( justification, ID );

	    setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
	    add( this.proposition );
	    add( this.justification );
	}

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	Constructor
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

	// Called when a supporter is filled up
	public void supporterFed() {
	    justification.supporterFed();
	}
    }

    /**
     *	A Proposition in a ProofRow
     **/
    class Proposition extends JTextField {

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	Fields
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

	// The ID of this object
	int ID;
	// String representation of the proposition itself
	// String proposition;

	// public String getProposition() { return proposition; }
	public String getProposition() { return getText(); }

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	Constructor
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

	// ID is used as a link to its parent, i.e., a ProofRow that
	// hold this object
	public Proposition( String proposition, int ID ) {
	    super( proposition );
	    this.ID = ID;
	    // this.proposition = proposition;
	    
	    // When a proposition is fed, keep it intact
	    if ( !proposition.equals("") ) {
		setEditable( false );
	    }

	    addMouseListener( new PropositionMouseListener() );
	    setActionCommand( ID + ""); 
	    addActionListener( new PropositionActionListener() ); 
	}
    }

    // The Justification object that gets focus on
    Justification currentJustification = null;

    Justification getCurrentJustification() {
	return currentJustification;
    }
    
    void setCurrentJustification (Justification justification) {
	currentJustification = justification;
    }

    /**
     *	A Justification in a ProofRow
     **/
    class Justification extends JPanel {

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	Fields
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

	// The same number as its parent's ID
	int ID;

	// The name of a postulate that support this justification, or
	// other text string (e.g., "premise") that explain the
	// justification
	JTextField supporter = new JTextField( BLANK_TEXT_FIELD );
	public JTextField getSupporter() { return supporter; }

	// A list of premises 
	Vector /* JTextField */ premises = new Vector();
	// Number of premises associated to this justification
	int numPremises = 0; 
	// Flag telling if the use is expected to input premises
	boolean premiseFieldOpen = false;

	// The premise that is supporsed to be filled 
	JTextField targetPremiseField;

	void setTargetPremiseField( JTextField premise ) {
	    targetPremiseField = premise;
	}

	public JTextField getTargetPremiseField() {
	    return targetPremiseField;
	}

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	Constructor
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

	// This is called for a single line justification, which
	// doesn't involve a postulate application.  ID is used as
	// link to its parent, i.e., a ProofRow that holds this object
	public Justification( String justification, int ID ) {

	    this.ID = ID;

	    if ( justification == "")
		supporter.setToolTipText( CLICK_HERE_MESSAGE );
	    else
		supporter.setText( justification );

	    setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

	    supporter.setActionCommand( supporterID( ID ) );
	    supporter.addActionListener( new JustificationActionListener() );
	    // supporter.addMouseListener( new ProofTableMouseListener() );
	    add( supporter );
	}

	/* - - - - - - - - - - - - - - - - - - - - - - - - - - -
	 *	Class Methods
	 * - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

	// Create a string fed as an actionCommand for the supporter's
	// Text Field
	String supporterID( int ID ) {
	    return ( SUPPORTER_FIELD + ":" + ID );
	}

	// Called when the supporter gets typed in
	public void supporterFed() {

	    String support = supporter.getText();

	    if ( isPostulateName( support ) ) {
		// User input a posulate as a support hence need to
		// let the user input premisese
		openPremiseFields();
	    } else if ( !isValidSupport( support ) ) {
		System.out.println("Invalid support: " + support);
	    }
	}

	// Get read to read premises and let the user enter them
	void openPremiseFields() {

	    premiseFieldOpen = true;
	    setCurrentJustification( this );

	    JLabel premiseLabel = new JLabel( "Premise: " );
	    add( premiseLabel );
	    pack();
	    newPremiseField();
	}

	// Finish reading premises
	void closePremiseFields() {
	    premiseFieldOpen = false;
	    clearCurrentJustification();
	    // The last premise field, which is left blank, must be
	    // removed
	    remove( getTargetPremiseField() );
	    pack();
	}

	void clearCurrentJustification() {
	    currentJustification = null;
	}

	// Create new Premise field
	void newPremiseField() {

	    if ( isPremiseFieldOpen() ) {

		JTextField premise = new JTextField( "" );
		premise.setActionCommand( PREMISE_FIELD + ":" + ID );
		premise.addActionListener( new JustificationActionListener() );
		setTargetPremiseField( premise );
		
		// add the premise into the Vector 
		premises.add( premise );
		// add it as a GUI component
		add( premise );
		pack();
	    }
	}

	// Called when the user clicked on a <proposition> button as a
	// specified premise, or the user input <proposition> into the
	// premise text field.  <contractor> shows the origin of input.  
	public void premiseEntered( int contractor, String proposition ) {

	    boolean validInput = true;

	    if ( isPremiseFieldOpen() ) {

		JTextField premiseField = getTargetPremiseField();
		String premise = premiseField.getText();
		
		switch ( contractor ) {
		case PROPOSITION_FIELD: 
		    // Proposition button is pressed
		    premiseField.setText( proposition );
		    break;
		    
		case PREMISE_FIELD:
		    // Premise Field gets text input
		    if ( premise.equals( "" ) ) {
			// Entering null in a premise field signals to
			// close entering premises
			validInput = false;
			closePremiseFields();
		    } else if (lookupProofRowWithProposition(premise) == null){
			// The premise input is new which happens only
			// in a backward inference hence need to
			// insert a new proof row with unjustified
			// proposition right above the current
			// justification (spcified by ID).
			insertProofRowAt( premise, "", ID );
		    } else {
			// The premise entered has been in the proof
			// table
			premiseField.setText( "" );
			validInput = false;
		    }
		    break;
		}
		// Only when the premise has been input properly, add
		// next premise field
		if ( validInput )
		    newPremiseField();
	    }
	}

	// 
	boolean isPremiseFieldOpen() {
	    return premiseFieldOpen;
	}

	// Verify if the <support> is a postulate name
	boolean isPostulateName( String support ) {
	    return true;
	}

	// verify if the <support> is a valid statement
	boolean isValidSupport( String support ) {
	    return true;
	}
    }

    /**
     *	Action Listener for Justification
     **/
    class JustificationActionListener implements ActionListener {
	
	// Identifies the text field in a ProofRow that has signaled
	// the event
	public void actionPerformed(ActionEvent actionEvent) {

	    // actionEvent must be "componentType:ID" 
	    String command = actionEvent.getActionCommand();
	    int componentType = getComponentID( command );
	    
	    switch ( componentType ) {
	    case PREMISE_FIELD:
		JTextField premiseField = (JTextField)actionEvent.getSource();
		String premise = premiseField.getText();
		getCurrentJustification().premiseEntered( PREMISE_FIELD,
							  premise );
		break;
		
	    case SUPPORTER_FIELD:
		int supporterID = getSupporterID( command );
		ProofRow theProofRow = lookupProofRow( supporterID );
		theProofRow.supporterFed();
		break;
	    }
	}

	// Extract component ID (e.g., "supporter") out of the
	// <actionCommand>, which must be "supporter:ID"
	int getComponentID( String actionCommand ) {

	    int delimiterPos = actionCommand.indexOf( ':' );
	    String ID = actionCommand.substring( 0, delimiterPos );
	    return ( Integer.parseInt( ID ) );
	}

	int getSupporterID( String actionCommand ) {

	    int delimiterPos = actionCommand.indexOf( ':' );
	    String IDstr = actionCommand.substring( delimiterPos+1 );
	    return Integer.parseInt( IDstr );
	}
    }

    /**
     *	Action Listener for Proposition
     **/
    class PropositionActionListener implements ActionListener {
	
	public void actionPerformed(ActionEvent actionEvent) {

	    Proposition source = (Proposition)actionEvent.getSource();
	    source.setEditable( false );
	}
    }

    /**
     *	Mouse Listener for Proposition 
     **/
    class PropositionMouseListener implements MouseListener {
	
	// - 
	// - Implementation of java.awt.event.MouseListener
	// -

	public void mouseClicked(MouseEvent mouseEvent) {

	    Proposition source = (Proposition)mouseEvent.getComponent();
	    String proposition = source.getProposition();

	    if ( !proposition.equals("") ) {
		Justification justification = getCurrentJustification();
		justification.premiseEntered( PROPOSITION_FIELD, proposition );
	    }
	}

	public void mousePressed(MouseEvent mouseEvent) {}

	public void mouseReleased(MouseEvent mouseEvent) {}

	public void mouseEntered(MouseEvent mouseEvent) {}

	public void mouseExited(MouseEvent mouseEvent) {}
    }
}

// 
// end of $RCSfile$
//
@
