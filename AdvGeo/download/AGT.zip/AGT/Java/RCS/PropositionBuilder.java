head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2004.02.24.21.36.03;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * PropositionBuilder.java
 *
 *	Proposition Builder window
 
 * Created: Wed Sep 24 16:43:32 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PropositionBuilder extends MyInternalFrame implements ActionListener {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------ */

    // The window title
    static String theTitle = "Proposition Buider";

    // The DiagramDisplay object that is a subject of clicking to
    // enter elements
    DiagramDisplay diagramDisplay;

    // The Content Pane
    JPanel contentPane;

    // The pane that lists buttons.  Placed on the left side
    JPanel buttonPane;

    // Labels on the buttons followed by tool tip texts.  Do not try
    // to delete or reorder the labels for they are used everywhere in
    // this module in the way that the order matters.  
    String buttonLabel[][] = {{"<_ = <_", "Angle equality"},
			      {"_ = _", "Segment equality"},
			      {"^_ # ^_", "Triangle congruence"},
			      {"_ // _", "Segment parallel"},
			      {"_ midpoint _", "Midpoint"}
    };

    // Done button
    JButton doneButton;
    public JButton getDoneButton() { return doneButton; }
    final String DONE_BUTTON_LABEL = "DONE";
    final String DONE_BUTTON_TIP_TEXT = "Press to complete your input";
    final String doneButtonID = "doneButton";

    // The pane that holds text areas.  Placed on the right side
    JPanel textPane;
    JTextArea messageArea;
    JTextField inputArea;
    public JTextField getInputArea() { return inputArea; }
    final int INPUT_AREA_SIZE = 15;
    final String inputAreaID = "inputArea";

    // The proposition made by student
    final String THE_PROPOSITION_MSG = "Proposition made: ";
    String propositionType = "";
    String theProposition = "";
    String lastInput = "";
    JLabel thePropositionLabel;
    
    // Flag to tell if one can make an input
    boolean allowReadInput = false;

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public PropositionBuilder( Dimension size, Point location ) {
	
	// Make an internal frame
	super( theTitle,
	       true,		// resizable
	       true,		// closable
	       true,		// maximizable
	       true		// iconifiable
	       );

	// setPreferredSize( size );
	setLocation( location );
	
	// Create the content pane
	contentPane = new JPanel();
	contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	// Create the button pane
	buttonPane = new JPanel();
	buttonPane.setLayout(new BoxLayout(buttonPane, BoxLayout.Y_AXIS));
	makeButtons( buttonPane );
	contentPane.add( buttonPane );

	// Create the text pane
	textPane = new JPanel();
	textPane.setLayout(new BoxLayout(textPane, BoxLayout.Y_AXIS));
	makeTextAreas( textPane );
	contentPane.add( textPane );

	pack();
	setVisible( true );

    } // PropositionBuilder constructor
    
    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------ */

    /**
     *	Add Buttons
     **/
    void makeButtons( JPanel buttonPane ) {

	for ( int i = 0; i < buttonLabel.length; i++ ) {

	    JButton button = new JButton( buttonLabel[i][0] );
	    button.setToolTipText( buttonLabel[i][1] );
	    button.setActionCommand( buttonLabel[i][0] );
	    button.addActionListener( this );
	    buttonPane.add( button );
	    
	} // end of for ()

	doneButton = new JButton( DONE_BUTTON_LABEL );
	doneButton.setToolTipText( DONE_BUTTON_TIP_TEXT );
	doneButton.setActionCommand( doneButtonID );
	doneButton.addActionListener( this );
	buttonPane.add( doneButton );
	doneButton.setEnabled( false );
    }

    /**
     *	Layout text fields
     **/
    void makeTextAreas( JPanel textPane ) {

	// The message area
	messageArea = new JTextArea( "A message appears here." );
	messageArea.setLineWrap(true);
	messageArea.setWrapStyleWord(true);
	JScrollPane areaScrollPane = new JScrollPane( messageArea );
	areaScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	areaScrollPane.setPreferredSize( new Dimension(250, 100) );
	textPane.add( areaScrollPane );

	// The input area
	inputArea = new JTextField( INPUT_AREA_SIZE );
	inputArea.setActionCommand( inputAreaID );
	inputArea.addActionListener( this );
	JLabel inputAreaLabel = new JLabel( "Enter here: " );
	inputAreaLabel.setLabelFor( inputArea );
	JPanel inputAreaPane = new JPanel();
	inputAreaPane.setLayout( new BoxLayout( inputAreaPane,
						BoxLayout.X_AXIS ) );
	inputAreaPane.add( inputAreaLabel );
	inputAreaPane.add( inputArea );
	textPane.add( inputAreaPane );
	// No input allowed at the beginning
	disableInput();

	// The output Area
	thePropositionLabel = new JLabel( THE_PROPOSITION_MSG );
	textPane.add( thePropositionLabel );
	
    }

    /**
     *	Scaffolding to make each type of proposition
     **/

    // Angle Equality
    void assistAngEqual() {

	propositionType = buttonLabel[0][0];
	String message =
	    "You have chosen to compose a proposition about " +
	    "angle equality.\n" +
	    "Select two angles, one at a time, by clicking a figure or " +
	    "enter names from a keyboard.\n" +
	    "Click [Cancel] if you wish to quit and try anything else.\n";

	setMessage( message );
	setProposition( buttonLabel[0][0] );
	enteringFirstElement();
    }

    // Segment Equality
    void assistSegEqual() {

	String message =
	    "You have chosen to compose a proposition about " +
	    "segment equality.\n" +
	    "Select two segments, one at a time, by clicking a figure or " +
	    "enter their names from keyboard.\n" +
	    "Click [Cancel] if you wish quit this and try anything else.\n";

	setMessage( message );
	setProposition( buttonLabel[1][0] );
	enteringFirstElement();
    }

    // Triangle Congruence
    void assistTriCong() {

	String message = "";
	setMessage( message );
	setProposition( buttonLabel[2][0] );
	enteringFirstElement();
    }

    // Segment Parallel
    void assistSegParallel() {

	String message = "";
	setMessage( message );
	setProposition( buttonLabel[3][0] );
	enteringFirstElement();
    }

    // Midpoint
    void assistMidPoint() {

	String message = "";
	setMessage( message );
	setProposition( buttonLabel[4][0] );
	enteringFirstElement();
    }

    // Update texts in the messagArea
    void setMessage( String message ) {
	messageArea.setText( message );
    }

    // Update proposition entered
    void setProposition( String tmpProposition ) {
	theProposition = tmpProposition;
	thePropositionLabel.setText( THE_PROPOSITION_MSG + theProposition );
    }

    // 
    void ageInput( String proposition ) {
	lastInput = theProposition;
	setProposition( proposition );
    }

    // Get an element that is eiter entered by keyboard or clicked on
    // the figure.  This method is also called by DiagramDisplay
    // object when it is clicked.
    public void getGeometricElement( String obj ) {

	// Verify if it's a good time to read an element or not.
	if ( allowReadInput ) {
	    // Verify if it's a right type of element
	    if ( isCorrectType( propositionType, obj ) ) {

		// Update proposition
		String newProposition = modifyProposition( obj );
		ageInput( newProposition );

		if ( !isCompleteProposition( newProposition ) ) {
		    // If the proposition has two arguments and this is
		    // the firt input, then do the second half of input,
		    enteringSecondElement();
		} else {
		    // else activate [DONE] button so that
		    // completeProposition can be called
		    doneButton.setEnabled( true );
		    disableInput();
		}
	    }
	}
    }

    // replace '_' in <theProposition> with the <element>
    String modifyProposition( String element ) {
	return theProposition.replaceFirst( "_", element );
    }

    // Verify if <proposition> has been filled up, i.e., all the '_'
    // have been replaced
    boolean isCompleteProposition( String proposition ) {
	return ( proposition.indexOf( '_' ) == -1 );
    }

    // Verifty if <obj> fits in the <propositionType>
    boolean isCorrectType( String propositionType, String obj ) {
	return true;
    }

    // Get ready to read input
    void enableInput() {
	allowReadInput = true;
	inputArea.setEnabled( true );
    }

    // Shutdown input channel
    void disableInput() {
	allowReadInput = false;
	inputArea.setEnabled( false );
    }

    // Let the proposition builder that the user is about to input the
    // first element of the target proposition
    void enteringFirstElement() {
	enableInput();
    }

    // The user is now about to input the second element
    void enteringSecondElement() {
	;
    }

    // Activated by [Done] button.  Hold the final 
    public void completeProposition() {
	disableInput();
	doneButton.setEnabled( false );
	ageInput( theProposition );

	// Mon Dec 01 16:38:06 2003
	// ToDo
	// 
	// Notify input to the communication manager
	// ComManager comManager = AGT.getComManager();
	// comManager.dispatch( getDoneButton(), theProposition );
    }

    // =
    // = Implementation of java.awt.event.ActionListener
    // = 

    /**
     * Describe <code>actionPerformed</code> method here.
     *
     * @@param actionEvent an <code>ActionEvent</code> value
     */
    public void actionPerformed(ActionEvent e) {

	String command = e.getActionCommand();

	// for buttons to compose a proposition
	if ( command.equals( buttonLabel[0][0] ) ) {
	    assistAngEqual();
	} else if ( command.equals( buttonLabel[1][0] ) ) {
	    assistSegEqual();
	} else if ( command.equals( buttonLabel[2][0] ) ) {
	    assistTriCong();
	} else if ( command.equals( buttonLabel[3][0] ) ) {
	    assistSegParallel();
	} else if ( command.equals( buttonLabel[4][0] ) ) {
	    assistMidPoint();
	} else if ( command.equals( doneButtonID ) ) {
	    completeProposition();
	} else if ( command.equals( inputAreaID ) ) {
	    getGeometricElement( inputArea.getText() );
	    inputArea.setText("");
	}
    }
}

//
// end of $RCSfile$
// 
@
