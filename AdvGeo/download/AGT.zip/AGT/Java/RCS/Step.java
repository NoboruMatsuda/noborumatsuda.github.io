head	1.1;
access;
symbols;
locks
	noboru:1.1; strict;
comment	@# @;


1.1
date	2003.10.04.17.16.16;	author NoboruM;	state Exp;
branches;
next	;


desc
@@


1.1
log
@Initial revision
@
text
@/**
 * Step.java
 *
 *
 * Created: Wed Oct 01 12:11:39 2003
 *
 * @@author <a href="mailto:mazda@@pitt.edu">Noboru Matsuda</a>
 * @@version $Id$
 */

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Describe class <code>Step</code> here.
 *
 */
class Step extends JPanel implements MouseListener {

    /* - - - - - - - - - - - - - - - - - - - - - - - - -
     *	Fields
     * - - - - - - - - - - - - - - - - - - - - - - - - - */

    final int STEP_BORDER = 10;
    // Height of step componet in the inference tab
    final int STEP_HEIGHT = 30;
    // Amount of indentation by 1 level
    final int STEP_INDENT = 20;
    // 
    Color stepBackground = Color.white;

    // Name of the step
    String name = "";

    // Description of the step
    String content = "";
    public String getContent() { return content; }
    public void setContent(String newContent) { this.content = newContent; }

    JLabel contentLabel = new JLabel();
    public void updateContent( String content ) {
	setContent( content );
	contentLabel.setText( content );
    }

    // Indentation
    Component boxIndent = null;

    // General explanation of the step
    String explanation;

    // Subseps
    Vector /* Step */ substep = new Vector();

    public Vector /* Step */ getSubstep() { return substep; }

    public void addSubstep( Step step ) {
	substep.add( step );
	step.setSuperStep( this );
    }

    // superstep
    Step superStep = null;

    /**
     * Get the SuperStep value.
     * @@return the SuperStep value.
     */
    public Step getSuperStep() {
	return this.superStep;
    }

    /**
     * Set the SuperStep value.
     * @@param newSuperStep The new SuperStep value.
     */
    public void setSuperStep(Step newSuperStep) {
	// System.out.println(this.getName() + "->" + newSuperStep.getName());
	this.superStep = newSuperStep;
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - -
     *	Constructor
     * - - - - - - - - - - - - - - - - - - - - - - - - - */

    public Step() {

	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
	setAlignmentX( JComponent.LEFT_ALIGNMENT );
	setBorder( BorderFactory.createEmptyBorder( STEP_BORDER,
						    STEP_BORDER,
						    STEP_BORDER,
						    STEP_BORDER ) );
	setBackground( stepBackground );

	// Make the Step component neatly fit into the inference tab
	Dimension size = AGT.getInferenceStep().getTabSize();
	Dimension stepSize = new Dimension( size.width, STEP_HEIGHT );
	setPreferredSize( stepSize );

	addMouseListener( this );
    }

    public Step( String name, String content ) {

	this();
	setContent( content );
	setName( name );

	this.boxIndent = boxIndent( 0 );
	add( boxIndent );
	add( new JLabel( "[" + name + "] ") );
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - -
     *	Methods
     * - - - - - - - - - - - - - - - - - - - - - - - - - */

    // Update indent level through out the step tree
    public void propagateLevel() {

	remove( boxIndent );
	add( boxIndent( getLevel() ), 0 );
	
	if ( !getSubstep().isEmpty() ) {

	    Enumeration iterator = getSubstep().elements();
	    while ( iterator.hasMoreElements() ) {
		((Step)iterator.nextElement()).propagateLevel();
	    }
	}
    }

    // Depth of the step used to make an indentation
    public int getLevel() {

	// System.out.println("getLebel: " + getName());

	if ( getSuperStep() == null ) {
	    // System.out.println("got bottom");
	    return 0;
	} else {
	    return getSuperStep().getLevel() + 1;
	}
    }

    Component boxIndent( int level ) {

	return Box.createHorizontalStrut( level * STEP_INDENT );
    }

    // ============================================================
    // Provide scaffolding on the step
    // 
    // Scaffolding Policy:
    // 
    // For steps that have substeps, message appears telling what the
    // current step for and a list of substeps.
    // 
    // For steps that do not have substeps, invoke its own diapatch
    // method and allow students to follow the step.
    // 
    public void scaffolding() {

	stepExplanation();

	if ( substep.isEmpty() )
	    // This step has no substeps hence need to "execute"
	    // necessary things.
	    dispatch();
	else
	    // This step does have substeps, which must be expanded
	    // now.
	    expandSubsteps();
	
	add( contentLabel );
	updateContent( getContent() );
	// add( new JLabel( getContent() ) );
    }

    // Display general explanation of the step
    public void stepExplanation() {
	JOptionPane.showMessageDialog( this, explanation );
    }

    // Expand and insert substeps
    void expandSubsteps() {

	Enumeration iterator = getSubstep().elements();
	InferenceStep inferenceStep = AGT.getInferenceStep();
	Step previousStep = this;
	
	while ( iterator.hasMoreElements() ) {
	    Step step = (Step)iterator.nextElement();
	    inferenceStep.insertStepAt( step, previousStep );
	    previousStep = step;
	}

	iterator = getSubstep().elements();
	String message =
	    "To fulfill this step, you need to do " +
	    getSubstep().size() +
	    "step" +
	    (getSubstep().size() == 1 ? " " : "s ") +
	    "that " + (getSubstep().size() == 1 ? " is " : " are ");
	while ( iterator.hasMoreElements() ) {
	    message += ((Step)iterator.nextElement()).getName();
	    message += (iterator.hasMoreElements() ? ", " : ".");
	}
	JOptionPane.showMessageDialog( this, message );
    }

    // ------------------------------------------------------------
    // Class specific scaffolding:: Following methods must be
    // implemented individually in a Step class that has no substeps
    // 
    public void dispatch () {
	
	JOptionPane.showMessageDialog(this,
				      "You need to implement " +
				      "dispatch() method for " +
				      getName() + "class.",
				      "Implementation Problem",
				      JOptionPane.WARNING_MESSAGE);
    }
    
    public void readInput() {
	
	JOptionPane.showMessageDialog(this,
				      "You need to implement " +
				      "readInput() method for " +
				      getName() + "class.",
				      "Implementation Problem",
				      JOptionPane.WARNING_MESSAGE);
    }

    // Return true when everything in <expected> is in <input> and
    // vise vasa.
    boolean setEqual( Vector input, Vector expected ) {
	
	return ( (input.size() == expected.size()) &&
		 (input.containsAll( expected )) );
    }

    // =
    // = Implementation of java.awt.event.MouseListener
    // =

    public void mouseClicked(MouseEvent mouseEvent) {

	Step step = (Step)mouseEvent.getComponent();
	// System.out.println("Got clicked on " + step);
	step.scaffolding();
    }

    public void mousePressed(MouseEvent mouseEvent) {}

    public void mouseReleased(MouseEvent mouseEvent) {}

    public void mouseEntered(MouseEvent mouseEvent) {}

    public void mouseExited(MouseEvent mouseEvent) {}    

}

//
// end of $RCSfile$
// 
@
