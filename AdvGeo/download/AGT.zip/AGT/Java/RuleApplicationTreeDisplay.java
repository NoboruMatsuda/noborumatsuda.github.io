/**
 * RuleApplicationTreeDisplay.java
 *
 *
 * Created: Mon Jul 21 17:28:46 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version
 */

import java.net.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;
// import javax.swing.border.*;

public class RuleApplicationTreeDisplay extends JPanel {

    /* ------------------------------------------------------------
     *	Member variables
     * ------------------------------------------------------------*/

    // The JTree
    JTree tree = null;

    // Tree root node, that represents a problem number
    DefaultMutableTreeNode root;
    DefaultTreeModel treeModel;

    // The depest level of tree
    int MAX_TREE_LEVEL = 10;

    // Holds the most recent tree node at the level of i
    DefaultMutableTreeNode[] recentNode
	= new DefaultMutableTreeNode[MAX_TREE_LEVEL];

    // size of the diaplay pane
    private int width = 800;
    private int height = 600;

    // Must define following variable and method to get the window
    // displayed in a desired size.
    private Dimension preferredSize = new Dimension( width, height );

    public Dimension getPreferredSize() {
	return preferredSize;
    }

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------*/

    public RuleApplicationTreeDisplay () {

	root = new DefaultMutableTreeNode( "Problem" );
	treeModel = new DefaultTreeModel( root );
	tree = new JTree( treeModel );
	tree.setEditable( true );
	tree.setShowsRootHandles( true );

	// Root must be at the indent level of 0
	recentNode[0] = root;

	tree.getSelectionModel().setSelectionMode
	    ( TreeSelectionModel.SINGLE_TREE_SELECTION );

	// Set default size
	JScrollPane treeView = new JScrollPane( tree );
	treeView.setPreferredSize( preferredSize );
	// treeView.setMinimumSize( preferredSize );

	// Add the scroll pane
	add( treeView, BorderLayout.CENTER );
    }

    /* ------------------------------------------------------------
     *	Read socket and expand the tree
     * ------------------------------------------------------------*/

    public void expandTree( BufferedReader socketIn ) {

	String bodyStr = "";
	String msgString = "";

	do {
	    try {
		msgString = socketIn.readLine();
	    } catch (IOException e) {
		e.printStackTrace();
	    } // end of try-catch

	    System.out.println( "\nmsg: " + msgString );

	    // Position of the first space
	    int delimiter = msgString.indexOf( ' ' );

	    System.out.println( "delimiter: " + delimiter );

	    if ( delimiter != 0 ) {
		
		// The first part is for a number to represent a command
		String indentStr = msgString.substring(0, delimiter);
		int indentVal = Integer.parseInt( indentStr );

		System.out.println( "indentVal: " + indentVal );

		// The rest of the message is the body 
		bodyStr = msgString.substring( delimiter+1 );

		System.out.println( "bodyStr: " + bodyStr );

		if ( indentVal > 0 ) {

		    DefaultMutableTreeNode node
			= new DefaultMutableTreeNode( bodyStr );

		    // recentNode[ indentVal-1 ].add( node );
		
		    DefaultMutableTreeNode parent = recentNode[indentVal-1];
		    treeModel.insertNodeInto( node,
					      parent,
					      parent.getChildCount() );
		    tree.scrollPathToVisible( new TreePath( node.getPath() ) );
		
		    recentNode[ indentVal ] = node;

		    System.out.println("recentNode[" + indentVal + "]=" + node );

		    repaint();

		} // end of if ()

	    } // end of if ()

	} while ( !bodyStr.equals( "QUIT" ) );

	System.out.println( "Good bye!" );
    }
}

// RuleApplicationTreeDisplay
