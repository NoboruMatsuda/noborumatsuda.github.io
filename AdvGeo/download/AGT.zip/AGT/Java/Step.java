/**
 * Step.java
 *
 *
 * Created: Wed Oct 01 12:11:39 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: Step.java 1.1 2003/10/04 17:16:16 NoboruM Exp NoboruM $
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Describe class <code>Step</code> here.
 *
 */
class Step extends JPanel implements MouseListener {

    //-
    //-	Fields - - - - - - - - - - - - - - - - - - - - - - - - -
    //-

    // Font
    // Font stepFont = new Font( "Arial", Font.PLAIN, 16 );
    // Font stepFont = new Font( "Century Gothic", Font.PLAIN, 16 );
    Font stepFont = new Font( "Verdana", Font.PLAIN, 16 );

    // Thickness of the borderline
    final int STEP_BORDER = 5;
    // Height of step componet in the inference tab
    final int STEP_HEIGHT = 30;
    // Background color
    Color stepBackground = Color.white;

    // The node # in a linear proof tree on which this inference steps
    // are all about
    int lptId;
    public int getLptId() { return lptId; }
    public void setLptId(int newLptId) { this.lptId = newLptId; }

    // Marker indicating current step
    JPanel marker = new JPanel();
    public JPanel getMarker() {
	return marker;
    }
    public void setMarker(JPanel newMarker) {
	this.marker = newMarker;
    }

    // String to be shown as the step name
    JLabel stepLabel;
    public JLabel getStepLabel() {
	return stepLabel;
    }
    public void setStepLabel(JLabel newStepLabel) {
	this.stepLabel = newStepLabel;
	this.stepLabel.setFont( stepFont );
    }

    String stepLabelString;
    public String getStepLabelString() { return stepLabelString; }
    public void setStepLabelString(String newStepLabelString) {
	this.stepLabelString = newStepLabelString;
    }

    // A single line description of this step shown as a tile
    JLabel descriptionLabel = new JLabel("");

    // An explanation of the step
    String explanation;

    // Indentation 
    Component boxIndent = null;
    Component getBoxIndent() { return this.boxIndent; }
    void setBoxIndent( Component boxIndent ) { this.boxIndent = boxIndent; }

    // Amount of indentation by 1 level
    final int STEP_INDENT = 20;
    // Depth of the step
    int indentLevel;
    public int getIndentLevel() { return indentLevel; }
    public void setIndentLevel(int newIndentLevel) {
	this.indentLevel = newIndentLevel;
    }

    //-
    //-	Constructor - - - - - - - - - - - - - - - - - - - - - - - - - 
    //- 

    public Step( String name, String label, int indentLevel, int lptID ) {

	this();

	setName( name );
	setStepLabelString( label );
	setIndentLevel( indentLevel );
	setLptId( lptID );
	setStepLabel( new JLabel( getStepLabelString() ) );
	setBoxIndent( boxIndent( indentLevel ) );
	Dimension markerSize =
	    new Dimension( STEP_HEIGHT-(STEP_BORDER*2), STEP_HEIGHT );
	getMarker().setMaximumSize( markerSize );
	getMarker().setMinimumSize( markerSize );
	getMarker().setPreferredSize( markerSize );
	getMarker().setBackground( Color.white );

	add( getBoxIndent() );
	add( getMarker() );
	add( getStepLabel() );
	add( descriptionLabel );
    }

    public Step() {

	setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
	setAlignmentX( JComponent.LEFT_ALIGNMENT );
	setBorder( BorderFactory.createEmptyBorder( STEP_BORDER,
						    STEP_BORDER,
						    STEP_BORDER,
						    STEP_BORDER ) );
	setBackground( stepBackground );

	// Make the Step component neatly fit into the inference tab
	// Dimension size = AGT.getInferenceStep().getTabSize();
	// Dimension stepSize = new Dimension( size.width, STEP_HEIGHT );
	// setPreferredSize( stepSize );

	setMaximumSize( new Dimension( 9999, STEP_HEIGHT ) );

	addMouseListener( this );
    }

    //-
    //-	Methods - - - - - - - - - - - - - - - - - - - - - - - - -
    //-

    // Generate a Box for indentation
    Component boxIndent( int level ) {

	return Box.createHorizontalStrut( level * STEP_INDENT );
    }

    // 
    public void updateDescription( String description ) {
	// setDescription( description );
	descriptionLabel.setText( Equation.reformMessage( description ) );
	System.out.println("updateDescription: " + getName() + " gets " + description);
    }

    // Display general explanation of the step
    public void stepExplanation() {
	JOptionPane.showMessageDialog( this, explanation );
    }

    // Highlighting step label
    public void highlightLabel() {
	getStepLabel().setForeground( Color.blue );
	getStepLabel().setBackground( Color.yellow );
    }

    public void cancelHighlightLabel() {
	getStepLabel().setForeground( Color.black );
	getStepLabel().setBackground( Color.white );
    }

    //
    public void markerOn() {
	getMarker().setBackground( Color.blue );
    }

    public void markerOff() {
	getMarker().setBackground( Color.white );
    }

    /* - - - - - - - - - - - - - - - - - - - - - - - - -
     *	Mouse Listener
     * - - - - - - - - - - - - - - - - - - - - - - - - - */

    public void mouseClicked( MouseEvent mouseEvent ) {
	/*
	System.out.println("Got clicked on " + getName());

	ComManager comManager = AGT.getComManager();
	String fn =
	    "(AGT:SCAFFOLDING-INFERENCE " + getName() + " " + getLptId() + ")";
	comManager.sendAgtCommand( "Step", fn );
	*/
    }

    public void mousePressed(MouseEvent mouseEvent) {}

    public void mouseReleased(MouseEvent mouseEvent) {}

    public void mouseEntered(MouseEvent mouseEvent) {}

    public void mouseExited(MouseEvent mouseEvent) {}

}

//
// end of $RCSfile: Step.java $
// 
