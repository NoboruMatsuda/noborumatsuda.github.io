    // ============================================================
    // Let the comunication manager know who's ready to get input.
    // Methods must follow a convention: cc_Sender_Receiver()
    //

    // StepPickupPostulate waiting for a justification-supporter in
    // the ProofTable
    public void cc_ProofTable_StepPickupPostulate( Vector supporter,
						   StepPickupPostulate spp ) {
	pushEventQueue( new Supporter_StepPickupPostulate( supporter, spp ) );
    }

    // StepIdentifyPremises waiting for DS premises input 
    public void cc_Premise_StepIdentifyPremises( Vector /* JButton */ source,
						 StepIdentifyPremises sip ) {
	pushEventQueue( new Premise_StepIdentifyPremises( source, sip ) );
    }
						 
    // StepUnifyPremises waiting for premise input
    public void cc_Premise_StepUnifyPremises( Vector /* JTextFiled */ s,
					      StepUnifyPremises sup ) {
	pushEventQueue( new Premise_StepUnifyPremises( s, sup ) );
    }
						 
    // StepIdentifyConsequence waiting for consequence input
    public void cc_Prop_StepIdentifyConsequence( Vector /*JTextField */ source,
						 StepIdentifyConsequence sic ){
	pushEventQueue( new Prop_StepIdentifyConsequence( source, sic ) );
    }

    // StepUnifyConsequence waiting for a consequence 
    public void cc_Prop_StepUnifyConsequence( Vector /* JButton */ source,
					      StepUnifyConsequence suc ) {
	pushEventQueue( new Prop_StepUnifyConsequence( source, suc ) );
    }

    // StepAssertConsequence waiting for a proposition fed 
    public void cc_Prop_StepAssertConsequence( Vector /* Proposition */ source,
					       StepAssertConsequence sac ) {
	pushEventQueue( new Prop_StepAssertConsequence( source, sac ) );
    }

    // StepPickupPostulate waiting for postulate fed in Justfication
    // supporter field
    class Supporter_StepPickupPostulate extends CcEvent {

	public Supporter_StepPickupPostulate( Vector /* JTextField */ source,
					      StepPickupPostulate spp ) {
	    super( source, spp );
	}

	public void dispatch( String msg ) {
	    ((StepPickupPostulate)getReceiver()).ccInputReady( msg );
	}
    }

    // StepIdentifyPremises waiting for DS premises input at
    // Proposition Builder and DS Browser
    class Premise_StepIdentifyPremises extends CcEvent {

	public Premise_StepIdentifyPremises( Vector /* JTextField */ source,
					     StepIdentifyPremises sip ) {
	    super( source, sip );
	}

	public void dispatch( String msg ) {
	    ((StepIdentifyPremises)getReceiver()).ccInputReady( msg );
	}
    }

    // StepUnifyPremises waiting for premise in the justification cell
    // filled up
    class Premise_StepUnifyPremises extends CcEvent {

	public Premise_StepUnifyPremises( Vector /* JTextField */ source,
					  StepUnifyPremises sup ) {
	    super( source, sup );
	}

	public void dispatch( String msg ) {
	    ((StepUnifyPremises)getReceiver()).ccInputReady( msg );
	}
    }

    // StepIdentifyConsequence waiting for DS consequence input
    class Prop_StepIdentifyConsequence extends CcEvent {
	public Prop_StepIdentifyConsequence( Vector /* JButton */ source,
					     StepIdentifyConsequence sic ) {
	    super( source, sic );
	}

	public void dispatch( String msg ) {
	    ((StepIdentifyConsequence)getReceiver()).ccInputReady( msg );
	}
    }

    // StepUnifyConsequence waiting for a consequence input
    class Prop_StepUnifyConsequence extends CcEvent {
	public Prop_StepUnifyConsequence( Vector /* JButton */ source,
					  StepUnifyConsequence suc ) {
	    super( source, suc );
	}

	public void dispatch( String msg ) {
	    ((StepUnifyConsequence)getReceiver()).ccInputReady( msg );
	}
    }

    class Prop_StepAssertConsequence extends CcEvent {
	public Prop_StepAssertConsequence( Vector /* Proposition */ source,
					   StepAssertConsequence sac ) {
	    super( source, sac );
	}

	public void dispatch( String msg ) {
	    ((StepAssertConsequence)getReceiver()).ccInputReady( msg );
	}
    }
    /* ------------------------------------------------------------
     *	CcEvent
     * ------------------------------------------------------------ */

    abstract class CcEvent {

	//-
	//-	Fields
	//-

	// a component expecting to receive a message
	Object receiver;
	public Object getReceiver() { return receiver; }
	public void setReceiver(Object newReceiver) {
	    this.receiver = newReceiver;
	}

	// A component that initiated a message passing
	Vector sender;
	public Vector getSender() { return sender; }
	public void setSender( Vector newSender ) { this.sender = newSender; }

	//-
	//-	Constructor
	//-

	public CcEvent( Vector sender, Object receiver ) {
	    setSender( sender );
	    setReceiver( receiver );
	}
	
	//-
	//-	Method
	//-

	// This method is called by ComManager when a component gets
	// an event fired
	abstract void dispatch( String msg );
    }

