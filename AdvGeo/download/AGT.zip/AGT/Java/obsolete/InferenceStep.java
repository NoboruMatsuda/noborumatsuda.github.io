    JScrollPane currentTab;
    void setCurrentTab( JScrollPane tab ) { currentTab = tab; }
    JScrollPane getCurrentTab() { return currentTab; }

    // A panel showing forward inference steps
    JPanel forwardPane;
    JScrollPane forwardSP;
    final String FORWARDPANE_NAME = "Forward Inference Steps";
    Color forwardPaneBackground = Color.white;
    
    // and for backward inference steps
    JPanel backwardPane;
    JScrollPane backwardSP;
    final String BACKWARDPANE_NAME = "Backward Inference Stpes";
    Color backwardPaneBackground = Color.white;

    public static final int FORWARD_TAB = 1;
    public static final int BACKWARD_TAB = 2;

    Component verticalGlue = Box.createVerticalGlue();
    Box verticalBox = Box.createVerticalBox();

	// forwardPane = new JPanel();
	forwardPane = new JPanel( new GridLayout( 0, 1 ) );
	forwardPane.setName( FORWARDPANE_NAME );
	forwardPane.setBackground( forwardPaneBackground );
	// Wed Oct 01 11:44:17 2003  Flow Layout works fine, not BoxLayout
	// forwardPane.setLayout(new BoxLayout(forwardPane, BoxLayout.Y_AXIS));
	forwardSP = new JScrollPane( forwardPane );
	forwardSP.setPreferredSize( paneSize );
	tabbedPane.addTab( FORWARDPANE_NAME, null, forwardSP, "FC" );

	// backwardPane = new JPanel();
	// backwardPane = new JPanel( new GridLayout( 0, 1 ) );
	backwardPane = new JPanel();
	backwardPane.setName( BACKWARDPANE_NAME );
	backwardPane.setBackground( backwardPaneBackground );
	// Wed Oct 01 11:44:17 2003  Flow Layout works fine, not BoxLayout
	backwardPane.setLayout(new BoxLayout(backwardPane, BoxLayout.Y_AXIS));
	backwardSP = new JScrollPane( backwardPane );
	backwardSP.setPreferredSize( paneSize );
	tabbedPane.addTab( BACKWARDPANE_NAME, null, backwardSP, "BC" );

	// selectTab( BACKWARD_TAB );

    /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
     *	Tabbed pane manipulation
     * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    // Set currently working tab
    public void selectTab( int tabName ) {

	switch ( tabName ) {
	case FORWARD_TAB:
	    setCurrentPane( forwardPane );
	    setCurrentTab( forwardSP );
	    break;
		
	case  BACKWARD_TAB:
	    setCurrentPane( backwardPane );
	    setCurrentTab( backwardSP );
	    break;

	default:
	    System.err.println("selectTab: invalid tab name " + tabName);
	    break;
	}
	tabbedPane.setSelectedComponent( getCurrentTab() );
    }

    // Returns size of the tabbed pane
    public Dimension getTabSize() {
	return getCurrentTab().getPreferredSize();
    }

    // The method to make a complete single forward inference step
    public void dispatchForwardInference( String postulate,
					  Vector dsPremise,
					  Vector premise,
					  String dsConsequence,
					  String consequence ) {
	
	selectTab( FORWARD_TAB );
	getCurrentPane().removeAll();

	StepForwardInference forwardInference =
	    new StepForwardInference();

	StepSelectPostulate selectPostulate =
	    new StepSelectPostulate();
	forwardInference.addSubstep( selectPostulate );

	StepPickupPostulate pickupPostulate =
	    new StepPickupPostulate( postulate );
	selectPostulate.addSubstep( pickupPostulate );

	StepVerifyPremise verifyPremise =
	    new StepVerifyPremise();
	selectPostulate.addSubstep( verifyPremise );

	StepIdentifyPremises identifyPremises =
	    new StepIdentifyPremises( dsPremise );
	verifyPremise.addSubstep( identifyPremises );

	StepUnifyPremises unifyPremises =
	    new StepUnifyPremises( premise );
	verifyPremise.addSubstep( unifyPremises );

	StepExecutePostulate executePostulate =
	    new StepExecutePostulate();
	forwardInference.addSubstep( executePostulate );

	StepInstantiateConsequenec instantiateConsequenec =
	    new StepInstantiateConsequenec();
	executePostulate.addSubstep( instantiateConsequenec );

	StepIdentifyConsequence identifyConsequence =
	    new StepIdentifyConsequence( dsConsequence );
	instantiateConsequenec.addSubstep( identifyConsequence );

	StepUnifyConsequence unifyConsequence =
	    new StepUnifyConsequence( consequence );
	instantiateConsequenec.addSubstep( unifyConsequence );

	StepCheckDuplication checkDuplication =
	    new StepCheckDuplication( true );
	executePostulate.addSubstep( checkDuplication );

	StepAssertConsequence assertConsequence =
	    new StepAssertConsequence( consequence );
	executePostulate.addSubstep( assertConsequence );

	forwardInference.propagateLevel();
	insertStepAt( forwardInference, 0 );
	// forwardInference.scaffolding();
    }

    public void dispatchBackwardInference() {

	selectTab( BACKWARD_TAB );
	getCurrentPane().removeAll();

    }

    /**
    // Insert an inference step titled <name> into the current tab
    // with an indentation <level> and the <context>
    public void insertStep( int level, String name, String context ) {

	// Create a new Step object and invoke insertStep
	Step step = new Step( level, name, context );
	insertStep( step );
    }
    */

    /*
    // Insert a <step> as a substep of <indexStep>
    public void insertStepAt( Step step, Step indexStep ) {
	int index = getInferenceSteps().indexOf( indexStep );
	insertStepAt( step, index+1 );
    }
    */

	// Add <step> into inferenceSteps Vector
	void addInferenceStep( Step step ) {
	    inferenceSteps.add( step );
	}

