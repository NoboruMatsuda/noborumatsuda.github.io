/**
 * Message.java
 *
 *
 * Created: Wed Oct 01 11:57:31 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: Message.java 1.1 2003/11/18 21:11:34 NoboruM Exp NoboruM $
 */

// import java.beans.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Message extends MyInternalFrame implements ActionListener {

    //-
    //-	Fields * * * * * * * * * * * * * * * * * * * * * * * * * 
    //-

    // Title of the window
    static String theTitle = "Message Window";

    // The content pane
    JPanel contentPane;

    // ToolBar
    int TOOLBAR_HEIGHT = 38;
    JButton backButton, forwardButton;
    final String BACK_COMMAND = "back button";
    final String FORWARD_COMMAND = "forward button";

    // Current message pane, which is displayed on the Message window
    JPanel messagePane;
    
    // Bag of messages
    Vector /* JPanel */ messagePool = new Vector();
    // The position of the current message in messagePool when
    // backpaged
    int messageIndex = 0;

    // Font
    Font messageFont = new Font( "Times New Roman", Font.PLAIN, 16 );

    // Margin
    Insets messageMargin = new Insets( 10, 10, 10, 10 );

    // Message Option Types
    // No button, no text field.  Just message
    static final int NO_OPTION = 1;
    // Single [OK] button
    static final int OK_OPTION = 2;
    // Text field to input a string
    static final int INPUT_OPTION = 3;
    // Disabled [OK] button at the beginning
    static final int OK_OPTION_AT_INPUT = 4;

    final String OK_ACTION_COMMAND = "ok button";
    final String INPUT_ACTION_COMMAND = "input field";

    // The initial message
    String initialText =
	"Message from the tutor appears here.\n" +
	"You can review past messages by clicking [ << ] button." ;

    // Flag to make Message Window modal
    boolean messageRead = false;
    public boolean isMessageRead() { return messageRead; }
    public void setMessageRead(boolean newMessageRead) {
	this.messageRead = newMessageRead;
    }

    // Strings input in the text field
    String inputText = "X";
    public String getInputText() { return inputText; }
    public void setInputText(String newInputText) {
	this.inputText = newInputText;
    }
    final int INPUT_FIELD_LEN = 50;

    // Is the input fed by Equation builder?
    boolean fedByEquationBuilder = false;
    public boolean isFedByEquationBuilder() { return fedByEquationBuilder; }
    public void setFedByEquationBuilder(boolean newFedByEquationBuilder) {
	this.fedByEquationBuilder = newFedByEquationBuilder;
    }

    // Number of equations fef by Equation Builder
    int numEquationFed = 0;

    JTextArea currentMessageArea;
    public JTextArea getCurrentMessageArea() { return currentMessageArea; }
    public void setCurrentMessageArea(JTextArea newCurrentMessageArea) {
	this.currentMessageArea = newCurrentMessageArea;
    }
    
    String currentMessage;

    // [OK] button 
    JButton theOkeyButton;
    public JButton getTheOkeyButton() { return theOkeyButton; }
    public void setTheOkeyButton(JButton newTheOkeyButton) {
	this.theOkeyButton = newTheOkeyButton;
    }

    //-
    //-	Constructor * * * * * * * * * * * * * * * * * * * * * *
    //- 

    public Message( Dimension size, Point location ) {

	super( theTitle, 
	       false,		// resizable
	       false,		// closing
	       false,		// maximizable
	       false		// iconifiable
	       );

	System.out.println("Message window size -> " + size);

	setPreferredSize( size );
	setLocation( location );

	System.out.println("Message window init contentPane size -> " +
			   getContentPane().getPreferredSize() );

	// Page turn buttons
	backButton = new JButton( " << " );
	backButton.setToolTipText( "Back" );
	backButton.setActionCommand( BACK_COMMAND );
	backButton.addActionListener( this );
	backButton.setEnabled( false );
	forwardButton = new JButton( " >> " );
	forwardButton.setToolTipText( "Forward" );
	forwardButton.setActionCommand( FORWARD_COMMAND );
	forwardButton.addActionListener( this );
	forwardButton.setEnabled( false );

	JPanel toolBar = new JPanel();
	FlowLayout layout = (FlowLayout)toolBar.getLayout();
	layout.setAlignment( FlowLayout.LEFT );
	int toolBarWidth = (int)getPreferredSize().getWidth();
	toolBar.setPreferredSize( new Dimension( toolBarWidth,
						 TOOLBAR_HEIGHT ) );
	toolBar.add( backButton );
	toolBar.add( forwardButton );

	// Content pane
	contentPane = new JPanel();
	contentPane.setPreferredSize( size );
	contentPane.setLayout(new BoxLayout( contentPane, BoxLayout.Y_AXIS ));
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	// Put things togther
	contentPane.add( toolBar );
	pack();
	setVisible( true );

	// Initial Message is just displayed, no acknowledge needed.
	JPanel initMP = newMessagePane( initialText, NO_OPTION );
	addMessagePool( initMP );
	setMessagePane( initMP );
    }
    
    //-
    //-	Methods * * * * * * * * * * * * * * * * * * * * * * * * * 
    //- 

    // The time when the message was displayed
    long startDisplay;
    public long getStartDisplay() { return startDisplay; }
    public void setStartDisplay(long newStartDisplay) {
	this.startDisplay = newStartDisplay;
    }

    // Called by LISP backend.  Display <message> and log student's
    // responce
    public void displayMessage( String message, int optionType ) {

	// Replace LISP expressions with human friendly math equations
	message = Equation.reformMessage( message );

	JPanel mPane = newMessagePane( message, optionType );
	addMessagePool( mPane );
	setMessagePane( mPane );

	forwardButton.setEnabled( false );
	backButton.setEnabled( true );

	// Logging a message opening 
	ComManager comManager = AGT.getComManager();
	String log = "(LOG:WRITE-LOG MESSAGE-OPEN \"" + message + "\")";
	comManager.sendAgtCommand( "Message", log );
	// Measure a time the message has been read 
	setStartDisplay( new Date().getTime() );
	
	// Rest some variables
	setMessageRead( false );
	setFedByEquationBuilder( false );
	numEquationFed = 0;
	setInputText( "" );

	// Wed Mar 17 16:51:32 2004 Because GUI events would happen
	// hereafter (i.e., after displaying message and before the
	// studen click [OK] or complete to input some text, this
	// method must be end here so that mailLoop in comManager can
	// resume its job.  When an expected follow-up event for this
	// method happen (i.e., either clicking [OK] or completing
	// text input, then closeDiaplayMessage() is called
    }

    void closeDiaplayMessage() {

	long end = new Date().getTime();
	// Logging a message closing
	String log =
	    "(LOG:WRITE-LOG MESSAGE-CLOSED " + (end - getStartDisplay()) + ")";
	ComManager comManager = AGT.getComManager();
	comManager.sendAgtCommand( "Message", log );
    }

    // Compose a new message window with options speficied with
    // <optionType>
    JPanel newMessagePane( String message, int optionType ) {

	Dimension maSize = getMessageAreaSize();
	Dimension minSize = new Dimension( (int)(maSize.width * .9), 0 );

	// Message texts must be line wrap
	JTextArea textArea = new JTextArea( message );
	textArea.setLineWrap( true );
	textArea.setWrapStyleWord( true );
	// textArea.setFont( messageFont );
	textArea.setMinimumSize( minSize );
	textArea.setMargin( messageMargin );

	setCurrentMessageArea( textArea );
	currentMessage = message + "\n\n";

	JPanel mPane = new JPanel();
	mPane.setLayout( new BoxLayout( mPane, BoxLayout.Y_AXIS ) );
	mPane.setPreferredSize( getMessageAreaSize() );
	mPane.add( textArea );

	/*
	  System.out.println("Message window contentPane size -> " +
	  getContentPane().getPreferredSize() );
	*/

	switch ( optionType ) {

	case OK_OPTION:
	case OK_OPTION_AT_INPUT:

	    // for OK_OPTION, place [OK] button at the bottom
	    JButton okButton = new JButton( "OK" );
	    okButton.setActionCommand( OK_ACTION_COMMAND );
	    okButton.addActionListener( this );
	    okButton.grabFocus();
	    if ( optionType == OK_OPTION_AT_INPUT ) {
		setTheOkeyButton( okButton );
		okButton.setEnabled( false );
	    }
	    mPane.add( okButton );
	    break;
	    
	case  INPUT_OPTION:

	    // for INPUT_OPTION, place a text field at the bottom
	    JTextField inputField = new JTextField( INPUT_FIELD_LEN );
	    inputField.setActionCommand( INPUT_ACTION_COMMAND );
	    inputField.addActionListener( this );
	    mPane.add( inputField );
	    break;
	    
	default:
	    break;
	}

	return mPane;
    }

    // Append new message pane into the messagePool and update
    // messageIndex
    void addMessagePool( JPanel messagePane ) {

	// Add the new message pane into the messagePool
	messagePool.add( messagePane );
	messageIndex = messagePool.size() -1;
    }

    // Display <mPane> as a message pane, and update messagePool.
    // addMessagePool must be called prior to this method so that
    // messageIndex has been set properly
    void setMessagePane( JPanel mPane ) {

	// Remove the old messagePane
	if ( messagePane != null ) {
	    contentPane.remove( messagePane );
	}
	
	// Set new message pane
	this.messagePane = mPane;
	contentPane.add( messagePane );
	pack();
    }

    // Returns the size of message area which is 90% of the whole frame
    Dimension getMessageAreaSize() {

	// Size of the Content Pane
	Dimension cpSize = getContentPane().getPreferredSize();
	int width = (int)(cpSize.getWidth() * .9);
	int height = (int)((cpSize.getHeight() - TOOLBAR_HEIGHT ) * .9);
	
	/*
	  System.out.println("MessageArea width: " + width
	  + ", height: " + height);
	*/

	return new Dimension( width, height );
    }

    // -
    // - An equation sent from Postulate Builder
    // -
    public void feedFromPostulateBuilder( String equation ) {

	// System.out.println("feedFromPostulateBuilder got " + equation);
	setFedByEquationBuilder( true );
	getTheOkeyButton().setEnabled( true );

	System.out.println("[BEFORE] inputText = " + inputText);

	inputText += equation + " ";
	numEquationFed++;

	System.out.println("[AFTER] inputText = " + inputText);

	currentMessage += equation + "\n";
	String msg = Equation.reformMessage( currentMessage );
	getCurrentMessageArea().setText( msg );
    }

    //- 
    //-	Implementation of java.awt.event.ActionListener - - - - - - -
    //-

    public void actionPerformed(ActionEvent actionEvent) {
	
	String command = actionEvent.getActionCommand();

	if ( command.equals( OK_ACTION_COMMAND ) ) {

	    // [OK] button pressed
	    setMessageRead( true );
	    ((JButton)actionEvent.getSource()).setEnabled( false );

	    ComManager comManager = AGT.getComManager();
	    // Some equations have been fed by Equation Builder
	    if ( isFedByEquationBuilder() ) {
		if ( numEquationFed > 1 ) {
		    inputText = "(" + inputText + ")";
		}
		comManager.sendStringInput( "Message", inputText );
		System.out.println("inputText " + inputText + "sent");
	    } else {
		comManager.sendAgtMessage( ":OK-CLICK", "Message", "" );
	    }
	    closeDiaplayMessage();

	} else if ( command.equals( INPUT_ACTION_COMMAND ) ) {

	    // input completed
	    JTextField inputField = (JTextField)actionEvent.getSource();
	    String theInput = inputField.getText();

	    if ( !theInput.equals("") ) {
		System.out.println("INPUT_ACTION_COMMAND: " + theInput );
		ComManager comManager = AGT.getComManager();
		comManager.sendStringInput( "Message", theInput );
		setInputText( theInput );
	    }
	    closeDiaplayMessage();

	} else if ( command.equals( BACK_COMMAND ) ) {
	    
	    JPanel mp = (JPanel)messagePool.elementAt( --messageIndex );
	    setMessagePane( mp );

	    if ( messageIndex == 0 )
		backButton.setEnabled( false );

	    forwardButton.setEnabled( true );

	} else if ( command.equals( FORWARD_COMMAND ) ) {

	    JPanel mp = (JPanel)messagePool.elementAt( ++messageIndex );
	    setMessagePane( mp );

	    if ( messageIndex == messagePool.size() -1 )
		forwardButton.setEnabled( false );

	    backButton.setEnabled( true );
	}
    }
}

//
// end of $RCSfile: Message.java $
// 


    // Called by LISP backend.  Display <message> and log student's
    // responce
    public void displayMessage( String message, int optionType ) {

	// Replace LISP expressions with human friendly math equations
	message = Equation.reformMessage( message );

	JPanel mPane = newMessagePane( message, optionType );
	addMessagePool( mPane );
	setMessagePane( mPane );

	forwardButton.setEnabled( false );
	backButton.setEnabled( true );

	// Logging a message opening 
	ComManager comManager = AGT.getComManager();
	String log = "(LOG:WRITE-LOG MESSAGE-OPEN \"" + message + "\")";
	comManager.sendAgtCommand( "Message", log );
	// Measure a time the message has been read 
	long start = new Date().getTime();
	
	// Rest some variables
	setMessageRead( false );
	setFedByEquationBuilder( false );
	numEquationFed = 0;
	setInputText( "" );

	switch ( optionType ) {
	case OK_OPTION:
	case OK_OPTION_AT_INPUT:
	    displayMessageWaitFor_OK();
	    break;
	    
	case INPUT_OPTION:
	    displayMessageWaitFor_IPUT();
	    break;
	}

	long end = new Date().getTime();
	// Logging a message closing
	log = "(LOG:WRITE-LOG MESSAGE-CLOSED " + (end - start) + ")";
	comManager.sendAgtCommand( "Message", log );
    }

    // Wait for [OK] botton confirmation
    void displayMessageWaitFor_OK() {
	while ( !isMessageRead() ) {
	    ;
	}
    }

    // Wait for a string input and send it to the LISP backend
    void displayMessageWaitFor_IPUT() {
	while ( getInputText() == "" ) {
	    ;
	}
    }
    
