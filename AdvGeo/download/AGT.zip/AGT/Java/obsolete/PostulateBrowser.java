    void setupComponents() {

	// Postulate Selector provides a combo box to select a
	// postulte to brows
	// 
	JTextField psLabel = new JTextField( "Postulate : " );
	comboBox = new JComboBox();
	// requestLoadDsName();
	comboBox.addActionListener( new ComboBoxActionListener() );

	selectButton = new JButton( "Selecet" );
	selectButton.setToolTipText( "Click this button to select the postulate" );
	selectButton.setActionCommand( selectButtonCommand );
	selectButton.addActionListener( new SelectButtonActionListener() );
	selectButton.setEnabled( false );

	JPanel postulateSelector = new JPanel();
	FlowLayout layout = (FlowLayout)postulateSelector.getLayout();
	layout.setAlignment( FlowLayout.LEFT  );
	psWidth = pbWidth;
	psHeight = PS_HEIGHT;
	// postulateSelector.setBackground( Color.red );
	postulateSelector.setPreferredSize( new Dimension( psWidth,
							   psHeight ) );
	postulateSelector.add( psLabel );
	postulateSelector.add( comboBox );
	postulateSelector.add( selectButton );

	// The second row shows of a diagram configuration
	ddWidth = pbWidth;
	ddHeight = ( pbHeight - psHeight ) / 2;
	diagramDisplay = new DiagramDisplay( ddWidth, ddHeight );
	
	daWidth = pbWidth / 2;
	// daHeight = ( pbHeight - psHeight ) / 2;
	daHeight = ( pbHeight - psHeight );

	JTextField daLabel = new JTextField( "Description: " );
	// daLabel.setMaximumSize( new Dimension( 100, 0 ) );

	descriptionArea = new JTextArea();
	descriptionArea.setLineWrap( true );
	descriptionArea.setWrapStyleWord( true );
	descriptionArea.setFont( messageFont );
	descriptionArea.setMargin( messageMargin );

	JScrollPane daScroll = new JScrollPane( descriptionArea );

	JPanel da = new JPanel();
	// da.setLayout( new BoxLayout( da, BoxLayout.Y_AXIS ) );
	da.add( daLabel, BorderLayout.PAGE_START );
	// daLabel.setAlignmentX( Component.LEFT_ALIGNMENT );
	da.add( daScroll, BorderLayout.CENTER );
	// daScroll.setAlignmentX( Component.LEFT_ALIGNMENT );

	JSplitPane innerSP = new JSplitPane( JSplitPane.VERTICAL_SPLIT,
					     diagramDisplay,
					     da );
	innerSP.setDividerLocation( .5 );

	// The third row is for the list of deduction
	//
	/*
	dlWidth = pbWidth;
	dlHeight = ( pbHeight - psHeight ) / 2;

	JTextField dlLabel = new JTextField( "Deduction: " );
	dlLabel.setMaximumSize( new Dimension( 100, 0 ) );

	deductionList = new JTextArea();
	JScrollPane dlScroll = new JScrollPane( deductionList );

	JPanel dl = new JPanel();
	dl.setLayout( new BoxLayout( dl, BoxLayout.Y_AXIS ) );
	dl.add( dlLabel );
	dlLabel.setAlignmentX( Component.LEFT_ALIGNMENT );
	dl.add( dlScroll );
	dlScroll.setAlignmentX( Component.LEFT_ALIGNMENT );

	JSplitPane splitPane = new JSplitPane( JSplitPane.VERTICAL_SPLIT,
					       innerSP,
					       dl );
	splitPane.setDividerLocation( .5 );
	*/

	// Setup the content pane
	contentPane = new JPanel();
	contentPane.setLayout( new BoxLayout( contentPane,
					      BoxLayout.Y_AXIS ) );
	contentPane.setOpaque( true );
	setContentPane( contentPane );

	postulateSelector.setAlignmentX( Component.LEFT_ALIGNMENT );
	contentPane.add( postulateSelector );
	// contentPane.add( splitPane );
	contentPane.add( innerSP );


	Container cp = getContentPane();
	int cWidth = (int)cp.getSize().getWidth();
	int cHeight = (int)cp.getSize().getHeight();

	System.out.println("pbWidth = " + pbWidth);
	System.out.println("pbHeight = " + pbHeight);
	System.out.println("cWidth = " + cWidth);
	System.out.println("cHeight = " + cHeight);

    }

