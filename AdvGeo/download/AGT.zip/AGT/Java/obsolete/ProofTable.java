    // Feed a support for the proposition
    public void feedSupporterFor( String proposition, String supporter ) {

	ProofRow proofRow = lookupProofRowWithProposition( proposition );
	proofRow.setSupporterText( supporter );
	// proofRow.openPremiseFields();
    }


	/*
	  // ID is used as a link to its parent, i.e., a ProofRow that
	  // hold this object
	  public Proposition( String proposition, int ID ) {

	  this( ID );

	  // When a proposition is fed, keep it intact
	  if ( !proposition.equals("") ) {
	  setText( proposition );
	  setEditable( false );
	  }

	  // Set virtical alignment
	  // setAlignmentX( JTextField.TOP_ALIGNMENT );

	  }
	*/

    /*
    // Assert premise fields for the proof row at <index>
    public void openPremiseFields( int index ) {

	ProofRow proofRow = lookupProofRow( index );
	proofRow.openPremiseFields();
    }
    */

    // Assign <proposition> and <supporter> to the top-most empty
    // proof row
    public void insertProofRow( String proposition, String supporter ) {

	ProofRow proofRow = lookupEmptyProofRow();
	proofRow.setPropositionText( proposition );
	proofRow.setSupporterText( supporter );
    }

    // <premises> is a vector of String
    Vector initialProofRows( String goal, Vector /* String */ premises ) {
	
	Vector /* ProofRow */ proofRows = new Vector();

	// Premise
	Enumeration premisesElements = premises.elements();
	while ( premisesElements.hasMoreElements() ) {
	    String premise = (String)premisesElements.nextElement();
	    proofRows.add( new ProofRow( premise, "Given" ) );
	}

	// Blank row
	// Mon Nov 17 11:06:18 2003: commented out (proof table can be
	// just grow downwords no matter direction of stategy taken
	// proofRows.add( newBlankRow() );

	// Goal
	proofRows.add( new ProofRow( goal, "" ) );

	return proofRows;
    }

    // Insert a new proof row into the proof table
    void insertProofRowAt( String proposition, String premise, int position ) {

	System.out.println("insert proof row at " + position +
			   " for \"" + proposition + "\", \"" +
			   premise + "\"");

	// Make a new proof row
	ProofRow proofRow = new ProofRow( proposition, premise );

	insertProofRowAt( proofRow, position );
    }

    void insertProofRowAt( ProofRow proofRow, int position ) {
	
	// insert it into the existing proof rows 
	if ( position == -1 )
	    proofRows.add( proofRow );
	else
	    proofRows.insertElementAt( proofRow, position );

	// replace proof table with the new one
	/*
	ProofPane newProofPane = new ProofPane( proofRows );
	contentPane.remove( proofPane );
	proofPane = newProofPane;
	contentPane.add( proofPane );
	pack();
	*/
    }

    // Make a new blank row
    ProofRow newBlankRow() {

	ProofRow blankRow = new ProofRow("", "");

	// Set cells that are waiting for an input
	addCurrentOpenSupporter( blankRow.getSupporter() );
	setCurrentOpenProposition( blankRow.getProposition() );

	return blankRow;
    }

    public ProofTable( Dimension size, Point location,
		       String goal, Vector /*String */ premises ) {
	
	this( size, location );

	proofRows = initialProofRows( goal, premises );
	setProofPane( new ProofPane( proofRows ) );
	contentPane.add( getProofPane() );
	pack();
    }
    
    // Called by the lisp backend to initialize a proof table by
    // feeding goal and givens of the problem.  <given> must be a list
    // of givens, which are geometry equations, as a flat string with
    // a character in <delim> as the delimiter.
    public void initializeProofTable( String goal,
				      String given, String delim ) {

	System.out.println("Goal: " + goal);
	System.out.println("Givens: " + given);

	// chop up the given string into individual equations
	Vector /* String */ gVector = new Vector();
	StringTokenizer gTokenizer = new StringTokenizer( given, delim );
	while ( gTokenizer.hasMoreTokens() ) {
	    gVector.add( gTokenizer.nextToken() );
	}

	initializeProofTable( initialProofRows( goal, gVector ) );
    }

    // Called by the lisp backend to initialize a proof table by
    // feeding goal and givens of the problem.  <given> must be a list
    // of givens, which are geometry equations, as a flat string with
    // a character in <delim> as the delimiter.
    public void initializeProofTable( String goal,
				      String given, String delim ) {
	
	System.out.println("Goal: " + goal);
	System.out.println("Givens: " + given);
	
	// chop up the given string into individual equations
	Vector /* String */ gVector = new Vector();
	StringTokenizer gTokenizer = new StringTokenizer( given, delim );
	while ( gTokenizer.hasMoreTokens() ) {
	    gVector.add( gTokenizer.nextToken() );
	}
	
	proofRows = initialProofRows( goal, gVector );
	proofPane = new ProofPane( proofRows );
	contentPane.add( proofPane );
	pack();	
    }

	// Create a string fed as an actionCommand for the supporter's
	// Text Field
	String supporterID( int ID ) {
	    return ( SUPPORTER_FIELD + ":" + ID );
	}

	// This is called for a single line justification, which
	// doesn't involve a postulate application.  ID is used as
	// link to its parent, i.e., a ProofRow that holds this object
	public Justification( String justification, int ID ) {

	    this( ID );

	    if ( justification == "" )
		supporter.setToolTipText( CLICK_HERE_MESSAGE );
	    else
		supporter.setText( justification );
	}

	// Called when the user clicked on a <proposition> button as a
	// specified premise, or the user input <proposition> into the
	// premise text field.  <contractor> shows the origin of input.  
	public void premiseEntered( int contractor, String proposition ) {

	    boolean closing = false;
	    JTextField premiseField = getTargetPremiseField();
	    String premise = premiseField.getText();

	    switch ( contractor ) {
		
	    // Proposition button is pressed
	    case PROPOSITION_FIELD: 
		
		premiseField.setText( proposition );
		break;
		
	    // Premise Field gets text input
	    case PREMISE_FIELD:
		// Entering null in a premise field signals to
		// close entering premises
		if ( premise.equals( "" ) )
		    closing = true;
		break;
	    }

	    if ( closing ) {
		// Now, if "" is entered, then shut up the premise
		// entry
		closePremiseFields();

		String delimitor = "$";
		String premiseStr = "";
		for (int i = 0; i < getPremises().size(); i++) {
		    JTextField tf = (JTextField)getPremises().elementAt(i);
		    String str = tf.getText();
		    premiseStr = premiseStr + delimitor + str;
		}

		ComManager comManager = AGT.getComManager();
		comManager.sendStringInput( "PREMISE", premiseStr );
	    } else {
		// Continue entering premises
		newPremiseField();
	    }
	}

	// Finish reading premises
	public void closePremiseFields() {
	    premiseFieldOpen = false;
	    clearCurrentJustification();
	    // The last premise field, which is left blank, must be
	    // removed
	    remove( getTargetPremiseField() );
	    pack();
	}

	void clearCurrentJustification() {
	    currentJustification = null;
	}

	/*
	// Get read to read premises and let the user enter them
	void openPremiseFields() {

	    premiseFieldOpen = true;
	    setCurrentJustification( this );

	    JLabel premiseLabel = new JLabel( "Premise: " );
	    add( premiseLabel );
	    pack();
	    newPremiseField();
	}
	*/

	// Create new Premise field
	void newPremiseField() {

	    if ( isPremiseFieldOpen() ) {

		JTextField premise = new JTextField( "" );
		// command -> "PREMISE:3:0" meaning the 0th premise
		// for the 3rd proposition
		String command =
		    PREMISE_FIELD + ":" + ID + ":" + getPremises().size();
		premise.setActionCommand( command );
		premise.addActionListener( this );
		premise.grabFocus();
		setTargetPremiseField( premise );
		
		// add the premise into the Vector 
		getPremises().add( premise );

		// add the premise field as a GUI component
		JPanel tmpPane = new JPanel();
		tmpPane.setLayout( new BoxLayout( tmpPane,
						  BoxLayout.X_AXIS ) );
		tmpPane.add( Box.createHorizontalStrut( PREMISE_INDENT ) );
		tmpPane.add( premise );
		add( tmpPane );

		pack();
	    }
	}

	// Verify if the premise field is open 
	boolean isPremiseFieldOpen() {
	    return premiseFieldOpen;
	}

    /* ------------------------------------------------------------
     *	ACTION LISTENER for Justification
     * ------------------------------------------------------------ */

    class JustificationActionListener implements ActionListener {
	
	// Identifies the text field in a ProofRow that has signaled
	// the event
	public void actionPerformed(ActionEvent actionEvent) {

	    // actionEvent must be "componentType:ID" 
	    String command = actionEvent.getActionCommand();
	    int componentType = getComponentID( command );
	    
	    switch ( componentType ) {
	    case PREMISE_FIELD:
		JTextField premiseField = (JTextField)actionEvent.getSource();
		String premise = premiseField.getText();
		getCurrentJustification().premiseEntered( PREMISE_FIELD,
							  premise );
		break;
		
	    case SUPPORTER_FIELD:
		// A user has entered a text into the supporter field
		int supporterID = getSupporterID( command );
		ProofRow theProofRow = lookupProofRow( supporterID );
		theProofRow.supporterFed();
		break;
	    }
	}

	int getSupporterID( String actionCommand ) {

	    int delimiterPos = actionCommand.indexOf( ':' );
	    String IDstr = actionCommand.substring( delimiterPos+1 );
	    return Integer.parseInt( IDstr );
	}
    }

	// Called when the user clicked on a <proposition> button as a
	// specified premise, or the user input <proposition> into the
	// premise text field.  <contractor> shows the origin of input.  
	public void premiseEntered( int contractor, String proposition ) {

	    // boolean validInput = true;

	    if ( isPremiseFieldOpen() ) {

		JTextField premiseField = getTargetPremiseField();
		String premise = premiseField.getText();
		
		switch ( contractor ) {
		case PROPOSITION_FIELD: 
		    // Proposition button is pressed
		    premiseField.setText( proposition );
		    break;
		    
		    /*
		case PREMISE_FIELD:
		    // Premise Field gets text input
		    if ( premise.equals( "" ) ) {
			// Entering null in a premise field signals to
			// close entering premises
			// validInput = false;
			// closePremiseFields();
		    } else if (lookupProofRowWithProposition(premise) == null){
			// The premise input is new which happens only
			// in a backward inference hence need to
			// insert a new proof row with unjustified
			// proposition right above the current
			// justification (spcified by ID).
			// insertProofRowAt( premise, "", ID );
		    } else {
			// The premise entered has been in the proof
			// table
			// premiseField.setText( "" );
			// validInput = false;
		    }
		    break;
		    */
		}
		// Only when the premise has been input properly, add
		// next premise field
		if ( validInput ) {
		    // Mon Dec 01 16:39:11 2003
		    // ToDo
		    //
		    /*
		      ComManager comManager = AGT.getComManager();
		      comManager.dispatch( premiseField,
		      premiseField.getText() );
		    */
		    newPremiseField();
		}
	    }
	}

    /* ------------------------------------------------------------
     *	ACTION LISTENER for Proposition
     * ------------------------------------------------------------ */

    class PropositionActionListener implements ActionListener {
	
	public void actionPerformed(ActionEvent actionEvent) {

	    Proposition source = (Proposition)actionEvent.getSource();
	    source.setEditable( false );

	    // lookup the position of a proof row that has source,
	    // which is a proposition
	    int position = indexOf( source );

	    // insert a blank row just underneath the target position
	    // ProofRow blankRow = newBlankRow();
	    // insertProofRowAt( blankRow, position +1 );

	    // Mon Dec 01 16:39:33 2003
	    // ToDo
	    // ComManager comManager = AGT.getComManager();
	    // comManager.dispatch( source, source.getProposition() );
	}
    }

