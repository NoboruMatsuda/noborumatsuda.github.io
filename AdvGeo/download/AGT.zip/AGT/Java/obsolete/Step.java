    // Name of the step
    // String name = "";

    // Description of the step
    /*
    String description = "";
    public String getDescription() { return description; }
    public void setDescription( String newDescription ) {
	this.description = newDescription;
    }
    */

    // Subseps
    Vector /* Step */ substep = new Vector();
    public Vector /* Step */ getSubstep() { return substep; }
    public void addSubstep( Step step ) {
	substep.add( step );
	step.setSuperStep( this );
    }

    // superstep
    Step superStep = null;
    public Step getSuperStep() { return this.superStep; }
    public void setSuperStep(Step newSuperStep) {
	// System.out.println(this.getName() + "->" + newSuperStep.getName());
	this.superStep = newSuperStep;
    }

    public Step( String name, String description ) {

	this();
	// setDescription( description );
	setName( name );

	this.boxIndent = boxIndent( 0 );
	add( boxIndent );
	add( new JLabel( "[" + getName() + "] ") );
    }

    // Update indent level through out the step tree
    public void propagateLevel() {

	remove( boxIndent );
	add( boxIndent( getLevel() ), 0 );
	
	if ( !getSubstep().isEmpty() ) {

	    Enumeration iterator = getSubstep().elements();
	    while ( iterator.hasMoreElements() ) {
		((Step)iterator.nextElement()).propagateLevel();
	    }
	}
    }

    // Depth of the step used to make an indentation
    public int getLevel() {

	// System.out.println("getLebel: " + getName());

	if ( getSuperStep() == null ) {
	    // System.out.println("got bottom");
	    return 0;
	} else {
	    return getSuperStep().getLevel() + 1;
	}
    }

    // ============================================================
    // Provide scaffolding on the step
    // 
    // Scaffolding Policy:
    // 
    // For steps that have substeps, message appears telling what the
    // current step for and a list of substeps.
    // 
    // For steps that do not have substeps, invoke its own diapatch
    // method and allow students to follow the step.
    // 
    public void scaffolding() {

	stepExplanation();

	if ( substep.isEmpty() )
	    // This step has no substeps hence need to "execute"
	    // necessary things.
	    dispatch();
	else
	    // This step does have substeps, which must be expanded
	    // now.
	    expandSubsteps();
	
	add( descriptionLabel );
	updateDescription( getDescription() );
	// add( new JLabel( getDescription() ) );
    }

    // Expand and insert substeps
    void expandSubsteps() {

	Enumeration iterator = getSubstep().elements();
	InferenceStep inferenceStep = AGT.getInferenceStep();
	Step previousStep = this;
	
	while ( iterator.hasMoreElements() ) {
	    Step step = (Step)iterator.nextElement();
	    inferenceStep.insertStepAt( step, previousStep );
	    previousStep = step;
	}

	iterator = getSubstep().elements();
	String message =
	    "To fulfill this step, you need to do " +
	    getSubstep().size() +
	    " step" +
	    (getSubstep().size() == 1 ? " " : "s ") +
	    "that " + (getSubstep().size() == 1 ? " is " : " are ");
	while ( iterator.hasMoreElements() ) {
	    message += ((Step)iterator.nextElement()).getName();
	    message += (iterator.hasMoreElements() ? ", " : ".");
	}
	JOptionPane.showMessageDialog( this, message );
    }

    // ------------------------------------------------------------
    // Class specific scaffolding:: Following methods must be
    // implemented individually in a Step class that has no substeps
    // 
    public void dispatch () {
	
	JOptionPane.showMessageDialog(this,
				      "You need to implement " +
				      "dispatch() method for " +
				      getName() + "class.",
				      "Implementation Problem",
				      JOptionPane.WARNING_MESSAGE);
    }
    
    public void readInput() {
	
	JOptionPane.showMessageDialog(this,
				      "You need to implement " +
				      "readInput() method for " +
				      getName() + "class.",
				      "Implementation Problem",
				      JOptionPane.WARNING_MESSAGE);
    }

    // Return true when everything in <expected> is in <input> and
    // vise vasa.
    boolean setEqual( Vector input, Vector expected ) {
	
	return ( (input.size() == expected.size()) &&
		 (input.containsAll( expected )) );
    }

