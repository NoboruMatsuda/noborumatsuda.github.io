/**
 * StepAssertConsequence.java
 *
 *
 * Created: Thu Oct 02 13:30:42 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * $Id: StepAssertConsequence.java 1.1 2003/10/07 15:32:35 NoboruM Exp NoboruM $
 */

import java.util.*;
import javax.swing.*;

public class StepAssertConsequence extends Step {

    /* ------------------------------------------------------------
     *	Field
     * ------------------------------------------------------------ */

    String propositionExpected;
    public String getPropositionExpected() { return propositionExpected; }
    public void setPropositionExpected(String newPropositionExpected) {
	this.propositionExpected = newPropositionExpected;
    }

    String propositionInput;
    public String getPropositionInput() { return propositionInput; }
    public void setPropositionInput(String newPropositionInput) {
	this.propositionInput = newPropositionInput;
    }

    /* ------------------------------------------------------------
     *	Construction
     * ------------------------------------------------------------ */

    public StepAssertConsequence( String proposition ) {
	
	super( "Assert Proposition",
	       "Assert the consequence into the proof table" );

	explanation =
	    "Assert the consequence you have drawn into " +
	    "the proof table next to the justification cell " +
	    "you have just entered.";

	setPropositionExpected( proposition );
    }

    public void dispatch() {

	String message =
	    "Enter the proposition you have concluded " +
	    "in the top most empty proposition cell.\n" +
	    "Use Equation Builder or simply type it in."; 
    
	JOptionPane.showMessageDialog(this, message );

	// Let the communication Manager that this object is waiting
	// input from Proof window
	ComManager comManager = AGT.getComManager();
	Vector /* Proposition */ proposition = new Vector();
	proposition.add( AGT.getProofTable().getCurrentOpenProposition() );
	comManager.cc_Prop_StepAssertConsequence( proposition, this );
    }

    public void ccInputReady( String proposition ) {

	setPropositionInput( proposition );

	String msg = proposition + " has been asserted into the proof table.";
	updateContent( msg );
    }
}

//
// $RCSfile: StepAssertConsequence.java $
// 
