/**
 * StepCheckDuplication.java
 *
 *
 * Created: Thu Oct 02 13:25:41 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * $Id: StepCheckDuplication.java 1.1 2003/10/06 16:48:24 NoboruM Exp $
 */

import javax.swing.*;

public class StepCheckDuplication extends Step {

    /* ------------------------------------------------------------
     *	Field
     * ------------------------------------------------------------ */

    boolean cleanAssertion;
    public boolean isCleanAssertion() { return cleanAssertion; }
    public void setCleanAssertion(boolean newCleanAssertion) {
	this.cleanAssertion = newCleanAssertion;
    }

    /* ------------------------------------------------------------
     *	Construction
     * ------------------------------------------------------------ */

    public StepCheckDuplication( boolean cleanAssertion ) {

	super( "Ceck Duplicaion",
	       "See if the cosequence has been asserted" );

	explanation =
	    "You only need to assert a proposition once.  " +
	    "Hence you need to verify if the consequence you " +
	    "have gotten is new or not.";

	setCleanAssertion( cleanAssertion );
    }

    public void dispatch() {

	String message =
	    "A single proposition should not be asserted more than once.  " +
	    "You need to see if the consequence you have just entered " +
	    "has been in the proof table or not.";

	JOptionPane.showMessageDialog( this, message );
    }
}

//
// $RCSfile: StepCheckDuplication.java $
// 
