/**
 * StepExecutePostulate.java
 *
 *
 * Created: Thu Oct 02 11:47:14 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id$
 */

public class StepExecutePostulate extends Step {

    public StepExecutePostulate() {

	super( "Execute Postulate",
	       "Execute postulate chosen" );

	explanation =
	    "To execute a postulate means to assert its consequence " +
	    "into the proof table.";
    }
}

//
// end of $RCSfile$
//
