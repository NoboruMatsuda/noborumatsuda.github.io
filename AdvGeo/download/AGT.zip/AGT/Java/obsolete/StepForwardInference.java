/**
 * StepForwardInference.java
 *
 *
 * Created: Wed Oct 01 16:34:24 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id$
 */

public class StepForwardInference extends Step {

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------ */

    public StepForwardInference() {

	super( "Forward inference",
	       "Make a single forward inference" );

	explanation = "Let's make a forward inference";
    }

}

//
// $RCSfile$
// 
