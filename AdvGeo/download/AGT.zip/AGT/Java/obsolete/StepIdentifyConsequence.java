/**
 * StepIdentifyConsequence.java
 *
 *
 * Created: Thu Oct 02 12:03:04 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: StepIdentifyConsequence.java 1.1 2003/10/05 22:48:13 NoboruM Exp NoboruM $
 */

import java.util.*;
import javax.swing.*;

public class StepIdentifyConsequence extends Step {

    /* ------------------------------------------------------------
     *	Field
     * ------------------------------------------------------------ */

    // The consequence specified in the postulate
    String dsConsequenceExpected;
    public String getDsConsequenceExpected() { return dsConsequenceExpected; }
    public void setDsConsequenceExpected( String newConsequence ) {
	this.dsConsequenceExpected = newConsequence;
    }

    // A consequence entered by the user
    String dsConsequenceInput;
    public String getDsConsequenceInput() { return dsConsequenceInput; }
    public void setDsConsequenceInput(String newDsConsequenceInput) {
	this.dsConsequenceInput = newDsConsequenceInput;
    }

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------ */

    public StepIdentifyConsequence( String consequence ) {

	super( "Identy Consequence",
	       "See that can draw from the postulate" );

	explanation =
	    "See what the consequence of the postualte say.";

	setDsConsequenceExpected( consequence );
    }

    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------ */

    public void dispatch() {

	String message =
	    "Enter the consequence appeared in the postulate " +
	    "you have chosen.\n" +
	    "Use Proposition Builder.";

	JOptionPane.showMessageDialog(this, message );

	// Let the communication Manager that this object is waiting
	// input from Postulate Builder
	ComManager comManager = AGT.getComManager();
	Vector /* JTextField */ sender = new Vector();
	sender.add( AGT.getPropositionBuilder().getDoneButton() );
	comManager.cc_Prop_StepIdentifyConsequence( sender, this );
    }

    public void ccInputReady( String dsConsequence ) {

	System.out.println("IdentifyConsequence got dsConsequence: " + dsConsequence);
	
	setDsConsequenceInput( dsConsequence );
	updateContent( "The postulate concludes " + dsConsequence );
    }

}

//
// end of $RCSfile: StepIdentifyConsequence.java $
//
