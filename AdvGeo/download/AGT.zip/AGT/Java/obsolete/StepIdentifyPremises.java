/**
 * StepIdentifyPremises.java
 *
 *
 * Created: Thu Oct 02 11:16:48 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: StepIdentifyPremises.java 1.1 2003/10/06 16:26:26 NoboruM Exp NoboruM $
 */

import java.util.*;
import javax.swing.*;

public class StepIdentifyPremises extends Step {

    /* ------------------------------------------------------------
     *	Fields
     * ------------------------------------------------------------ */

    Vector /* String */ dsPremiseExpected = new Vector();
    public Vector getDsPremiseExpected() { return dsPremiseExpected; }
    public void setDsPremiseExpected(Vector newDsPremise) {
	this.dsPremiseExpected = newDsPremise;
    }
    
    Vector /* String */ dsPremiseInput = new Vector();
    public Vector getDsPremiseInput() { return dsPremiseInput; }
    public void setDsPremiseInput(Vector newDsPremiseInput) {
	this.dsPremiseInput = newDsPremiseInput;
    }
    void addDsPremiseInput( String proposition ) {
	getDsPremiseInput().add( proposition );
    }

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------ */

    public StepIdentifyPremises( Vector /* String */ dsPremiseExpected ) {

	super( "Identify Preise",
	       "Look at the premises in the postulate" );

	explanation =
	    "See what the postulate you picked up requires " +
	    "as the premises to be held. ";
	
	setDsPremiseExpected( dsPremiseExpected );
    }
    
    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------ */

    // Method called by scaffolding
    public void dispatch() {

	String message =
	    "Enter premises appeared in the postulate you have chosen.\n" +
	    "Use Equation Builder to compose propositions, or click " +
	    "appropriate ones in Postulate Browser.  " +
	    getDsPremiseExpected();
	
	JOptionPane.showMessageDialog( this, message );

	notifyComManager();
    }

    // Get a text input elsewhere
    public void ccInputReady( String premise ) {

	addDsPremiseInput( premise );

	String tmp = "The postulate's premises: ";
	for (int i = 0; i < getDsPremiseInput().size() ; i++) {
	    tmp += (String)getDsPremiseInput().elementAt(i) + ",";
	}
	updateContent( tmp );
	
	// Repeat to read premise until all expected premises are read
	if ( !setEqual( getDsPremiseInput(), getDsPremiseExpected() ) ) {
	    notifyComManager();
	} else {
	    System.out.println("InputDsPremise done!!!");
	}
    }

    // Establish communication channel on the communication manager
    void notifyComManager() {
	// Let the communication Manager that this object is waiting
	// for input from Equation Builder
	ComManager comManager = AGT.getComManager();
	Vector /* JButton */ sender = new Vector();
	sender.add( AGT.getPropositionBuilder().getDoneButton() );
	comManager.cc_Premise_StepIdentifyPremises( sender, this );
    }

}


// 
// end of $RCSfile: StepIdentifyPremises.java $
//
