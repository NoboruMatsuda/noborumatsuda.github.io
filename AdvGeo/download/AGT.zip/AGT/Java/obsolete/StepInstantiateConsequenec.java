/**
 * StepInstantiateConsequenec.java
 *
 *
 * Created: Thu Oct 02 12:00:55 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id$
 */

public class StepInstantiateConsequenec extends Step {

    public StepInstantiateConsequenec() {

	super( "Instantiate Consequence",
	       "See what can be concluded." );

	explanation =
	    "Now, find out what you can conclude " +
	    "this postulate application.";
    }
}

//
// $RCSfile$
//
