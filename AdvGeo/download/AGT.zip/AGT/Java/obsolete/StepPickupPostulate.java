/**
 * StepPickupPostulate.java
 *
 *
 * Created: Wed Oct 01 15:07:34 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: StepPickupPostulate.java 1.1 2003/10/05 22:43:17 noboru Exp noboru $
 */

import java.util.*;
import javax.swing.*;

public class StepPickupPostulate extends Step {

    /* ------------------------------------------------------------
     *	Fields
     * ------------------------------------------------------------ */

    // The posulate supporsed to be picked up
    String postulateExpected;

    public String getPostulateExpected() { return postulateExpected; }
    public void setPostulateExpected(String newPostulateExpected) {
	this.postulateExpected = newPostulateExpected;
    }

    // The postulate actually picked up
    String postulateInput;

    public String getPostulateInput() { return postulateInput; }
    public void setPostulateInput(String newPostulateInput) {
	this.postulateInput = newPostulateInput;
    }

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------ */

    public StepPickupPostulate( String postulate ) {
	
	super( "Pick up a postulate",
	       "Selecting a postulate..." );

	explanation =
	    "First thing you need to do is to choose a postulate " +
	    "that you think would apply, and enter its name " +
	    "into the top most empty justification cell.";

	setPostulateExpected( postulate );
    }

    /* ------------------------------------------------------------
     *	Method
     * ------------------------------------------------------------ */

    // Method called by scaffolding() defined in class Step
    public void dispatch() {

	String message = 
	    "Enter a postulate name that you would want to apply " +
	    "in the top most empty justification cell.";

	JOptionPane.showMessageDialog(this, message );

	// Let the communication Manager that this object is waiting
	// input from Proof window
	ComManager comManager = AGT.getComManager();
	Vector /* JTextField */ supporter =
	    AGT.getProofTable().getCurrentOpenSupporter();
	comManager.cc_ProofTable_StepPickupPostulate( supporter, this );
    }

    // Method called from class ComChannel.  Always fed a string. 
    public void ccInputReady( String postulate ) {
	updateContent( "Let's try " + postulate + " to apply." );
    }
}

//
// end of $RCSfile: StepPickupPostulate.java $
// 
