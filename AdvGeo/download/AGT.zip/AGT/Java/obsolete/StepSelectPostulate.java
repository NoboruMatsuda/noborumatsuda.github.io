/**
 * StepSelectPostulate.java
 *
 *
 * Created: Wed Oct 01 12:21:11 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id: StepSelectPostulate.java 1.1 2003/10/01 13:30:42 NoboruM Exp NoboruM $
 */

// import javax.swing.*;

public class StepSelectPostulate extends Step {

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------ */

    public StepSelectPostulate() {

	super( "Select a postulate",
	       "Select a postulate to make a forward inference" );

	explanation = "First, select a postulate to apply.";
    }

    /* ------------------------------------------------------------
     *	Method
     * ------------------------------------------------------------ */
}

//
// $RCSfile: StepSelectPostulate.java $
// 
