/**
 * StepUnifyConsequence.java
 *
 *
 * Created: Thu Oct 02 13:19:52 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * $Id: StepUnifyConsequence.java 1.1 2003/10/06 16:34:26 NoboruM Exp NoboruM $
 */

import java.util.*;
import javax.swing.*;

public class StepUnifyConsequence extends Step {

    /* ------------------------------------------------------------
     *	Field
     * ------------------------------------------------------------ */

    String consequenceExpected;
    public String getConsequenceExpected() { return consequenceExpected; }
    public void setConsequenceExpected(String newConsequenceExpected) {
	this.consequenceExpected = newConsequenceExpected;
    }

    String consequenceInput;
    public String getConsequenceInput() { return consequenceInput; }
    public void setConsequenceInput(String newConsequenceInput) {
	this.consequenceInput = newConsequenceInput;
    }

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------ */

    public StepUnifyConsequence( String consequence ) {
	
	super( "Unify Consequence",
	       "Map postulat's consequence onto the problem figure" );

	explanation =
	    "Now, see what you can conclude by applying the postulate.";

	setConsequenceExpected( consequence );
    }

    public void dispatch() {

	String message =
	    "Enter the consequence that you can actually draw " +
	    "from the application of the postulate you have chosen.";

	JOptionPane.showMessageDialog( this, message );
	
	// Let the communication Manager that this object is waiting
	// input from Proof window
	ComManager comManager = AGT.getComManager();
	Vector /* JButton */ sender = new Vector();
	sender.add( AGT.getPropositionBuilder().getDoneButton() );
	comManager.cc_Prop_StepUnifyConsequence( sender, this );
    }

    // Method called from class ComChannel.  Always fed a string. 
    public void ccInputReady( String consequence ) {
	updateContent( "We can conclude " + consequence );
	// Store the consequence in AGT so that consecutive steps can
	// refer to it.
	AGT.setFcLastAssertion( consequence );
    }
}

//
// $RCSfile: StepUnifyConsequence.java $
//
