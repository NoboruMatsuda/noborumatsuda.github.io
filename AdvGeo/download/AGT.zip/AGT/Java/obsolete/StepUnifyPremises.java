/**
 * StepUnifyPremises.java
 *
 *
 * Created: Thu Oct 02 11:44:07 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * $Id: StepUnifyPremises.java 1.1 2003/10/05 22:40:55 NoboruM Exp NoboruM $
 */

import java.util.*;
import javax.swing.*;

public class StepUnifyPremises extends Step {

    /* ------------------------------------------------------------
     *	Fields
     * ------------------------------------------------------------ */

    Vector /* String */ premiseExpected = new Vector();
    public Vector getPremiseExpected() { return premiseExpected; }
    public void setPremiseExpected(Vector newPremiseExpected) {
	this.premiseExpected = newPremiseExpected;
    }

    Vector /* String */ premiseInput = new Vector();
    public Vector getPremiseInput() { return premiseInput; }
    public void setPremiseInput(Vector newPremiseInput) {
	this.premiseInput = newPremiseInput;
    }
    void addPremiseInput( String premise ) {
	getPremiseInput().add( premise );
    }

    /* ------------------------------------------------------------
     *	Constructor
     * ------------------------------------------------------------ */

    public StepUnifyPremises( Vector /* String */ premise ) {

	super( "Unify premise",
	       "Unify postulate premise with the problem" );

	explanation =
	    "Once the postulate premise is identifed, " +
	    "then you need to overlap them onto the problem figure.";

	setPremiseExpected( premise );
    }

    /* ------------------------------------------------------------
     *	Methods
     * ------------------------------------------------------------ */

    public void dispatch() {

	String message =
	    "Fill up the premise fields underneath the postulate " +
	    "name in the justifucation column.\n" +
	    "Use Equation Builder " +
	    "if you will, or type appropriate propositions in the " +
	    "premise fields.";
	
	JOptionPane.showMessageDialog( this, message );
		
	notifyComManager();
    }

    public void ccInputReady( String premise ) {

	addPremiseInput( premise );

	String tmp = "This postulate application is supported by: ";
	for (int i = 0; i < getPremiseInput().size() ; i++) {
	    tmp += (String)getPremiseInput().elementAt(i) + ",";
	}
	updateContent( tmp );
	
	// Repeat to read premise until all expected premises are read
	if ( !setEqual( getPremiseInput(), getPremiseExpected() ) ) {
	    notifyComManager();
	} else {
	    AGT.getProofTable().getCurrentJustification().closePremiseFields();
	    System.out.println("InputPremise done!!!");
	}
    }

    // Establish communication channel on the communication manager
    void notifyComManager() {
	// Let the communication Manager that this object is waiting
	// for input from Equation Builder
	ComManager comManager = AGT.getComManager();
	Vector /* JTextField */ sender = new Vector();
	sender.add( AGT.getProofTable().getTargetPremiseField() );
	comManager.cc_Premise_StepUnifyPremises( sender, this );
    }

}

//
// $RCSfile: StepUnifyPremises.java $
//
