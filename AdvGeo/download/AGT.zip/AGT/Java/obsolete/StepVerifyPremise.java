/**
 * StepVerifyPremise.java
 *
 *
 * Created: Wed Oct 01 23:21:50 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version $Id$
 */

public class StepVerifyPremise extends Step {

    public StepVerifyPremise() {
	
	super( "Verify premises",
	       "Verify premises of the postulate" );

	explanation =
	    "Check if the premises of the postulate " +
	    "are all justified in the proof table.";
    }
}

// 
// $RCSfile$
//
