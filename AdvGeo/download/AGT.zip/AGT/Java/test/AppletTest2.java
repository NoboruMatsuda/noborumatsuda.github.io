/**
 * AppletTest.java
 *
 *
 * Created: Thu Apr 15 13:17:31 2004
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

import javax.swing.*;

public class AppletTest2 extends JApplet {

    public AppletTest2() {
	JButton button = new JButton( "TEST" );
	getContentPane().add( button );
    }

    public void init() {
	System.out.println("init 2 ...");
    }

    public void stop () {
	System.out.println("Stopping ...");
    }

    public void destroy() {
	System.out.println("Destroying...");
    }

} // AppletTest
