/**
 * Constructor.java
 *
 *
 * Created: Tue Sep 30 17:21:39 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

public class Constructor{

    public Constructor() {
	System.out.println("Null constructor called");
    }

    public Constructor( int x ) {
	// this();
	System.out.println("X = " + x);
	new A( 1 );
	System.out.println("Call B(2)");
	new B( 2 );
	System.out.println("Call B()");
	new B();
    }
    
    public static void main(String[] args) {
	new Constructor( 10 );
    }

    class A {

	public A () {
	    System.out.println("A: null constructor called");
	}

	public A (int x) {
	    // this();
	    System.out.println("A: x = " + x);
	}
    }

    class B extends A {

	public B () {
	    System.out.println("B: null constructor called");
	}

	public B ( int x ) {
	    // super( x );
	    this();
	    System.out.println("B: x = " + x);
	}
    }

} // Constructor
