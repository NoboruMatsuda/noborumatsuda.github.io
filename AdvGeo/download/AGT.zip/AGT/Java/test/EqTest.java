/**
 * EqTest.java
 *
 *
 * Created: Tue Feb 24 11:33:35 2004
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

public class EqTest{

    public EqTest() {

	String[] exp = { "(:EQ (:S A B) (:S C D))",
			 "(:eq (:a a b c) (:a c d e))",
			 "( :parallel (:S x y) (:s a b))",
			 "(:cong (:triangle (:p a) (:p b) (:p c)) (:triangle (:p d) (:p e) (:p f)) )",
			 "(:RHOMBUS (:p a) (:p b) (:p c) (:p d))"
	};

	/*
	String[] exp = { "This is (:EQ (:S A B) (:S C D)) a test" };
	*/

	for (int i = 0; i < exp.length; i++) {
	    String expEq = Equation.toEquation( exp[i] );
	    // String expEq = Equation.reformMessage( exp[i] );
	    System.out.println(exp[i] + " ==> " + expEq);
	}
    }
    
    public static void main(String[] args) {
	new EqTest();
    }

} // EqTest
