/**
 * Extends.java
 *
 *
 * Created: Tue May 13 14:17:47 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version
 */

import java.util.*;

public class Extends{

    public static void main(String[] args){
	new Extends();
    }

    public Extends (){

	A a = new A();
	B b = new B();
	Vector v = new Vector();

	v.add(a);
	v.add(b);

	Enumeration e = v.elements();
	while ( e.hasMoreElements() ) {
	    ((P)e.nextElement()).foo();
	} // end of while ()
    }

    class P {
	public void foo() {
	    System.out.println("oops");
	}
	public void boo() {
	    System.out.println("boo!");
	}
    }

    class A extends P {

	public void foo() {
	    System.out.println("a");
	}
    }

    class B extends P {
	public void foo() {
	    // System.out.println("b");
	    super.boo();
	}
    }
    
} // Extends
