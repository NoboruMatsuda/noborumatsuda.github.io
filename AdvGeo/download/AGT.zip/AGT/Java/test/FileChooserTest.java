/**
 * FileChooserTest.java
 *
 *
 * Created: Thu May 08 17:28:42 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version
 */

import javax.swing.*;
import java.awt.*;

public class FileChooserTest extends Component {

    public FileChooserTest (){
    }
    
    public static void main(String[] args){

	FileChooserTest fct = new FileChooserTest();

	JFileChooser fc = new JFileChooser();
	int x = fc.showOpenDialog(fct);

	System.out.println(x);

	System.exit(0);
    }

} // FileChooserTest
