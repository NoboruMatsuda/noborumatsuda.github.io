/**
 * GSDtest.java
 *
 *
 * Created: Fri May 09 17:00:48 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version
 */

import javax.swing.*;

public class GSDtest extends JFrame {

    private static GoalStackDisplay gsd;

    public GSDtest (){

	try {
	    String af = UIManager.getCrossPlatformLookAndFeelClassName();
	    UIManager.setLookAndFeel( af );
	} catch ( Exception e ) {
	    System.out.println( "LookAndFeel: error " + e );	    
	} // end of try-catch

	gsd = new GoalStackDisplay();
	getContentPane().add( gsd );
	pack();
	setVisible( true );
    }
    
    public static void main(String[] args){
	new GSDtest();
	gsd.addNode( GoalStackDisplay.GOAL_NODE, "X = Y", 100, 200 );
	gsd.addNode( GoalStackDisplay.OPERATOR_APPLICATION_NODE,
		     "A < B", 150, 100 );
    }

} // GSDtest
