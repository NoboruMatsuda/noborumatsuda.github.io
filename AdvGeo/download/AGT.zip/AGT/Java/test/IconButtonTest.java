/**
 * IconButtonTest.java
 *
 *
 * Created: Thu Apr 08 16:14:41 2004
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

import javax.swing.*;

public class IconButtonTest{

    public IconButtonTest() {
	
	Icon icon = new ImageIcon( "../img/menuButton.gif" );
	JButton button = new JButton( icon );

	// JButton button = new JButton( "TEST ");

	JFrame frame = new JFrame();
	frame.getContentPane().add( button );
	frame.pack();
	frame.setVisible( true );
    }
    
    public static void main(String[] args) {
	
	new IconButtonTest();
    }
} // IconButtonTest
