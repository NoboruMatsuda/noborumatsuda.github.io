/**
 * InlineEqBuilderTest.java
 *
 *
 * Created: Mon Apr 05 12:29:17 2004
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

import javax.swing.*;
import java.awt.*;

public class InlineEqBuilderTest {

    public InlineEqBuilderTest() {

	JFrame frame = new JFrame();
	InlineEqBuilder eqBuilder = new InlineEqBuilder();

	Dimension size = new Dimension( 100, 100 );

	frame.setSize( size );
	frame.getContentPane().add( eqBuilder );
	frame.pack();
	frame.setVisible( true );
    }
    
    public static void main(String[] args) {

	new InlineEqBuilderTest();
    }

} // InlineEqBuilderTest
