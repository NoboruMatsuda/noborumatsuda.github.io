/**
 * InnerClassTest.java
 *
 *
 * Created: Mon Mar 22 16:39:42 2004
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

public class InnerClassTest{

    int n = 0;

    public InnerClassTest() {
	
	for ( int i = 1; i < 10; i++ ) {

	    n++;
	    new IC();

	}
    }
    
    public static void main(String[] args) {
	new InnerClassTest();
    }

    class IC {

	public IC() {
	    
	    System.out.println("n = " + n);
	}
    }

} // InnerClassTest
