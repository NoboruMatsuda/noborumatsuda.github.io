/**
 * LayoutTest.java
 *
 *
 * Created: Fri Jan 16 23:08:49 2004
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class LayoutTest{

    public LayoutTest() {

	// Red pane  400x300
	Dimension paneSize = new Dimension( 400, 300 );
	JPanel pane = new JPanel();
	pane.setPreferredSize( paneSize );
	pane.setBackground( Color.red );
	// Yellow bar 300x250 in the red pane
	pane.add( new Bar( "test1" ) );
	
	// Frame 400x200
	JFrame frame = new JFrame();
	// Dimension frameSize = new Dimension( 400, 200 );
	// frame.setSize( frameSize );
	frame.getContentPane().add( pane );
	frame.pack();
	frame.setVisible( true );
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public static void main(String[] args) {
	LayoutTest x = new LayoutTest();
    }

    class Bar extends JPanel {

	public Bar( String name ) {

//  	    setPreferredSize( new Dimension( 300, 250 ) );
//  	    setLayout( new BorderLayout() );
//  	    setBackground( Color.yellow );

//  	    FlowLayout layout = (FlowLayout)getLayout();
//  	    layout.setAlignment( FlowLayout.LEFT  );

//  	    Border emptyBorder = BorderFactory.createEmptyBorder();
//  	    setBorder( emptyBorder );

	    System.out.println("Insets: " + getInsets() );

	    JPanel tPane = new JPanel();
	    tPane.setBackground( Color.white );
	    // tPane.setMinimumSize( new Dimension( 90, 40 ) );
	    tPane.setPreferredSize( new Dimension( 300, 10 ) );
	    // add( tPane, BorderLayout.PAGE_START );

	    JPanel aPane = new JPanel();
	    aPane.setPreferredSize( new Dimension( 10, 10 ) );
	    // add( aPane, BorderLayout.LINE_START );

	    JTextField text = new JTextField();
	    // text.setBorder( emptyBorder );
	    // text.setColumns( 5 );
	    text.setMaximumSize( new Dimension( 20, 99999 ) );
	    //add( text, BorderLayout.CENTER );
	    add( text, BorderLayout.LINE_START );

	    JButton button = new JButton( "test" );
	    button.setPreferredSize( new Dimension( 50, 10 ) );
	    // add( button, BorderLayout.CENTER );

	    JPanel bPane = new JPanel();
	    bPane.setPreferredSize( new Dimension( 10, 10 ) );
	    // add( bPane, BorderLayout.LINE_END );

	    System.out.println("text size :: " + text.getSize());

	    // text.setHorizontalAlignment( JTextField.TRAILING );
	    // text.setPreferredSize( new Dimension( 10, 10 ) );
	    // text.setMinimumSize( new Dimension( 100, 100 ) );
	    // text.setText( "test 1" );
	    
	    // add( tPane );
	    revalidate();
	}
    }

} // LayoutTest
