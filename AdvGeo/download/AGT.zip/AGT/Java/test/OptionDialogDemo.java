/**
 * OptionDialogDemo.java
 *
 *
 * Created: Tue Nov 18 22:14:54 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

import javax.swing.*;

public class OptionDialogDemo extends JFrame {

    public OptionDialogDemo() {
	
	System.out.println("start");
	int option = -1;
	/*
	  option = 
	JOptionPane.showConfirmDialog( this, "test", "TEST",
					   JOptionPane.DEFAULT_OPTION );
	*/
	JOptionPane.showMessageDialog( this, "test" );
	System.out.println("got " + option);
    }
    
    public static void main(String[] args) {

	new OptionDialogDemo();
	System.exit( 0 );
    }

} // OptionDialogDemo
