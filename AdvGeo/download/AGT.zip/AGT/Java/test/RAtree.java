/**
 * RAtree.java
 *
 *
 * Created: Mon Jul 21 21:56:50 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version
 */

import java.net.*;
import java.io.*;
import javax.swing.*;

public class RAtree extends JFrame {

    // Host name
    String hostName = "vanlehn22";
    int portNo = 9998;

    static RuleApplicationTreeDisplay ratd;
    static ServerSocket serverSocket = null;
    static Socket socket = null;
    static BufferedReader socketIn = null;

    public RAtree () {
	
	try {
	    String af = UIManager.getCrossPlatformLookAndFeelClassName();
	    UIManager.setLookAndFeel( af );
	} catch ( Exception e ) {
	    System.out.println( "LookAndFeel: error " + e );	    
	    System.exit(-1);
	} // end of try-catch

	ratd = new RuleApplicationTreeDisplay();
	getContentPane().add( ratd );
	pack();
	setVisible( true );

	//-
	//- Open socket stream
	//- 
	try {
	    serverSocket = new ServerSocket( portNo );
	} catch (IOException e) {
	    System.out.println( "ServerSocket error" );
	    e.printStackTrace();
	    System.exit(-1);
	} // end of try-catch

	System.out.println( "ServerSocket made" );

	try {
	    socket = serverSocket.accept();
	    socketIn =
		new BufferedReader
		    ( new InputStreamReader( socket.getInputStream() ) );
	} catch (IOException e) {
	    System.out.println( "socket stream error" );
	    e.printStackTrace();
	    System.exit(-1);
	} // end of try-catch
	
	System.out.println( "socket stream made" );
    }
    
    public static void main(String[] args){
	new RAtree();

	ratd.expandTree( socketIn );

	System.out.println( "closing..." );

	try {
	    socketIn.close();
	    serverSocket.close();
	    socket.close();
	} catch (IOException e) {
	    e.printStackTrace();
	} // end of try-catch

	System.out.println( "done!" );
	System.exit( 0 );
    }

} // RAtree
