/**
 * ST.java
 *
 *
 * Created: Fri Oct 31 21:50:15 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

import java.util.*;

public class ST{
    public ST() {
	
	String str = "<abc/>";

	System.out.println(str.substring(1,str.length()-2));

	/* 
	// String str = "<Integer>abc</Integer><String>str</String>";
	String str = "";
	System.out.println( ":" + removeFirstArg( str ) + ":" );
	*/
    }
    
    public static void main(String[] args) {

	new ST();

	/* 
	   StringTokenizer st = new StringTokenizer( "a b c d e " );
	   while ( st.hasMoreTokens() ) {
	   System.out.println(":" + st.nextToken() + ":");
	   }
	*/
    }

    String getFirstTag( String msg ) {
	
	String tag = "";
	int start = msg.indexOf( '<' );
	int end = msg.indexOf( '>' );

	if ( (start > -1) && (end>start)) {
	    tag = msg.substring( start, end );
	}

	return tag;
    }

    String removeFirstArg( String argList ) {
	
	String body = "";
	String tag = getFirstTag( argList );
	int index; 

	if ( tag != "" ) {
	    index = argList.indexOf( "</" + tag.substring( 1 ) );
	    body = argList.substring( index + tag.length() + 2 );
	}
	
	return body;
    }
    
} // ST
