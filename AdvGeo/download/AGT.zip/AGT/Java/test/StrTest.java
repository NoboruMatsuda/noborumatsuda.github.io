/**
 * StrTest.java
 *
 *
 * Created: Thu Sep 25 15:19:48 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

public class StrTest{
    public StrTest() {
	
    }
    
    public static void main(String[] args) {

	String s = "bcd";
	String b = "bcd";

	if ( s == b ) {
	    System.out.println("match!");
	} else {
	    System.out.println("Not match");
	} // end of else
    }
} // StrTest
