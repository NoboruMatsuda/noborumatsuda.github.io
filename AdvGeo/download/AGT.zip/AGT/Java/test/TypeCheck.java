/**
 * TypeCheck.java
 *
 *
 * Created: Tue Jan 20 16:20:43 2004
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

public class TypeCheck{

    public TypeCheck() {

	String str = "a1";
	int n = -1;

	try {
	    n = Integer.parseInt( str );
	    System.out.println("Got " + n + "!");
	} catch (NumberFormatException e) {
	    System.out.println(str + " is not a number");
	} // end of try-catch
	
    }
    
    public static void main(String[] args) {
	new TypeCheck();
    }

} // TypeCheck
