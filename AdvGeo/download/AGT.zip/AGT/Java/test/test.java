/**
 * test.java
 *
 *
 * Created: Tue Dec 23 14:01:19 2003
 *
 * @author <a href="mailto:mazda@pitt.edu">Noboru Matsuda</a>
 * @version 1.0
 */

public class test{
    public test() {
	
    }
    
    static int getPremiseID( String command ) {
	
	int firstPos = command.indexOf( ':' );
	int secondPos = command.indexOf( ':', firstPos + 1 );
	String id = command.substring( secondPos + 1 );
	return Integer.parseInt( id );
    }

    public static void main(String[] args) {

	/*
	String str = "ABC:1:50";
	System.out.println(getPremiseID( str ));

	String str2 = "ab�Q";
	System.out.println(str2.indexOf( "�Q" ));

	System.out.println("�e�X�g");
	*/

	System.out.println("test\ntest");
	

    }

} // test
