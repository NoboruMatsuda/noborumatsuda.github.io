//////////////////////////////////////////////////////////////////////
// Client.java
//   client applet
//   set up to run in a browser or as a standalone application
//////////////////////////////////////////////////////////////////////

import java.net.Socket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.URL;
import java.net.MalformedURLException;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;
import javax.swing.text.Document;
import javax.swing.text.BadLocationException;
import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.JViewport;
import javax.swing.JOptionPane;

import java.applet.AppletContext;

import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.awt.Graphics;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Dimension;

import java.util.Date;
import java.util.Vector;
import java.util.Enumeration;

import java.lang.reflect.Constructor;

//////////////////////////////////////////////////////////////////////
// class allows window closing to call client when application is
// stand alone can't call directly a dynamic routine from a static
// method
//
class ClientWindowAdapter extends WindowAdapter {

    Client client;

    ClientWindowAdapter(Client theClient) {
	client = theClient;
    }
    public void windowClosing(WindowEvent e) {
	client.close("GoodBye");
    }
}

//////////////////////////////////////////////////////////////////////
//
class DialogInternalFrame extends ClientInternalFrame {

    private JTextArea textPane;
    private JScrollPane scrollPane;
    private JScrollBar scrollBar;
    private Document theDocument;
    private KeyListener theKeyListener;

    DialogInternalFrame(String name, String title, KeyListener kl,
			Integer w, Integer h) {
	super(name, title, kl, w, h);
	
	textPane = new JTextArea();
	textPane.setLineWrap(true);
	textPane.setWrapStyleWord(true);
	textPane.setColumns(w.intValue()-30/16);
	//textPane.setFont(new Font("Serif", Font.PLAIN, 12));
	theKeyListener = kl;

	textPane.setEditable(false);
	scrollPane = new JScrollPane(textPane);
	getContentPane().add(scrollPane, BorderLayout.CENTER);
	getContentPane().addKeyListener(kl);
	
	theDocument = textPane.getDocument();
	try {
	    theDocument.insertString(0, "\n", null);
	} catch (Exception e) {
	    L.ogn("Exception: 021 " + e);
	}
    }
    
    public void setListener() {
	if (theKeyListener != null) {
	    textPane.addKeyListener(theKeyListener);
	    theKeyListener = null;
	}
    }

    synchronized public void handleCommand(String commandData) {
	super.handleCommand(commandData);
	String data = commandData;
	String command = ClientParse.getCommand(data);
	while (! command.equals("")) {
	    String arguments = ClientParse.getArguments(command, data);
	    doCommand(command, arguments);
	    data = ClientParse.removeCommand(command, data);
	    command = ClientParse.getCommand(data);
	}
    }
    
    boolean doCommand(String command, String arguments) {
	if (command.equals("<say>")) {
	    appendText(arguments);
	    return true;
	}
	return false;
    }

    synchronized public void handleCharacter(char aCharacter) {
	if (aCharacter == '\b') {
	    doBackSpace();
	} else {
	    appendText("" + aCharacter);
	}
    }

    void doBackSpace() {
	try {
	    theDocument.remove(theDocument.getLength()-2, 2);
	    theDocument.insertString(theDocument.getLength(), "\n", null);
	    textPane.setCaretPosition(theDocument.getLength()-1);
	    updateView();
	} catch (Exception e) {
	    L.ogn("Exception 024: " + e);
	}
    }

    void appendText(String text) {
	try {
	    L.ogno("Inserting {" + text + "}");
	    if (theDocument.getLength() > 20000) {
		theDocument.remove(0, 5000);
	    }
	    theDocument.insertString(theDocument.getLength()-1, text, null);
	    textPane.setCaretPosition(theDocument.getLength()-1);
	    updateView();
	} catch (BadLocationException e) {
	    L.ogn("Exception: 022 " + e);
	}
    }

    void updateView() {
	// get the height of current window
	// get the height of the current text location
	//  make the view show the text so that last text entered is at bottm
	//  when last text position is greater than view size
	try {
	    JViewport jvp = scrollPane.getViewport();
	    int h = jvp.getView().getHeight();
	    int height = (int)jvp.getExtentSize().getHeight();
	    L.ogno("Extent height is {" + height + "}");
	    int textYLocation =
		(int)textPane.modelToView(theDocument.getLength()).getY();
	    L.ogno("Text Y location is {" + textYLocation + "}");
	    L.ogno("Current Position is {" + jvp.getViewPosition() + "}");
	    if (textYLocation >= height) {
		Point p = new Point(0, textYLocation-height);
		jvp.setViewPosition(p);
		L.ogno("   New position {" + p + "}");
	    }
	    L.ogno("New Position is {" + jvp.getViewPosition() + "}");
	    //jvp.invalidate();
	    //scrollPane.invalidate();
	    //textPane.invalidate();
	    //invalidate();
	    //shudder(); // must be a better way to handle this seems
	    //to clear up text display
	} catch (Exception e) {
	    L.ogn("Exception: 026 " + e);
	}
    }

    public String getVersion() {
	return "1.0.1";
    }
}

//////////////////////////////////////////////////////////////////////
//
class BrowserInternalFrame extends ClientInternalFrame {

    private JEditorPane browser;
    private JScrollPane scrollPane;
    private JScrollBar scrollBar;
    private Vector data;
    
    BrowserInternalFrame(String name, String title, KeyListener kl,
			 Integer w, Integer h) {
	super(name, title, kl, w, h);
	
	browser = new JEditorPane();
	browser.setEditable(false);
	browser.setContentType("text/html");

	scrollPane = new JScrollPane(browser,
				     JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				     JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
	getContentPane().add(scrollPane, BorderLayout.CENTER);

	data = new Vector();
    }

    synchronized public void handleCommand(String commandData) {
	super.handleCommand(commandData);
	String data = commandData;
	String command = ClientParse.getCommand(data);
	while (! command.equals("")) {
	    String arguments = ClientParse.getArguments(command, data);
	    doCommand(command, arguments);
	    data = ClientParse.removeCommand(command, data);
	    command = ClientParse.getCommand(data);
	}
    }

    boolean doCommand(String command, String arguments) {
	if (command.equals("<update/>")) {
	    L.ogno("Browse vector contents are {" + vectorToString() + "}");
	    browser.setText(vectorToString());
	    L.ogno("Browse text contents are {" + browser.getText() + "}");
	} else if (command.equals("<append>")) {
	    L.ogno("Browser adding {" + arguments + "}");
	    data.add(arguments);
	} else if (command.equals("<erase/>")) {
	    data.clear();
	    browser.setText("");
	    repaint();
	}
	return false;
    }

    private String vectorToString() {
	String tmp = "";
	Enumeration enum = data.elements();
	while (enum.hasMoreElements()) {
	    tmp = tmp + enum.nextElement();
	}
	return tmp;
    }

    public String getVersion() {
	return "1.0";
    }
}

//////////////////////////////////////////////////////////////////////
//
class ExtraInternalFrame extends ClientInternalFrame {

    ExtraInternalFrame(String name, String title, KeyListener kl,
		       Integer w, Integer h) {
	super(name, title, kl, w, h);
	setVisible(true);
    }

    public String getVersion() {
	return "0.0";
    }
}

//////////////////////////////////////////////////////////////////////
//
public class Client extends JApplet implements KeyListener, Runnable {
    private Socket socket;
    private BufferedReader in;
    private BufferedWriter out;
    private int thePort;
    private String data;
    private Thread theThread;
    private boolean isApplet;
    private JDesktopPane desktop;
    private ClientInternalFrame currentFrames[];
    private ClientInternalFrame defaultInput;
    private boolean isDeveloper;
    private boolean developerEnabled;
    private boolean isTester;
    private boolean testerEnabled;
    private String keyBuffer;
    private String debugBuffer;
    private boolean passwordMode;
    private boolean singleCharacterReply;
    private boolean acceptInput;
    private int currW, currH;

    public static void main(String[] args) {
	// instantiate the applet
	Client theApplet = new Client();
	
	// get a window for the applet to run in
	JFrame theFrame = new JFrame();
	if (args.length == 2) {
	    if (args[0].equals("test")) {
		if (args[1].equals("develop")) {
		    theFrame.setSize(808, 734);
		} else {
		    theFrame.setSize(808, 634);
		}
	    } else {
		theFrame.setSize(808, 634);
	    }
	} else {
	    theFrame.setSize(808, 634);
	}

	// put the applet into the window
	theFrame.getContentPane().add("Center", theApplet);

	// set things so hitting close box will close the applet
	theFrame.addWindowListener(new ClientWindowAdapter(theApplet));

	// start the applet
	theApplet.init();
	theApplet.setApplet(false);

	theApplet.start();

	// show the window
	theFrame.setVisible(true);
    }

    public void updateSize(int newWidth, int newHeight) {
	currW = newWidth;
	currH = newHeight;
	if (currentFrames != null) {
	    for (int i=0; i<currentFrames.length; i++) {
	        if (currentFrames[i] != null) {
        	    currentFrames[i].updateSize(newWidth, newHeight);
	        }
	    }
	}
    }

    //////////////////////////////////////////////////////////////////////

    public void init() {
        L.ogging(true);
        L.ogn("Init");
	desktop = new JDesktopPane();
	getContentPane().add(desktop);
	currentFrames = null;
	isApplet = true;
	isDeveloper = false;
	developerEnabled = false;
	isTester = false;
	testerEnabled = false;
	defaultInput = null;
	keyBuffer = "";
	debugBuffer = "";
	singleCharacterReply = false;
	passwordMode = false;
	acceptInput = true;
        currW = 1600;
	currH = 1200;
	try {
	    socket = new Socket("pyrenees.lrdc.pitt.edu", 6020);
	    try {
		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		try {
		    out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		    theThread = new Thread(this);
		    theThread.start();
		} catch (IOException oe) {
		    L.ogn("Exception 001" + oe);
		    out = null;
		    in.close();
		    in = null;
		    socket.close();
		    socket = null;
		    close("001");
		}	    
	    } catch (IOException ie) {
		L.ogn("Exception 002" + ie);
		try {
		    socket.close();
		} catch (IOException ci) {
		    L.ogn("Exception 003" + ci);
		} finally {
		    out = null;
		    in = null;
		    socket = null;
		}
		close("002");
	    }	    
	} catch (ConnectException ce) {
	    L.ogn("Exception 004" + ce);
	    close("004");
	} catch (SocketException ste) {
	    L.ogn("Exception 005" + ste);
	    close("005");
	} catch (UnknownHostException se) {
	    L.ogn("Exception 006" + se);
	    socket = null;
	    close("006");
	} catch (IOException osi) {
	    L.ogn("Exception 007" + osi);
	    socket = null;
	    close("007");
	}	    
	L.ogn("Finished Init");
        System.out.println("Finished Init");
    }

    // used to modify exit behaviour
    public void setApplet(boolean flag) {
	isApplet = flag;
    }

    // called after init or when reactivated
    public void start() {
	send("<start/>");
	L.ogn("Started");
	super.start();
    }

    // called when paused
    public void stop() {
	if (theThread != null) {
	    send("<pause/>");
	}
	L.ogn("Paused");
	flush();
	super.stop();
    }

    // called when exiting application
    public void destroy() {
	L.ogn("Destroyed");
	close("GoodBye");
	super.destroy();
    }

    //////////////////////////////////////////////////////////////////////
    // KeyListener functions
    //   first check for special 'meta' commands for developers and testers
    // then send character to dialog 
    // send to server when user hits return otherwise store in buffer
    //////////////////////////////////////////////////////////////////////

    public void keyTyped(KeyEvent e) {
	char aCharacter = e.getKeyChar(); // get a character
	// quick check for codes
	L.ogno("" + e + " number is " + (int)aCharacter);

	if ((int)aCharacter == 26) { // short cut quit key ctl-z
	    L.ogn("Hit Ctrl-Z");
	    send("<stop/>");
	} else if ((int)aCharacter == 25) { // developer toggle ctl-y
	    if (developerEnabled == true) {
		if (isTester == false) {
		    if (isDeveloper == false) {
			isDeveloper = true;
			L.ogn("Developer mode on");
		    } else {
			isDeveloper = false;
			L.ogn("Developer mode off");
		    }
		}
	    }
	} else if ((int)aCharacter == 24) { // tester toggle ctl-x
	    if (testerEnabled == true) {
		if (isDeveloper == false) {
		    if (isTester == false) {
			isTester = true;
			L.ogn("Tester mode on");
		    } else {
			isTester = false;
			if (debugBuffer.equals("")) {
			} else {
			    send("<logbug>"+debugBuffer+"</logbug>");
			    L.ogno("Sent Debug buffer <logbug>" +
				   debugBuffer + "</logbug>");
			    debugBuffer = "";
			}
			L.ogn("Tester mode off");
		    }
		}
	    }
	} else {
	    // let the display have the character (for user feedback)
	    if (defaultInput != null) { 
		if (passwordMode == true) {
		    if (aCharacter == '\n') {
			passwordMode = false;
		    }
		}
		if (passwordMode == true) {
		    defaultInput.handleCharacter('*');
		} else {
		    if (aCharacter == '\b') {
			if (singleCharacterReply) {
			    if ((isDeveloper == true) || (isTester == true)) {
				String s = "";
				s += aCharacter;
				s = s.toLowerCase();
				aCharacter = s.charAt(0);
				defaultInput.handleCharacter(aCharacter);
			    } else {
				defaultInput.handleCharacter('u');
				defaultInput.handleCharacter('n');
				defaultInput.handleCharacter('d');
				defaultInput.handleCharacter('o');
			    }
			} else if (! keyBuffer.equals("")) {
			    defaultInput.handleCharacter(aCharacter);
			}
		    } else {
			if (aCharacter == '\n') {
			    defaultInput.handleCharacter(aCharacter);
			} else if ((int)aCharacter < 32) {
			    // ignore control characters
			} else if ((int)aCharacter > 126) { 
			    // ignore not ascii characters
			} else {
			    defaultInput.handleCharacter(aCharacter);
			}
		    }
		}
		// attempt to get input window to front without mouse click
		//   causes strange exceptions deep in java libraries ... why??
		// defaultInput.toFront();
		// defaultInput.requestFocus();
	    }
	    if ((isDeveloper == true) || (isTester == true)) {
		if (aCharacter == '\n') { // either send the buffer
		    if (isDeveloper == true) {
			send("<consult>" + debugBuffer + "</consult>");
			L.ogno("Sent Debug buffer <consult>" +
			       debugBuffer + "</consult>");
		    } else {
			send("<logbug>"+debugBuffer+"</logbug>");
			L.ogno("Sent Debug buffer <logbug>" +
			       debugBuffer + "</logbug>");
		    }
		    debugBuffer = "";
		} else if (aCharacter == '\b') {
		    if (debugBuffer.equals("")) {
		    } else {
			if (debugBuffer.charAt(debugBuffer.length()-1) == '\'') {
			    // we put two on when one was typed so we
			    // must remove two
			    debugBuffer =
				debugBuffer.substring(0,
						      debugBuffer.length()-2);
			} else {
			    debugBuffer =
				debugBuffer.substring(0,
						      debugBuffer.length()-1);
			}
		    }
		} else if ((int)aCharacter == 23) { // cancel the buffer ctl-w
		    debugBuffer = "";
		    L.ogn("Debug buffer cleared");
		} else if ((int)aCharacter < 32) { // ignore the rest
		} else if ((int)aCharacter > 126) { // ignore the rest
		} else {
		    if (aCharacter == '\'') { // add twice to escape ' in prolog
			debugBuffer = debugBuffer + aCharacter; // add char to buffer
		    }
		    debugBuffer = debugBuffer + aCharacter; // add char to buffer
		}
	    } else {
		if (singleCharacterReply == true) { // if only want a single character
		    String s = "";
		    s = s + aCharacter;
		    send(s.toLowerCase()); // send it
		    singleCharacterReply = false; // turn switch off
		} else {
		    if (aCharacter == '\n') { 
			if (keyBuffer.equals("")) { // if blank line send nl tag
			    send("<nl/>");
			} else {
			    send(keyBuffer.toLowerCase()); // send the character
			    keyBuffer = "";
			}
		    } else if (aCharacter == '\b') {
			if (keyBuffer.equals("")) {
			} else {
			    keyBuffer = keyBuffer.substring(0, keyBuffer.length()-1);
			}
		    } else if ((int)aCharacter < 32) { // ignore control character input
		    } else if ((int)aCharacter > 126) { // ignore not-ascii character input
		    } else {
			if (acceptInput == true) {
			    keyBuffer += aCharacter;
			}
		    }
		}
	    }
	    L.ogo("" + aCharacter); // echoes to stdout for verification
	}
	//repaint();
    }
    public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}

    //////////////////////////////////////////////////////////////////////
    // run checks for new incoming data (blocking) and adds any new
    // data to buffer also handles pings and (if it should happen)
    // shutting down when ping replies are not happening ... since
    // theThread maybe assigned null at any moment (including while we
    // are dealing with things in the thread we make several checks
    // here so things aren't done if thread dead
    //////////////////////////////////////////////////////////////////////

    public void run() {
	Date time = new Date();
	// get an initial time to begin  counting from
	long then = time.getTime(); 
	String buffer = "";
	int timeoutCount = 0;
	while (theThread != null) {
	    String data = "";
	    try {
		if (in != null) {
		    data = in.readLine(); // check for incoming
		    if (data == null) { // we didn't have any data
			data = "";
			time = new Date(); // get current time
			long now = time.getTime();
			if ((now - then) > 30000) { // if it's been over 30 seconds
			    timeoutCount++; // increment counter
			    if (timeoutCount > 5) { // if counter more than 3 minutes
				L.ogn("Timed out !!!"); // timeout
				close("TimeOut");
			    }
			    if (theThread != null) {
				send("<ping/>"); // send an are you there query
			    }
			    then = now; // reset to count another 30 seconds
			}
		    } else {
			timeoutCount = 0; // we got data
			then = time.getTime(); // so reset timeout to reflect we're communicating
		    }
		} else {
		    data = "";
		}
	    } catch (Exception ie) {
		if (theThread != null) { // only call close if thread is alive
		    L.ogn("Exception 008 " + ie);
		    data = "";
		    close("008"); // shutdown connection lost
		}
	    }
	    if (theThread != null) { // only do this if thread is still alive
		// process and return data not processed -- ignore ping replies: work's done
		try {
                    L.ogn("Received {" + data + "}");
		    buffer = process(buffer + ClientParse.removeCommand("<ping_reply/>", data));
		} catch (Exception ae) {
		    if (theThread != null) { // only if thread is alive
			L.ogn("Process problem " + ae);
			close("Run");
		    }
		}
	    }
	}
    }

    void bringInputToFront() {
	try {
	    if (defaultInput != null) {
		defaultInput.moveToFront();
		defaultInput.setSelected(true);
		defaultInput.setListener();
	    }
	} catch (Exception e) {
	    L.ogn("Exception 025: " + e);
	}
    }
    //////////////////////////////////////////////////////////////////////
    // process buffer and returns unprocessed data
    //////////////////////////////////////////////////////////////////////
    public String process(String newData) {
	bringInputToFront();
	if (newData.equals("")) {
	    return "";
	} else {
	    L.ogno("Processing data {" + newData + "}");
	    if (ClientParse.find("<stop/>", newData)) {
		close("GoodBye");
	    }
	    
	    String data = ClientParse.replace("<sq/>",
					      "'",
					      ClientParse.replace("<nl/>", "\n", newData));
	    L.ogno("Remove <nl/> {" + data + "}");
	    String command = ClientParse.getCommand(data);
	    L.ogno("Command is {" + command + "}");
	    String arguments = ClientParse.getArguments(command, data);
	    L.ogno("Arguments are {" + arguments + "}");
	    handleCommand(command, arguments);
	    String result = ClientParse.removeCommand(command, data);
	    L.ogno("Data left {" + result + "}");
	    return result;
	}
    }

    //////////////////////////////////////////////////////////////////////
    // handles commands:
    // <open> opens a new frame of type with name
    // <input> specifies that keyboard input be echoed to frame name
    // <single/> respond with first character hit (don't wait for enter key stroke)
    // <redirect> moves browser to a different page
    // <develop> allows developer options to occur
    // <password/> takes all input up to enter key and echoes '*'
    // <begin/> notifies client that server is ready
    // <ping/> server is curious if client still around
    // <kill> kills named frame
    // <stop/> tells client that server is disconnecting
    // <accept/> allows user input to be sent to server
    // <ignore/> stops user input from being sent to server
    // <version/> return version information
    // assumes all others are references to particular frames
    void handleCommand(String command, String arguments) {
	L.ogno("Handling command {" + command + "}");
	L.ogno("  with arguments {" + arguments + "}");
	if (command.equals("")) {
	} else if (command.equalsIgnoreCase("<open>")) {
	    String typeOfPane = ClientParse.getArgument("type", arguments);
	    String nameOfPane = ClientParse.getArgument("name", arguments);
	    String titleOfPane = ClientParse.getArgument("title", arguments);
	    String nameOfClass = ClientParse.getArgument("class", arguments);
	    openNewInternalFrame(typeOfPane, nameOfPane, titleOfPane, nameOfClass);
	} else if (command.equalsIgnoreCase("<input>")) {
	    defaultInput = getFrame("<"+arguments+">");
	    if (defaultInput != null) {
		bringInputToFront();
	    } else {
		L.ogn("Bad <input> command");
	    }
	} else if (command.equalsIgnoreCase("<accept/>")) {
	    acceptInput = true;
	} else if (command.equalsIgnoreCase("<ignore/>")) {
	    acceptInput = false;
	} else if (command.equalsIgnoreCase("<kill>")) {
	    removeFrame(arguments);
	} else if (command.equalsIgnoreCase("<comment>")) {
	    // we ignore this data intentionally
	} else if (command.equalsIgnoreCase("<single/>")) {
	    singleCharacterReply = true;
	} else if (command.equalsIgnoreCase("<redirect>")) {
	    redirect(arguments);
	} else if (command.equalsIgnoreCase("<password/>")) {
	    passwordMode = true;
	} else if (command.equalsIgnoreCase("<version>")) {
	    ClientInternalFrame CIF = getFrame("<" + arguments + ">");
	    if (CIF != null) {
		send("<log><version><client>" + getVersion() + "</client>" +
		     CIF.getXMLStartTag() + CIF.getVersion() + CIF.getXMLEndTag() +
		     "</version></log>");
	    } else {
		send("<log>Version " + getVersion() + "</log>");
	    }
	} else if (command.equalsIgnoreCase("<stop/>")) {
	    close("GoodBye");
	} else if (command.equalsIgnoreCase("<develop/>")) {
	    enableDeveloperActions();
	} else if (command.equalsIgnoreCase("<test/>")) {
	    enableTesterActions();
	} else if (command.equalsIgnoreCase("<debug>")) {
	    L.og(arguments);
	} else if (command.equalsIgnoreCase("<start/>")) {
	} else if (command.equalsIgnoreCase("<ping/>")) {
	    send("<ping_reply/>");
	} else if (command.equalsIgnoreCase("<ping_reply/>")) {
	} else {
	    ClientInternalFrame theFrame = getFrame(command);
	    if (theFrame != null) {
		theFrame.handleCommand(arguments);
	    } else {
		L.ogn("Unknown frame reference to {" + command + "}");
		L.ogn("  with arguments {" + arguments + "}");
	    }
	}
    }

    ClientInternalFrame getFrame(String tag) {
	if (currentFrames != null) {
	    for (int i=0; i<currentFrames.length; i++) {
		L.ogn("Search {" + tag + "} Frame {" + currentFrames[i].getXMLStartTag() + "}");
		if (tag.equalsIgnoreCase(currentFrames[i].getXMLStartTag())) {
		    L.ogn("Matched");
		    return currentFrames[i];
		}
	    }
	}
	return null;
    }

    void removeFrame(String name) { // essentially relies on garbage collection
	ClientInternalFrame theCIF = getFrame("<" + name + ">");
	if (theCIF != null) {
	    theCIF.handleCommand("<hide/>");
	    theCIF.handleCommand("<die/>");
	    if (currentFrames != null) {
		for (int i=0; i<currentFrames.length; i++) {
		    if (name.equalsIgnoreCase(currentFrames[i].getName())) {
			currentFrames[i] = null;
			// check special case where frame we are removing is referenced by input
			if (defaultInput == theCIF) {
			    defaultInput = null;
			}
			// input
			break; // no need to look further
		    }
		}
	    }
	}
    }

    void openNewInternalFrame(String type, String name, String title, String className) {
	L.ogo("Creating new pane of type {" + type + "} called {" + name);
	L.ogno("} with title {" + title + "} of class {" + className + "}");
	ClientInternalFrame newCIF = null;

	Integer currWO = new Integer(currW);
	Integer currHO = new Integer(currH);

	if (type.equalsIgnoreCase("dialog")) {
	    newCIF = new DialogInternalFrame(name, title, this, currWO, currHO);
	} else if (type.equalsIgnoreCase("browser")) {
	    newCIF = new BrowserInternalFrame(name, title, this, currWO, currHO);
	} else if (type.equalsIgnoreCase("special")) {
	    try {
		Class theClass = Class.forName(className);
		Class[] parameters = new Class[5];
		parameters[0] = Class.forName("java.lang.String");
		parameters[1] = Class.forName("java.lang.String");
		parameters[2] = Class.forName("java.awt.event.KeyListener");
		parameters[3] = Class.forName("java.lang.Integer");
		parameters[4] = Class.forName("java.lang.Integer");
		Constructor constructor = theClass.getConstructor(parameters);
		Object[] arguments = new Object[5];
		arguments[0] = name;
		arguments[1] = title;
		arguments[2] = this;
		arguments[3] = currWO;
		arguments[4] = currHO;
		newCIF = (ClientInternalFrame)constructor.newInstance(arguments);
		// newCIF = new DrawingInternalFrame(name, title, this);
	    } catch (Exception e) {
		L.ogn("Special Class bad: " + e);
		close("023");
	    }
	} else {
	    newCIF = new ExtraInternalFrame(name, title, this, currWO, currHO);
	}
	newCIF.setVisible(true);
	desktop.add(newCIF);
	if (currentFrames == null) {
	    currentFrames = new ClientInternalFrame[1];
	    currentFrames[0] = newCIF;
	} else {
	    // does array have an empty slot
	    int loc = -1;
	    for (int i=0; i<currentFrames.length; i++) {
		if (currentFrames[i] == null) {
		    loc = i;
		    break;
		}
	    }
	    if (loc == -1) { // if no empty slot then grow array
		ClientInternalFrame tmp[] = currentFrames;
		currentFrames = new ClientInternalFrame[tmp.length+1];
		for (int i=0; i<tmp.length; i++) {
		    currentFrames[i] = tmp[i];
		}
		currentFrames[tmp.length] = newCIF;
	    } else { // otherwise use it to hold newCIF
		currentFrames[loc] = newCIF;
	    }
	}
    }

    void enableDeveloperActions() {
	// this will allow user to do things like update server with <consult/>
	developerEnabled = true;
	// and outputs to stdout -- command-line console or java console if in browser
	L.ogging(true); //developerEnabled);
    }

    void enableTesterActions() {
	// this will allow user to do things like update server with <consult/>
	testerEnabled = true;
    }

    //////////////////////////////////////////////////////////////////////
    public void close(String ExitCondition) {
	if (isApplet) {
	    if (theThread != null) {
		L.ogn("Code base is {" + getCodeBase() + "}");
		redirect(getCodeBase() + ExitCondition + ".html");
	    }
	} else {
	    redirect(ExitCondition);
	}
    }
    
    synchronized void redirect(String Where) {
	L.ogn("Closing ... going to {" + Where + "}");
	theThread = null;
	if (currentFrames != null) {
	    for (int i=0; i<currentFrames.length; i++) {
	        currentFrames[i] = null;
	    }
	    currentFrames = null;
        }
	defaultInput = null;
	if (out != null) {
	    try {
		out.write("\u0004"); // DO NOT CALL SEND/WRITE HERE exception could lock loop
		out.flush();
		out.write("<stop/>\u0004");
		out.flush();
		out.close();
	    } catch (IOException ie) {
		L.ogn("Exception 009" + ie);
	    }
	    out = null;
	}
	if (in != null) {
	    try {
		in.close();
	    } catch (IOException ie) {
		L.ogn("Exception 010" + ie);
	    }
	    in = null;
	}
	if (socket != null) {
	    try {
		socket.close();
	    } catch (IOException ie) {
		L.ogn("Exception 011" + ie);
	    }
	    socket = null;
	}
	if (isApplet) {
	    try {
		getAppletContext().showDocument(new URL(Where));
	    } catch (MalformedURLException me) {
		L.ogn("Exception 015: " + me);
	    } catch (Exception e) {
		L.ogn("Exception in redirect: " + e);
	    }
	} else {
	    System.exit(0);
	}
    }

    String getVersion() {
	return "1.0.1";
    }

    //////////////////////////////////////////////////////////////////////
    // output handlers here
    //////////////////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////
    // sync this to ensure no overlapping output in threads
    synchronized void send(String data) {
	write(data + "\u0004");
	flush();
	L.ogn("Sent {" + data + "}");
    }
    
    //////////////////////////////////////////////////////////////////////
    synchronized public void write(String data) {
	if (out != null) {
	    try {
		out.write(data);
	    } catch (IOException oe) {
		L.ogn("Exception 012" + oe);
		data = null;
		close("012");
	    }
	}
    }

    //////////////////////////////////////////////////////////////////////
    synchronized public void write(char data) {
	if (out != null) {
	    try {
		out.write(data);
	    } catch (IOException oe) {
		L.ogn("Exception 013" + oe);
		close("013");
	    }
	}
    }

    //////////////////////////////////////////////////////////////////////
    synchronized public void flush() {
	if (out != null) {
	    try {
		out.flush();
	    } catch (IOException oe) {
		L.ogn("Exception 014" + oe);
		close("014");
	    }
	}
    }
}

//////////////////////////////////////////////////////////////////////
// end of Client.java
//////////////////////////////////////////////////////////////////////
