import javax.swing.JInternalFrame;
import java.awt.event.KeyListener;

///////////////////////////////////////////////////////////////////////
// essentially so we can take advantage of polymorphism but also
// allows us to centralize through inheiretence some common
// functionality

public class ClientInternalFrame extends JInternalFrame {

    private String name;
    private int sx, sy, w, h;
    private int fw, fh;
    private int maxW, maxH;
    private KeyListener theKeyListener;

    public ClientInternalFrame(String aName, String title, KeyListener kl,
			       Integer width, Integer height) {
	super(title, true);
	setTitle(title + " " + getVersion());
	theKeyListener = kl;
	name = aName;
	sx = 0;
	sy = 0;
	maxW = 1600;
	maxH = 1200;
	fw = width.intValue();
	fh = height.intValue();
	w = fw;
	h = fh;
    }
    
    public void setListener() {
	if (theKeyListener != null) {
	    getContentPane().addKeyListener(theKeyListener);
	    theKeyListener = null;
	}
    }

    public String getName() {
	return name;
    }

    public String getXMLStartTag() {
	return "<" + getName() + ">";
    }

    public String getXMLEndTag() {
	return "</" + getName() + ">";
    }

    synchronized public void handleCommand(String commandData) {
	String data = commandData;
	String command = ClientParse.getCommand(data);
	while (! command.equals("")) {
	    String arguments = ClientParse.getArguments(command, data);
	    doCommand(command, arguments);
	    data = ClientParse.removeCommand(command, data);
	    command = ClientParse.getCommand(data);
	}
    }

    private boolean doCommand(String command, String arguments) {
	if (command.equals("<show/>")) {
	    updateSize(fw, fh);
	    setVisible(true);
	} else if (command.equals("<hide/>")) {
	    setVisible(false);
	} else if (command.equals("<die/>")) {
	    setVisible(false);
	} else if (command.equals("<sx>")) {
	    if (! arguments.equals("")) {
		sx = Integer.parseInt(arguments);
	    }
	} else if (command.equals("<sy>")) {
	    if (! arguments.equals("")) {
		sy = Integer.parseInt(arguments);
	    }
	} else if (command.equals("<w>")) {
	    if (! arguments.equals("")) {
		w = Integer.parseInt(arguments);
	    }
	} else if (command.equals("<h>")) {
	    if (! arguments.equals("")) {
		h = Integer.parseInt(arguments);
	    }
	} else {
	    return false;
	}
	return true;
    }

    public void updateSize(int newWidth, int newHeight) {
	fw = newWidth;
	fh = newHeight;
	fixSize();
    }

    /// this is a real Kludge trying to force dialog window to update
    /// properly so that text formattin is not garbled on display
    public void shudder() {
	//fw++;
	//fh++;
	fixSize();
	//fw--;
	//fh--;
	//fixSize();
    }

    public void fixSize() {
	L.ogno(name + " Size is " + (w*fw)/maxW + ", " + (h*fh)/maxH);
        setSize((w*fw)/maxW, (h*fh)/maxH);
	L.ogno(name + " Loc is " + (sx*fw)/maxW + ", " + (sy*fh)/maxH);
        setLocation((sx*fw)/maxW, (sy*fh)/maxH);
	//invalidate();
	L.ogno("Now size is " + getWidth() + ", " + getHeight());
    }

    public void handleCharacter(char aCharacter) {
	L.ogno("Frame " + name + " is handling " + aCharacter);
    }

    public String getVersion() {
	return "1.0";
    }
}
