//////////////////////////////////////////////////////////////////////
// provides static methods for parsing xml commands
public class ClientParse {
    // looks for the first occurence of < and then > and returns
    // everything between them and them ... getCommand("<duh>stuff")
    // will return "<duh>"
    public static String getCommand(String data) {
	int start = data.indexOf('<');
	int end = data.indexOf('>');
	if ((start > -1) && (end > start)) {
	    return data.substring(start, end+1);
	} else {
	    L.ogno("Strange command in {" + data + "}");
	    return "";
	}
    }

    // if command is a standalone tag "<sometext/>" returns ""
    // otherwise assumes if command is <sometext> that there exists
    // </sometext> searches for it and returns what is inbetween the
    // two getArguments("<duh>", "<duh>blah</duh>") will return "blah"
    // getArguments("<duh/", "<duh/>stuff") will return ""
    public static String getArguments(String command, String data) {
	if (command.equals("")) {
	    return "";
	} else {
	    int command_length = command.length();
	    L.ogno("Command length = " + command_length);
	    if (command.charAt(command_length - 2) == '/') {
		return ""; // must be standalone tag
	    } else {
		String command_end = "</" + command.substring(1);
		int end = data.indexOf(command_end);
		return data.substring(command_length, end);
	    }
	}
    }

    // as above only comandName is not enclosed in "<" and ">"
    // returns same as above
    public static String getArgument(String commandName, String data) {
	String start = "<" + commandName + ">";
	String stop = "</" + commandName + ">";
	int si = data.indexOf(start);
	int ei = data.indexOf(stop);
	if ((si > -1) && (ei > si)) {
	    return data.substring(si+2+commandName.length(), ei);
	} else {
	    return "";
	}
    }

    // returns true if a string is in data
    public static boolean find(String toFind, String data) {
	if (data.indexOf(toFind) > -1) {
	    return true;
	} else {
	    return false;
	}
    }

    // removes the command from the input data
    // removeCommand("<duh>", "<duh>stuff</duh>otherstuff") will
    // return "otherstuff"
    public static String removeCommand(String command, String data) {
	if (command.equals("")) { // no command
	    return "";
	} else {
	    int command_length = command.length(); // get the length
	    int start = data.indexOf(command); // find where it starts in data
	    if (start < 0) { // not in data
		return data;
	    } else if (start == 0) { // first thing in data so return everything after it
		if (command.charAt(command_length - 2) == '/') {
		    if (command_length == data.length()) {
			return "";
		    } else {
			return data.substring(command_length);
		    }
		} else {
		    String command_end = "</" + command.substring(1);
		    int end = data.indexOf(command_end);
		    if (end+command_length+1 == data.length()) {
			return "";
		    } else {
			return data.substring(end+command_length+1);
		    }
		}
	    } else { // must return what's before and what's after
		String front = data.substring(0, start);
		if (command.charAt(command_length - 2) == '/') {
		    if (start+command_length == data.length()) {
			return front;
		    } else {
			return front + data.substring(start+command_length);
		    }
		} else {
		    String command_end = "</" + command.substring(1);
		    int end = data.indexOf(command_end);
		    if (end+command_length+1 == data.length()) {
			return front;
		    } else {
			return front + data.substring(end+command_length+1);
		    }
		}
	    }
	}
    }

    public static String replace(String item, String newItem, String data) {
	int loc = data.indexOf(item);
	if (loc < 0) {
	    return data;
	} else {
	    int len = item.length();
	    if (len == data.length()) {
		return data.substring(0, loc) + newItem;
	    } else {
		return data.substring(0, loc) + newItem +
		    replace(item, newItem, data.substring(loc+len));
	    }
	}
    }
    String getVersion() {
	return "1.0";
    }
}

