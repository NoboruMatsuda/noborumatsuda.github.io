import javax.swing.JInternalFrame;

import java.awt.event.KeyListener;

import java.awt.BorderLayout;

//////////////////////////////////////////////////////////////////////
//
public class DrawingInternalFrame extends ClientInternalFrame {
    DrawingPane drawingPane;

    public DrawingInternalFrame(String name, String title, KeyListener kl, Integer w, Integer h) {
	super(name, title, kl, w, h);
	drawingPane = new DrawingPane();
	drawingPane.updateSize(w.intValue(), h.intValue());
	getContentPane().add(drawingPane, BorderLayout.CENTER);
    }

    synchronized public void handleCommand(String commandData) {
	super.handleCommand(commandData);
	String data = commandData;
	String command = ClientParse.getCommand(data);
	while (! command.equals("")) {
	    String arguments = ClientParse.getArguments(command, data);
	    doCommand(command, arguments);
	    data = ClientParse.removeCommand(command, data);
	    command = ClientParse.getCommand(data);
	}
    }
    
    public void updateSize(int newWidth, int newHeight) {
	super.updateSize(newWidth, newHeight);
	drawingPane.updateSize(getWidth(), getHeight());
    }

    private boolean doCommand(String command, String arguments) {
	L.ogo("DrawingInternalFrame is handling command {" + command);
	L.ogno("} with arguments {" + arguments + "}");
	if (command.equals("<vector>")) {
	    drawingPane.drawVector(arguments);
	    return true;
	} else if (command.equals("<axes>")) {
	    drawingPane.drawAxes(arguments);
	    return true;
	} else if (command.equals("<erase/>")) {
	    drawingPane.erase();
	    return true;
	} else if (command.equals("<body>")) {
	    drawingPane.drawBody(arguments);
	    return true;
	}
	return false;
    }

    public String getVersion() {
	return "1.1";
    }
}

