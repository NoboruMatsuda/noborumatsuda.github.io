//////////////////////////////////////////////////////////////////////
// provides very simple logging tools
public class L {
    static boolean doLogging = false;

    public static void ogging(boolean flag) {
	doLogging = flag;
    }

    public static void og(String message) {
	if (doLogging) {
	    System.out.print(message);
	}
    }

    public static void ogn(String message) {
	if (doLogging) {
	    System.out.println(message);
	}
    }

    public static void ogo(String message) {
	// so adding o to og turns off log without having to type a
	// lot or remove line of comment
    }

    public static void ogno(String message) {
	// same as ogo
    }
}
