%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
get_a_file_lock(FileName) :-
	atom_concat(FileName, '.lock', LockFileName),
	wait_for_unlocked(LockFileName),
	open(LockFileName, write, Stream, [close_on_abort(true)]),
	close(Stream).

wait_for_unlocked(LockFileName) :-
	exists_file(LockFileName),
	sleep(1),
	wait_for_unlocked(LockFileName).
wait_for_unlocked(_).
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delete_a_lock_file(FileName) :-
	atom_concat(FileName, '.lock', LockFileName),
	delete_file(LockFileName).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
write_data_list(FileName, DataList) :-
	get_a_file_lock(FileName),
	open(FileName, write, Stream, [close_on_abort(true)]),
	file_write_list(Stream, DataList),
	close(Stream).

file_write_list(_, []).
file_write_list(Stream, [First|Rest]) :-
	write(Stream, First),
	file_write_list(Stream, Rest).

file_add_data_list(FileName, DataList) :-
	get_a_file_lock(FileName),
	open(FileName, append, Stream, [close_on_abort(true)]),
	file_write_list(Stream, DataList),
	close(Stream).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
find_in_file(FileName, Mask, Found) :-
	get_a_file_lock(FileName),
	open(FileName, read, Stream, [close_on_abort(true)]),
	find_in_open_file(Stream, Mask, Found),
	close(Stream),
	delete_a_lock_file(FileName).

find_in_open_file(Stream, Mask, Found) :-
	read(Stream, Value),
	see_if_matches(Stream, Value, Mask, Found).

see_if_matches(_, end_of_file, _, false) :-
	debugn('End of File'),
	!.
see_if_matches(_, Value, Value, true) :-
	debugn(['Found match ', Value]),
	!.
see_if_matches(Stream, _, Mask, Found) :-
	debugn('Try Again'),
	find_in_open_file(Stream, Mask, Found).
