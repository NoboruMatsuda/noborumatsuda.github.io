%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
debug(Message) :-
	not(server(yes)),
	!,
	write_list(Message).
debug(Message) :-
	send_message_nl(['<debug>', Message, '</debug>']).

debugn(Message) :-
	not(server(yes)),
	!,
	debug(Message),
	nl.
debugn(Message) :-
	send_message_nl(['<debug>', Message, '<nl/></debug>']).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
bug(Message) :-
	not(server(yes)),
	!,
	debug(Message).
bug(Message) :-
	server_log(['Error ', Message]),
	send_message_nl(['<debug>***ERROR*** ', Message, '<nl/></debug>']).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% counter(Identifer, Count)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- dynamic (counter/2).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% counter_clear(+Counter)
%%  removes all occurences of counter(Counter, _) and asserts
%%    counter(Counter, 0)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
counter_clear(Counter) :-
	retractall(counter(Counter, _)),
	assert(counter(Counter, 0)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% counter_increment(+Counter)
%%  adds one to counter
%%  NOTE: if counter does not exist asserts counter(Counter, 1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
counter_increment(Counter) :-
	(retract(counter(Counter, Count)); Count = 0),
	!, %% stops any backtrack over disjunction
	NewCount is Count + 1,
	assert(counter(Counter, NewCount)).
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% counter_decrement(+Counter)
%%  removes old data and asserts ne with counter value decremented by 1
%% NOTE: will not decrement below 0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
counter_decrement(Counter) :-
	(retract(counter(Counter, Count)); Count = 0),
	!,
	counter_decrement_support(Counter, Count).
counter_decrement_support(_, 0) :-
	!.
counter_decrement_support(Counter, Count) :-
	NewCount is Count - 1,
	assert(counter(Counter, NewCount)).
	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% counter_count(+Counter, -Count)
%%  Counter is name of a Counter and Count is its current value
%%  Count bound to 0 is counter does not exist
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
counter_count(Counter, Count) :-
	counter(Counter, Count),
	!.
counter_counter(_, 0).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
assert_all([]).
assert_all([First|Rest]) :-
	catch(assert(First), Error, handle_error_assert_all(Error, First)),
	assert_all(Rest).

handle_error_assert_all(Error, Assertion) :-
	bug(['Error asserting {', Assertion, '}: ', Error]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
call_all([]).
call_all([First|Rest]) :-
	catch(call(First), Error, handle_error_call_all(Error, First)),
	call_all(Rest).

handle_error_call_all(Error, Call) :-
	bug(['Error calling {', Call, '}: ', Error]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

