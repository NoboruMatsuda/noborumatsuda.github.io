%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% server_start.pl
%%  entry point for server
%%  opens a server socket and then starts the server_dispatch loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
server_start :-
	tcp_socket(Socket), %% get the socket
	tcp_bind(Socket, 8576), %% and bind it to the port
	tcp_listen(Socket, 50), %% set max connections to 50 (arbitray for now)
	tcp_open_socket(Socket, ServerSocketStream, _), %% open the socket
	server_dispatch(ServerSocketStream),
	tcp_close_socket(Socket).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% for applications that may need to run without server
server(yes).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% client_in_stream(InStream)
%% client_out_stream(OutStream)
%%  used to hold a clients input and out put streams for use by read_message
%%  and send_message
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- dynamic(client_socket/1).
:- dynamic(client_in_stream/1).
:- dynamic(client_out_stream/1).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% server_dispatch(+ServerSocketStream)
%%   loops (forever)
%%     wait for connection
%%     note number of connections (just FYI data)
%%     fork
%%       if forked PID is the client (PID == child) then
%%         open the streams call the client and when its done
%%   	   close the streams and quit (NOTE: client must ALWAYS succeed)
%%       otherwise
%%         close the socket and decrement the number of connections
%%     repeat loop
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
server_dispatch(ServerSocketStream) :-
	tcp_accept(ServerSocketStream, Client, _ClientIPAddress),
	fork(PID),
	(
		PID == child
	 -> 	sclogn('Client connection'),
		get_time(Time),
		assert(client_start_time(Time)),
		tcp_open_socket(Client, InStream, OutStream),
		assert(client_socket(Client)),
		assert(client_in_stream(InStream)),
		sclogn(['In stream {', InStream, '}']),
		assert(client_out_stream(OutStream)),
		sclogn(['Out stream {', OutStream, '}']),
		%% can use bug, debug and debugn from here until sockets killed
		%% login logs user in and the executes client application
		catch(server_login, E, program_error_handler(E)),
		client_shutdown
	;	tcp_close_socket(Client)
	),
	server_dispatch(ServerSocketStream).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% client_shutdown
%%  closes streams used by client and halts process
%%  should be able to use this to kill clients on error catches
%% Call this to kill client
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
client_shutdown :-
	do_registered_shutdown,
	server_close_in_stream,
	server_close_out_stream,
	server_close_client_socket,
	sclogn('Client halting'),
	halt.

server_close_client_socket :-
	client_socket(Client),
	!, % commit
	sclogn('Closing client socket'),
	retractall(client_socket(_)),
	tcp_close_socket(Client).
server_close_client_socket.

server_close_in_stream :-
	client_in_stream(Stream),
	!, % commit
	sclogn('Closing in stream'),
	retractall(client_in_stream(_)),
	close(Stream).
server_close_in_stream.

server_close_out_stream :-
	client_out_stream(Stream),
	!, % commit
	sclogn('Closing out stream'),
	retractall(client_out_stream(_)),
	close(Stream).
server_close_out_stream.

:- dynamic(registered_shutdowns/1).
registered_shutdowns([]).

do_registered_shutdown :-
	registered_shutdowns(Calls),
	!,
	do_registered_shutdowns(Calls).
do_registered_shutdown.
 
do_registered_shutdowns([]).
do_registered_shutdowns([First|Rest]) :-
	(catch(call(First), E, bug(['Error during shutdown: ', E])); true),
	do_registered_shutdowns(Rest).

register_a_shutdown_call(Call) :-
	registered_shutdowns(Calls),
	retractall(registered_shutdowns(_)),
	assert(registered_shutdowns([Call|Calls])).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% program_error_handler(ErrorExceptionThatWasThrownOrOtherWiseGenerated)
%%  should log message about error and then call client shoutdown
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
program_error_handler(Error) :-
	bug(['Exception occurred: ', Error]),
	client_shutdown.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% basic read and write routines for communicating with clients follow
%% four basic routins are supplied
%% 1) read_message(-Message)
%%  returns with Message bound to prolog string containing message data sent
%%  by client
%% 2) read_character(-Character)
%%  returns with Character bound to most recently read character from client
%% 3) send_message(+Message)
%%  sends a message to the client (not flushed)
%% 4) send_message_nl(+Message)
%%  sends a message to the client (flushed)
%% NOTE: client needs to send messages that are control-d terminated
%% Implemented as a character read because it is not a good assumption that
%%  read will get valid prolog input ... if this appears to be a performance
%%  hit ... we could try read_line_to_codes ... 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% may be asserted during login if user directives are set appropriately
:- dynamic(is_developer/1).
:- dynamic(is_debug/1).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% read_atom(Atom)
%% calls read message(Blah) and converts Blah to an atom
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
read_atom(Atom) :-
	read_message(Message),
	string_to_atom(Message, Atom).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% read_message(-Message)
%%  returns with Message bound to prolog string repesenting input from
%%  callers (clients) InStream ... see client_in/out_streams/1 above
%%  NOTE: special case Message may be the atom abort
%%   ping messages are not returned but handled internally
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
read_message(Message) :-
	client_in_stream(InStream),
	read_message(InStream, NewMessage),
	handle_pings(NewMessage, Message),
	string_to_atom(NewMessage, ForOutput),
	track_user_history(in, [ForOutput, ' {', NewMessage, '}']).
read_message(_) :-
	bug('read_message failed').

%% does not return ping messages but handles them internally
handle_pings("<ping/>", Message) :- %% got an 'are you there?' so say yes
	!,
	send_message_nl("<ping_reply/>"),
	read_message(Message).
handle_pings("<ping_reply/>", Message) :- %% can ignore these as work done
	!, %%  when character read done
	read_message(Message).
%% this provides developer access via the client and as such should only be
%%  allowed when is_developer(yes) is in facts
%% these commands are of the form <consult-Term/>
handle_pings(Command, Message) :-
	is_developer(_),
	is_debug(yes),
        append("<consult-", Rest, Command),
	append(Directive, "/>", Rest),
        !, %% commit if above succeeds
        catch(do_the_directive(Directive), E, directiveError(E)),
        read_message(Message).
handle_pings(Command, Message) :-
	append("<log>", Rest, Command),
	append(Information, "</log>", Rest),
	!, %% commit
	track_user_history(note, Information),
	read_message(Message).
handle_pings(Message, Message).

%% supports special mode above
%% converts directive to term and calls term replies to client with
%% bindings resulting from call ... NOTE even if call fails this should succeed
%%  because we wrapped call to here in a catch that should succeed
do_the_directive(String) :-
        string_to_atom(String, Atom),
        atom_to_term(Atom, Term, Bindings),
        (call(Term); true),
        !, %% no backtrack over disjunction
        send_message_nl(['<debug>', Bindings, '</debug>']).

%% notifies client of error if error occurs handling directive
directive_error(Error) :-
        send_message(['<debug>', Error, '</debug>']).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% read_message(+InStream, -Message)
%%   returns with Message bound to input from InStream
%%   NOTE: Message is a prolog string (array of char_codes)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
read_message(InStream, Message) :-
	read_character(InStream, Letter), % get first character
	char_code(Letter, Ascii), % get ascii char_code
	read_message(InStream, Ascii, [], Message).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% read_message(+InStream, +AsciiCodeOfCharJustRead,
%%                                                MessageAccumulator, -Message)
%%    not intended for use outside of this file
%%  this calls read_character and builds the prolog string for Reply
%%  Reply contains all characters sent except one
%%  if character read is code 4 (control-d) then consider Reply built
%%   (consider control-d to be end of input message marker)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
read_message(_, 4, [], '') :- % handle case where input is null
	!.
read_message(_, 4, Message, Message) :- % hit end of input so return string
	!.
read_message(In, Letter, AccumulatedMessage, Message) :- % build the string
	read_character(In, NewLetter), % get the character
	char_code(NewLetter, Ascii),
	append(AccumulatedMessage, [Letter], NewAccumulatedMessage),
	read_message(In, Ascii, NewAccumulatedMessage, Message).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% read_character(-TheCharacterRead)
%%  returns with TheCharacterRead bound to the next available character in the
%%  clients input stream (see client_in_stream/1 above) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
read_character(TheCharacterRead) :-
	client_in_stream(InStream),
	read_character(InStream, TheCharacterRead),
	char_code(ForOutput, TheCharacterRead),
	track_user_history(in, [ForOutput, '{', TheCharacterRead, '}']).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% read_character(+InStream, -TheCharacter)
%%   reads a single character from InStream
%% NOTE: blocks for 30 seconds and then updates timeout count ... will assume
%%  that connection is lost if we get more than 5 timeouts in a row (about
%%  three minutes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
read_character(InStream, TheCharacter) :-
	wait_for_input([InStream], InNow, 30), % InStream is Stream ready to read
	get_available_character(InStream, InNow, TheCharacter).

handle_error_read(Error, 4) :- % the 4 (ctrl-d) ensures that things succeed with current contents
	bug(['Error reading from client ', Error]),
	server_close_in_stream.

%% if wait timed out increment timeout count; check if too many timeouts
%% otherwise get the character that has come in
get_available_character(InStream, [], TheCharacter) :-
	!,
	counter_increment(timeouts),
	counter(timeouts, Count),
	loop_unless_timed_out(InStream, Count, TheCharacter).
get_available_character(_, [In], TheCharacter) :-
	counter_clear(timeouts),
	catch(get_char(In, TheCharacter), E, handle_error_read(E, TheCharacter)).

%% if we have timed out more than five times assume connection is lost
%% (after roughly 3 minutes) and shutdown server process ... otherwise
%% try again
loop_unless_timed_out(InStream, Count, TheCharacter) :-
	Count =< 5,
	send_message_nl('<ping/>'),
	read_character(InStream, TheCharacter).
loop_unless_timed_out(_, Count, _) :-
	Count > 5,
	client_shutdown.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% send_message(+Message)
%%  sends Message to client (example call send_message("Hello")
%%  does not flush so client may not recieve until a flush is performed
%% NOTE: uses client_out_stream/1
%% NOTE: Message is a prolog string (a list of character codes)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
send_message(Message) :-
	client_out_stream(OutStream),
	!, % commit
	send_message(OutStream, Message),
	track_user_history(out, Message).
send_message(Message) :-
	server_log(['Not sent {', Message, '}']).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% send_message(+OutStream, +Message)
%%  not intended for use outside of this file
%%  as noted previously does not flush
%% expects a prolog string or a single atom/term
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
send_message(_, []) :-
	!. % commit
send_message(OutStream, Message) :-
	string(Message),
	!, % commit
	send_message_string(OutStream, Message).
send_message(OutStream, [First|Rest]) :-
	!, % commit
	send_message(OutStream, First),
	send_message(OutStream, Rest).
send_message(OutStream, Message) :-
	catch(write(OutStream, Message), E, handle_error_send_message(E, '1', Message)).

send_message_string(_, []) :-
	!. % commit
send_message_string(OutStream, [First|Rest]) :-
	char_code(Ascii, First),
	!,
	client_out_stream(OutStream),
	!,
	catch(write(OutStream, Ascii), E, handle_error_send_message(E, '2', First)),
	send_message_string(OutStream, Rest).
send_message_string(_, Message) :-
	bug(['Failed sending {', Message, '}']).

handle_error_send_message(Error, ID, Message) :-
	server_close_out_stream,
	server_log(['Error ', ID, ' sending {', Message, '} ', Error]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% send_message_nl(+Message) 
%%  as with send_message(Message) but also flushes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
send_message_nl(Message) :-
	client_out_stream(OutStream),
	!, % commit
	send_message_nl(OutStream, Message),
	track_user_history(out, Message).
send_message_nl(Message) :-
	server_log(['Not sent {', Message, '}']).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% send_message_nl(+OutStream, +Message) 
%%  as with send_message(OutStream, Message) but also flushes
%%  not intended to be used outside of this file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
send_message_nl(OutStream, Message) :-
	send_message(OutStream, Message),
	catch(nl(OutStream), E, handle_error_send_message(E, '3', 'carriage return')),
	catch(flush_output(OutStream), E, handle_error_send_message(E, '4', 'flush')).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- dynamic(history_file/1).
server_log(Message) :-
	history_file(_),
	!,
	track_user_history(note, Message).
server_log(Message) :-
	sclogn(['1 ', Message]).

track_user_history(Direction, Message) :-
	history_file(Stream),
	!,
	write_history(Stream, Direction, Message).
track_user_history(Direction, Message) :-
	sclogn([Direction, ' says ', Message]).

open_history_file :-
	user_name(Name),
	!,
	client_start_time(Time),
	convert_time(Time, TimeStamp),
	string_to_atom(TimeStamp, TimeAtom),
	% get the path of the initial application file
	current_application(Directory, _, _),
	atom_concat(Directory, '/', Temp1), % rebuild log directory pathname
	atom_concat(Temp1, 'logs/', Temp2),
	atom_concat(Temp2, Name, Temp3),
	atom_concat(Temp3, TimeAtom, Base),
	atom_concat(Base, '.log', FileName),
	sclogn(['Creating file {', FileName, '}']),
	open(FileName, append, Stream, [close_on_abort(false)]),
	assert(history_file(Stream)),
	sclogn(['History {', Stream, '}']),
	register_a_shutdown_call(close_history_file).
open_history_file.

write_history(Stream, Direction, Message) :-
	history_file(Stream),
	!,
	get_time(Time),
	convert_time(Time, String),
	string_to_atom(String, TimeAtom),
	server_atoms2atom(['history(''', TimeAtom, ''', ', Direction, ', \'', Message, '\').'], Atom),
	catch(write(Stream, Atom), E, handle_error_write_history(E, Atom)),
	catch(nl(Stream), E, handle_error_write_history(E, 'carriage return')).
write_history(_, _, _) :-
	sclogn('Weirdness abounds').

handle_error_write_history(Error, Atom) :-
	sclogn(['*** ERROR *** ', Error, ' writing {', Atom, ' to history file.']).

close_history_file :-
	history_file(Stream),
	!, % commit
	sclogn(['Closing history file']),
	retractall(history_file(_)),
	close(Stream).
close_history_file.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sclog([]) :-
	!.
sclog([First|Rest]) :-
	!,
	sclog(First),
	sclog(Rest).
sclog(Message) :-
	write(Message).

sclogn(Message) :-
	sclog(Message),
	nl.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% end of server.pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
