%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% server_login.pl
%%  this is code that logs in a user to client application
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- dynamic(user_name/1). %% user_name(UserName)
:- dynamic(current_application/3). %% current_application(Directory, File, EntryPoint)

server_login :-
	register_a_shutdown_call(login_shutdown),
	wait_for_client_begin,
	login_init,
	login_start(0),
	login_clean_up.

server_login. %% this should always succeed even if something failed.

wait_for_client_begin :-
	%% use read message cause actually want the start
	read_message(Response),
	handle_client_begin(Response).

handle_client_begin("<start/>").
handle_client_begin(Response) :-
	string_to_atom(Response, Atom),
	debugn(['First message is ', Atom]).

login_shutdown :-
	exists_file('user/user_access.dat.lock'),
	delete_file('user/user_access.dat.lock').
login_shutdown.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
login_init :- %% send a go message
	send_message_nl('<start/>'),
	send_message_nl('<open><type>dialog</type><name>login</name><title>Meuse Login</title></open>'),
	send_message_nl('<input>login</input>'),
	send_message_nl('<login><show/></login>'),
        send_message_nl('<login><say> Welcome <nl/></say></login>').

login_start(Count) :-
	send_message_nl('<login><say> Enter User Name: </say></login>'),
	login_get_atom(Name),
	debugn(['User name is ', Name]),
	login_user(Name, Count),
	debugn([Name, ' has logged out.']).

login_user(Name, Count) :-
	send_message_nl('<login><say> Enter Password: </say></login>'),
	send_message_nl('<password/>'),
	login_get_atom(Password),
        login_verify_user(Name, Password, Count).

login_verify_user(Name, Password, Count) :-
	login_get_user_data(Name, Password, PermittedAccess, Directives),
	debugn('Got user data'),
    	login_handle_access(Name, PermittedAccess, Directives, Count).

login_handle_access(_, [], _, Count) :-
    	Count > 2,
    	!,
    	send_message_nl('<redirect>Refused</redirect>'),
    	fail.
login_handle_access(Name, [], _, Count) :-
    	server_ask_yes_no(['Incorrect login: you have mistyped something during the login process or you do not have an account. ', Name, ', have you been given an account for this application? (y/n) '], Answer),
    	login_handle_access_answer(Answer, Count).
login_handle_access(Name, [[_, ApplicationInformation]], Directives, _) :-
	server_call_all(Directives),
	login_start_application(Name, ApplicationInformation).
login_handle_access(Name, Programs, Directives, _) :-
	server_call_all(Directives),
	server_ask_get_choice('What do you want to do', Programs, Answer),
	login_start_application(Name, Answer).

login_start_application(Name, [Directory, FileName, EntryPoint]) :-
	init_for_debug,
	atom_concat(Directory, '/', Temp),
	atom_concat(Temp, FileName, FilePath),
	consult(FilePath),
	send_message_nl('<kill>login</kill>'),
	assert(user_name(Name)),
	assert(current_application(Directory, FileName, EntryPoint)),
	open_history_file,
	(catch(call(EntryPoint), E, handle_login_call_error(E, Directory, FileName, EntryPoint));
	true).

login_handle_access_answer(yes, Count) :-
    	NewCount is Count + 1,
    	login_start(NewCount).
login_handle_access_answer(no, _) :-
	send_message_nl('<login><say>If you will supply us with a user name and email address, we will contact you with further information to allow you to login.<nl/>Please enter a user name :</say></login>'),
	login_get_atom(Name),
	send_message('<login><say> Hello '),
	send_message(Name),
	send_message_nl(', please enter your email address :</say></login>'),
	login_read_atom(Mail),
	server_ask_yes_no([' User Name: ', Name, '<nl/>Email Address: ', Mail, '<nl/>  Is the above correct? '], Answer),
	login_handle_new_enroll(Name, Mail, Answer).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
handle_login_call_error(Error, Directory, File, EntryPoint) :-
	bug(['Error in ', File, ' in ', Directory, ' calling ', EntryPoint, ': ', Error]),
	client_shutdown.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
login_handle_new_enroll(_, _, no) :-
	login_handle_access_answer(yes, _).
login_handle_new_enroll(Name, Mail, yes) :-
	send_message('<redirect>ReturnLater</redirect>'),
	login_add_new_user(Name, Mail).

login_add_new_user(Name, Mail) :-
	file_add_data_list([new_user(Name, Mail)]),
	debugn(['Need to register ', Name, ' at ', Mail]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
login_get_user_data(Name, Password, Program, Directive) :-
 	find_in_file('user/user_access.dat', user(Name, Password, _, P, D), Found),
 	login_handle_user_data(Name, Password, P, D, Found, Program, Directive).

login_handle_user_data(Name, Password, P, D, true, P, D) :-
	!,
	debugn(['Signed in ', Name, '-', Password]).
login_handle_user_data(Name, Password, _, _, false, [], []) :-
	debugn(['Not Registered ', Name, '-', Password]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
init_for_debug :-
	is_developer(_),
	is_debug(yes),
	send_message_nl('<develop/>').
init_for_debug.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
login_clean_up :-
	debugn('So long and thanx for all those fish ...').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% often calling read directly will get you some messages you don't want
%%  to handle every time you call read the best way to handle this is to
%%  write your own get that calls read and then handles anything you
%%  want to ignore
login_get_atom(Reply) :-
	login_get_message(Data),
	string_to_atom(Data, Reply).

login_get_message(Reply) :-
	read_message(Input),
	login_handle_input(Input, Reply).

login_handle_input("<start/>", Reply) :-
	login_get_message(Reply).
login_handle_input("<stop/>", _) :- %% client is going down so quit
	client_shutdown.
login_handle_input("<pause/>", Reply) :-
	login_get_message(Reply).
login_handle_input("<nl/>", "\n"). %% user hit a blank line
login_handle_input(Reply, Reply).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% end of program .pl
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
