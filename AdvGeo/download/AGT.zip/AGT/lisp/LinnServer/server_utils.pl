server_assert_all([]).
server_assert_all([First | Rest]) :-
	assert(First),
	server_assert_all(Rest).

server_call_all([]).
server_call_all([First|Rest]) :-
	catch(call(First), E, server_handle_error_call_all(E, First)),
	server_call_all(Rest).

server_handle_error_call_all(Error, First) :-
	bug(['Error calling directive {', First, '}: ', Error]).

server_atoms2atom([], '') :-
	!.
server_atoms2atom([Atom], Out) :-
	!,
	server_atoms2atom(Atom, Out).
server_atoms2atom([First|Rest], Out) :-
	!,
	server_atoms2atom(Rest, RestOut),
	server_atoms2atom(First, FirstOut),
	atom_concat(FirstOut, RestOut, Out).
server_atoms2atom(Atom, Atom) :-
	atom(Atom),
	!.
server_atoms2atom(Atom, Out) :-
	term_to_atom(Atom, Out),
	!.

server_ask_yes_no(Prompt, Answer) :-
	server_atoms2atom(Prompt, Atom),
	send_message('<login><say>'),
	send_message(Atom),
	send_message_nl('</say></login>'),
	send_message_nl('<single/>'),
	read_message(Reply),
	send_message_nl('<login><say><nl/></say></login>'),
	server_handle_yes_no_reply(Prompt, Reply, Answer).

server_handle_yes_no_reply(_, "y", yes).
server_handle_yes_no_reply(_, "Y", yes).
server_handle_yes_no_reply(_, "n", no).
server_handle_yes_no_reply(_, "N", no).
server_handle_yes_no_reply(Prompt, _, Answer) :-
	send_message_nl('<login><say>Please respond by using either the "y" or "n" key<nl/></say></login>'),
	server_ask_yes_no(Prompt, Answer).

server_ask_get_choice(Prompt, Choices, Answer) :-
	send_message('<login><say>'),
	send_message(Prompt),
	send_message_nl(' ?<nl/></say></login>'),
	server_send_choices(Choices, 'a'),
	send_message_nl('<single/>'),
	send_message_nl('<login><say>-> </say></login>'),
	read_message(Reply),
	server_handle_choices_reply(Prompt, Choices, Reply, Answer).

server_send_choices([], _).
server_send_choices([[Prompt|_]|Rest], Letter) :-
	send_message('<login><say>  '),
	send_message(Letter),
	send_message(') '),
	send_message(Prompt),
	send_message_nl('<nl/></say></login>'),
	char_code(Letter, Value),
	NewValue is Value + 1,
	char_code(NextLetter, NewValue),
	server_send_choices(Rest, NextLetter).

server_handle_choices_reply(_, Choices, Reply, Answer) :-
 write(Reply), nl,
	Reply = [Code],
	Index is Code - 97, %% 'a' is 97 -- this'll get 0 to some'at
	nth0(Index, Choices, [_, Answer]).
server_handle_choices_reply(Prompt, Choices, _, Answer) :-
	send_message('<login><say><nl/>That is not a correct choice. Try Again.<nl/></say></login>'),
	server_ask_get_choice(Prompt, Choices, Answer).

server_report_type(Value) :-
	atom(Value), write('atom-'), fail.
server_report_type(Value) :-
	atomic(Value), write('atomic-'), fail.
server_report_type(Value) :-
	float(Value), write('float-'), fail.
server_report_type(Value) :-
	integer(Value), write('integer-'), fail.
server_report_type(Value) :-
	is_list(Value), write('list-'), fail.
server_report_type(Value) :-
	is_set(Value), write('set-'), fail.
server_report_type(Value) :-
	nonvar(Value), write('nonvar-'), fail.
server_report_type(Value) :-
	number(Value), write('number-'), fail.
server_report_type(Value) :-
	string(Value), write('string-'), fail.
server_report_type(Value) :-
	var(Value), write('var-'), fail.
server_report_type(Value) :-
	write(Value), nl.

