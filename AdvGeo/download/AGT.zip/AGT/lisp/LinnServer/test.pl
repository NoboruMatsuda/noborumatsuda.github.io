%%replace_chars([Old], [New], Original, String)
replace_chars([_], [_], [], []).
replace_chars([Old], [New], [Old|Rest], [New|NewRest]) :-
	!,
	replace_chars([Old], [New], Rest, NewRest).
replace_chars([Old], [New], [Other|Rest], [Other|NewRest]) :-
	replace_chars([Old], [New], Rest, NewRest).

pcr :-
	pcr(0).

pcr(300) :-
	!.
pcr(K) :-
	char_code(A, K),
	findall(Type, code_type(K, Type), Types),
	write(K), write(') ['), write(A), write('] {'), write(Types), write('}'), nl,
	NK is K + 1,
	pcr(NK).


%% symbols - presubscript subscript presuperscript superscript capital lowercase underscored barred tilda accentgrave accentague trema circumflexed overcircumflexed caret
%% superscript - raised to the power
%% subscript - indexed by -- arrays/tables vectors/matrixes


