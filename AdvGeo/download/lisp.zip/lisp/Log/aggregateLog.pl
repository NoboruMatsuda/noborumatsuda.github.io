#!c:/UsrLocal/Perl/bin/perl -w
#
#	Aggregate log files made for each construction and output
#	total number of states, propositions asserted, and search time.
#	Made for JAR03 submission to make Fig. 4
#
#	Usage:  perl aggregateLog.pl <problem-id> <dir>
#
# Copyright Noboru Matsuda, 2003
# Tue Jul 01 15:34:59 2003

# Global variables
$numLogFiles = 0;
$totalTime = 0;
$numStates = 0;
$numProp = 0;
$startTime = "";
$endTime = "";

# Problem ID and directory
$problem = $ARGV[0];

#
# Functions
#

# Returns the last element of a list
sub lastElement {
    @tmp = split( / /, $_[0] );
    return $tmp[$#tmp];
}

# Convers string representing time (e.g, "17:52:10") into seconds
sub stringToSec {
    @tmp = split( /:/, $_[0] );
    return $tmp[0]*60*60 + $tmp[1]*60 + $tmp[2];
}

#
# Main routine
# 
if ( $#ARGV =~ 1 ) {
    $dir = $ARGV[1];
} else {
    $dir = "c:/Home2/GRAMY/Logfiles/Log/2.8.4/";
}

print( " Problem ID:: ", $problem, "\n" );
# print( "Working dir:: ", $dir, "\n" );

# Target directory must be synthesized 
$targetDir = "${dir}TA-$problem";
# print ( " Target dir:: ", $targetDir, "\n" );

if ( ! -e $targetDir ) {
    print( "Can't find the target directory.\n" );
    print( "Good bye\n" );
    exit();
}

# A list of files in the target dir
chdir( $targetDir );
@logFiles = glob( "*.txt" );

## # Collect log files for successful search 
##
## @successfulOnes = ();
##
## foreach ( @logFiles ) {
##     if ( /ng.txt$/ ) {		# matched with $_
## 	# print( $_, " is skipped.\n" );
##     } else {
## 	# print ( $_, "\n" );
## 	@successfulOnes = (@successfulOnes, $_);
## 	$numLogFiles++
##     }
## }

# Aggregate data from the target log files
foreach $theFile ( @logFiles ) {
    open( F, $theFile );
    while (<F>) {
	if ( /^Started:/ ) {
	    $startTime = stringToSec(lastElement($_));
	} elsif ( /^Terminated:/ ) {
	    $endTime = stringToSec(lastElement($_));
	} elsif ( /of assertions/ ) {
	    $numProp += lastElement( $_ );
	} elsif ( /nodes expanded/ ) {
	    $numStates += lastElement( $_ );
	}
    }
    $totalTime += ($endTime - $startTime);
    # print( "totalTime --> $totalTime\n" );
}

# output the results
print "\n";
# print( $numLogFiles, " log files found.\n" );
print( " Time: ", $totalTime, "\n" );
print( "State: ", $numStates, "\n" );
print( " Prop: ", $numProp, "\n" );
